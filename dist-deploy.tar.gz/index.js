var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// drizzle/schema.ts
var schema_exports = {};
__export(schema_exports, {
  adminAuditLogs: () => adminAuditLogs,
  aiMessageLogs: () => aiMessageLogs,
  apiKeys: () => apiKeys,
  authRateLimits: () => authRateLimits,
  automationJobs: () => automationJobs,
  automations: () => automations,
  billingInvoices: () => billingInvoices,
  billingRefunds: () => billingRefunds,
  emailVerificationTokens: () => emailVerificationTokens,
  featureConfigs: () => featureConfigs,
  leads: () => leads,
  llmCircuitBreakers: () => llmCircuitBreakers,
  messages: () => messages,
  passwordResetTokens: () => passwordResetTokens,
  phoneNumbers: () => phoneNumbers,
  plans: () => plans,
  recoveryEvents: () => recoveryEvents,
  referralPayouts: () => referralPayouts,
  referrals: () => referrals,
  smsRateLimits: () => smsRateLimits,
  stripeSubscriptions: () => stripeSubscriptions,
  subscriptions: () => subscriptions,
  systemErrorLogs: () => systemErrorLogs,
  templates: () => templates,
  tenants: () => tenants,
  usage: () => usage,
  users: () => users,
  webhookLogs: () => webhookLogs,
  webhookReceiveDedupes: () => webhookReceiveDedupes
});
import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
  index
} from "drizzle-orm/mysql-core";
var users, emailVerificationTokens, passwordResetTokens, tenants, plans, subscriptions, billingInvoices, billingRefunds, usage, phoneNumbers, leads, messages, templates, automations, automationJobs, aiMessageLogs, webhookLogs, apiKeys, systemErrorLogs, adminAuditLogs, smsRateLimits, llmCircuitBreakers, webhookReceiveDedupes, authRateLimits, referrals, referralPayouts, stripeSubscriptions, recoveryEvents, featureConfigs;
var init_schema = __esm({
  "drizzle/schema.ts"() {
    users = mysqlTable("users", {
      id: int("id").autoincrement().primaryKey(),
      openId: varchar("openId", { length: 64 }).notNull().unique(),
      name: text("name"),
      email: varchar("email", { length: 320 }),
      emailVerifiedAt: timestamp("emailVerifiedAt"),
      loginMethod: varchar("loginMethod", { length: 64 }),
      passwordHash: varchar("passwordHash", { length: 255 }),
      role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
      tenantId: int("tenantId"),
      active: boolean("active").default(true).notNull(),
      stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
      lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull()
    }, (t2) => ({
      emailIdx: uniqueIndex("users_email_idx").on(t2.email),
      tenantIdIdx: index("users_tenant_id_idx").on(t2.tenantId),
      openIdIdx: uniqueIndex("users_open_id_idx").on(t2.openId)
    }));
    emailVerificationTokens = mysqlTable("email_verification_tokens", {
      id: int("id").autoincrement().primaryKey(),
      userId: int("userId").notNull(),
      email: varchar("email", { length: 320 }).notNull(),
      tokenHash: varchar("tokenHash", { length: 255 }).notNull(),
      expiresAt: timestamp("expiresAt").notNull(),
      consumedAt: timestamp("consumedAt"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    passwordResetTokens = mysqlTable("password_reset_tokens", {
      id: int("id").autoincrement().primaryKey(),
      userId: int("userId").notNull(),
      tokenHash: varchar("tokenHash", { length: 255 }).notNull(),
      expiresAt: timestamp("expiresAt").notNull(),
      consumedAt: timestamp("consumedAt"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    tenants = mysqlTable("tenants", {
      id: int("id").autoincrement().primaryKey(),
      name: varchar("name", { length: 255 }).notNull(),
      slug: varchar("slug", { length: 100 }).notNull().unique(),
      timezone: varchar("timezone", { length: 64 }).default("America/New_York").notNull(),
      industry: varchar("industry", { length: 100 }),
      active: boolean("active").default(true).notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    plans = mysqlTable("plans", {
      id: int("id").autoincrement().primaryKey(),
      name: varchar("name", { length: 100 }).notNull().unique(),
      slug: varchar("slug", { length: 100 }).notNull().unique(),
      priceMonthly: int("priceMonthly").default(0).notNull(),
      maxAutomations: int("maxAutomations").default(5).notNull(),
      maxMessages: int("maxMessages").default(500).notNull(),
      maxSeats: int("maxSeats").default(1).notNull(),
      stripePriceId: varchar("stripePriceId", { length: 255 }),
      revenueSharePercent: int("revenueSharePercent").default(0).notNull(),
      promotionalSlots: int("promotionalSlots").default(0).notNull(),
      promotionalPriceCap: int("promotionalPriceCap").default(0).notNull(),
      hasPromotion: boolean("hasPromotion").default(false).notNull(),
      features: json("features").$type(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    subscriptions = mysqlTable("subscriptions", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      planId: int("planId").notNull(),
      stripeId: varchar("stripeId", { length: 255 }),
      status: mysqlEnum("status", ["active", "trialing", "past_due", "canceled", "unpaid"]).default("trialing").notNull(),
      trialEndsAt: timestamp("trialEndsAt"),
      trialReminderSent: boolean("trialReminderSent").default(false).notNull(),
      currentPeriodStart: timestamp("currentPeriodStart"),
      currentPeriodEnd: timestamp("currentPeriodEnd"),
      isPromotional: boolean("isPromotional").default(false).notNull(),
      promotionalExpiresAt: timestamp("promotionalExpiresAt"),
      // ROI Guarantee fields
      guaranteeCohort: mysqlEnum("guaranteeCohort", ["risk_free_20", "flex_10"]),
      guaranteeStatus: mysqlEnum("guaranteeStatus", ["active", "satisfied", "refunded", "expired"]),
      guaranteeStartedAt: timestamp("guaranteeStartedAt"),
      guaranteeExpiresAt: timestamp("guaranteeExpiresAt"),
      lastRoiCheckAt: timestamp("lastRoiCheckAt"),
      lastRoiAmount: int("lastRoiAmount"),
      // in cents, client's net ROI
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    billingInvoices = mysqlTable("billing_invoices", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      subscriptionId: int("subscriptionId"),
      stripeInvoiceId: varchar("stripeInvoiceId", { length: 255 }).notNull().unique(),
      stripeChargeId: varchar("stripeChargeId", { length: 255 }),
      number: varchar("number", { length: 128 }),
      status: varchar("status", { length: 64 }).notNull(),
      currency: varchar("currency", { length: 16 }).notNull(),
      subtotal: int("subtotal").default(0).notNull(),
      total: int("total").default(0).notNull(),
      amountPaid: int("amountPaid").default(0).notNull(),
      amountRemaining: int("amountRemaining").default(0).notNull(),
      hostedInvoiceUrl: varchar("hostedInvoiceUrl", { length: 500 }),
      invoicePdfUrl: varchar("invoicePdfUrl", { length: 500 }),
      periodStart: timestamp("periodStart"),
      periodEnd: timestamp("periodEnd"),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    billingRefunds = mysqlTable("billing_refunds", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      subscriptionId: int("subscriptionId"),
      billingInvoiceId: int("billingInvoiceId"),
      stripeRefundId: varchar("stripeRefundId", { length: 255 }).notNull().unique(),
      stripeChargeId: varchar("stripeChargeId", { length: 255 }),
      amount: int("amount").notNull(),
      currency: varchar("currency", { length: 16 }).notNull(),
      reason: varchar("reason", { length: 100 }),
      status: varchar("status", { length: 64 }).notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    usage = mysqlTable("usage", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      messagesSent: int("messagesSent").default(0).notNull(),
      automationsRun: int("automationsRun").default(0).notNull(),
      hasUsageAlerted: boolean("hasUsageAlerted").default(false).notNull(),
      periodStart: timestamp("periodStart").notNull(),
      periodEnd: timestamp("periodEnd").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    phoneNumbers = mysqlTable("phone_numbers", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      number: varchar("number", { length: 20 }).notNull().unique(),
      label: varchar("label", { length: 100 }),
      isDefault: boolean("isDefault").default(false).notNull(),
      isInbound: boolean("isInbound").default(false).notNull(),
      twilioSid: varchar("twilioSid", { length: 100 }),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      deletedAt: timestamp("deletedAt")
    });
    leads = mysqlTable("leads", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      phone: varchar("phone", { length: 20 }).notNull(),
      phoneHash: varchar("phoneHash", { length: 64 }).notNull(),
      name: varchar("name", { length: 255 }),
      email: varchar("email", { length: 320 }),
      status: mysqlEnum("status", ["new", "contacted", "qualified", "booked", "lost", "unsubscribed"]).default("new").notNull(),
      source: varchar("source", { length: 100 }),
      tags: json("tags").$type(),
      notes: text("notes"),
      lastMessageAt: timestamp("lastMessageAt"),
      lastInboundAt: timestamp("lastInboundAt"),
      appointmentAt: timestamp("appointmentAt"),
      // TCPA Compliance fields
      smsConsentAt: timestamp("smsConsentAt"),
      smsConsentSource: varchar("smsConsentSource", { length: 100 }),
      // "form", "manual", "import", etc.
      tcpaConsentText: text("tcpaConsentText"),
      // Store the exact consent language
      unsubscribedAt: timestamp("unsubscribedAt"),
      unsubscribeMethod: varchar("unsubscribeMethod", { length: 50 }),
      // "sms_stop", "manual", etc.
      recoverySource: varchar("recoverySource", { length: 100 }),
      // "rebookd_automation", "manual", etc.
      recoveredFromLeadId: int("recoveredFromLeadId"),
      // Links to original canceled/no-show lead
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      tenantIdIdx: index("leads_tenant_id_idx").on(t2.tenantId),
      phoneHashIdx: uniqueIndex("leads_phone_hash_idx").on(t2.tenantId, t2.phoneHash),
      statusIdx: index("leads_status_idx").on(t2.tenantId, t2.status),
      createdAtIdx: index("leads_created_at_idx").on(t2.tenantId, t2.createdAt),
      searchIdx: index("leads_search_idx").on(t2.tenantId, t2.phone, t2.name, t2.email),
      consentIdx: index("leads_consent_idx").on(t2.tenantId, t2.smsConsentAt)
    }));
    messages = mysqlTable("messages", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      leadId: int("leadId").notNull(),
      direction: mysqlEnum("direction", ["inbound", "outbound"]).notNull(),
      body: text("body").notNull(),
      fromNumber: varchar("fromNumber", { length: 20 }),
      toNumber: varchar("toNumber", { length: 20 }),
      twilioSid: varchar("twilioSid", { length: 100 }),
      status: mysqlEnum("status", ["queued", "sent", "delivered", "failed", "received"]).default("queued").notNull(),
      provider: varchar("provider", { length: 50 }),
      providerError: text("providerError"),
      retryCount: int("retryCount").default(0).notNull(),
      idempotencyKey: varchar("idempotencyKey", { length: 64 }),
      deliveredAt: timestamp("deliveredAt"),
      failedAt: timestamp("failedAt"),
      aiRewritten: boolean("aiRewritten").default(false).notNull(),
      tone: varchar("tone", { length: 50 }),
      automationId: int("automationId"),
      recoveryEventId: int("recoveryEventId"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    }, (t2) => ({
      tenantIdIdx: index("messages_tenant_id_idx").on(t2.tenantId),
      leadIdIdx: index("messages_lead_id_idx").on(t2.leadId),
      tenantLeadIdx: index("messages_tenant_lead_idx").on(t2.tenantId, t2.leadId),
      createdAtIdx: index("messages_created_at_idx").on(t2.tenantId, t2.createdAt),
      idempotencyKeyIdx: uniqueIndex("messages_idempotency_key_idx").on(t2.tenantId, t2.idempotencyKey),
      recoveryEventIdx: index("messages_recovery_event_idx").on(t2.recoveryEventId)
    }));
    templates = mysqlTable("templates", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      key: varchar("key", { length: 100 }).notNull(),
      name: varchar("name", { length: 255 }).notNull(),
      body: text("body").notNull(),
      tone: mysqlEnum("tone", ["friendly", "professional", "casual", "urgent", "empathetic"]).default("friendly").notNull(),
      variables: json("variables").$type(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
      deletedAt: timestamp("deletedAt")
    });
    automations = mysqlTable("automations", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      name: varchar("name", { length: 255 }).notNull(),
      key: varchar("key", { length: 100 }).notNull(),
      category: mysqlEnum("category", ["follow_up", "reactivation", "appointment", "welcome", "custom", "no_show", "cancellation", "loyalty"]).default("custom").notNull(),
      enabled: boolean("enabled").default(true).notNull(),
      triggerType: mysqlEnum("triggerType", ["new_lead", "inbound_message", "status_change", "time_delay", "appointment_reminder"]).default("new_lead").notNull(),
      triggerConfig: json("triggerConfig").$type(),
      conditions: json("conditions").$type(),
      actions: json("actions").$type(),
      runCount: int("runCount").default(0).notNull(),
      errorCount: int("errorCount").default(0).notNull(),
      lastRunAt: timestamp("lastRunAt"),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
      deletedAt: timestamp("deletedAt")
    });
    automationJobs = mysqlTable("automation_jobs", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      automationId: int("automationId").notNull(),
      leadId: int("leadId"),
      eventType: varchar("eventType", { length: 100 }).notNull(),
      eventData: json("eventData").$type(),
      stepIndex: int("stepIndex").default(0).notNull(),
      nextRunAt: timestamp("nextRunAt").notNull(),
      status: mysqlEnum("status", ["pending", "running", "completed", "failed", "cancelled"]).default("pending").notNull(),
      attempts: int("attempts").default(0).notNull(),
      lastError: text("lastError"),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    aiMessageLogs = mysqlTable("ai_message_logs", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      leadId: int("leadId"),
      original: text("original").notNull(),
      rewritten: text("rewritten"),
      tone: varchar("tone", { length: 50 }).notNull(),
      success: boolean("success").default(true).notNull(),
      error: text("error"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    webhookLogs = mysqlTable("webhook_logs", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId"),
      url: varchar("url", { length: 500 }).notNull(),
      payload: text("payload").notNull(),
      statusCode: int("statusCode"),
      error: text("error"),
      attempts: int("attempts").default(0).notNull(),
      nextRetryAt: timestamp("nextRetryAt"),
      resolved: boolean("resolved").default(false).notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    apiKeys = mysqlTable("api_keys", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      keyHash: varchar("keyHash", { length: 255 }).notNull(),
      keyPrefix: varchar("keyPrefix", { length: 10 }).notNull(),
      label: varchar("label", { length: 100 }),
      active: boolean("active").default(true).notNull(),
      lastUsedAt: timestamp("lastUsedAt"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    systemErrorLogs = mysqlTable("system_error_logs", {
      id: int("id").autoincrement().primaryKey(),
      type: mysqlEnum("type", ["twilio", "ai", "automation", "billing", "webhook"]).notNull(),
      message: text("message").notNull(),
      detail: text("detail"),
      tenantId: int("tenantId"),
      resolved: boolean("resolved").default(false).notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    adminAuditLogs = mysqlTable("admin_audit_logs", {
      id: int("id").autoincrement().primaryKey(),
      adminUserId: int("adminUserId").notNull(),
      adminEmail: varchar("adminEmail", { length: 320 }),
      action: varchar("action", { length: 120 }).notNull(),
      targetTenantId: int("targetTenantId"),
      targetUserId: int("targetUserId"),
      route: varchar("route", { length: 255 }),
      metadata: json("metadata").$type(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    smsRateLimits = mysqlTable("sms_rate_limits", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      windowStart: timestamp("windowStart").notNull(),
      count: int("count").default(0).notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    llmCircuitBreakers = mysqlTable("llm_circuit_breakers", {
      id: int("id").autoincrement().primaryKey(),
      provider: varchar("provider", { length: 50 }).notNull(),
      model: varchar("model", { length: 100 }).notNull(),
      state: mysqlEnum("state", ["closed", "open", "half_open"]).default("closed").notNull(),
      consecutiveFailures: int("consecutiveFailures").default(0).notNull(),
      openedAt: timestamp("openedAt"),
      cooldownUntil: timestamp("cooldownUntil"),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    webhookReceiveDedupes = mysqlTable(
      "webhook_receive_dedupes",
      {
        id: int("id").autoincrement().primaryKey(),
        tenantId: int("tenantId").notNull(),
        dedupeKey: varchar("dedupeKey", { length: 64 }).notNull(),
        createdAt: timestamp("createdAt").defaultNow().notNull()
      },
      (t2) => ({
        tenantDedupeUid: uniqueIndex("webhook_receive_dedupes_tenant_dedupe_uidx").on(t2.tenantId, t2.dedupeKey)
      })
    );
    authRateLimits = mysqlTable("auth_rate_limits", {
      id: int("id").autoincrement().primaryKey(),
      email: varchar("email", { length: 320 }).notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    }, (t2) => ({
      emailCreatedIdx: uniqueIndex("auth_rate_limits_email_created_idx").on(t2.email, t2.createdAt)
    }));
    referrals = mysqlTable("referrals", {
      id: serial("id").primaryKey(),
      referrerId: int("referrer_id").notNull(),
      referredUserId: int("referred_user_id").notNull(),
      referralCode: varchar("referral_code", { length: 16 }).notNull().unique(),
      status: mysqlEnum("status", ["pending", "completed", "expired", "cancelled"]).default("pending").notNull(),
      subscriptionId: varchar("subscription_id", { length: 255 }),
      rewardAmount: int("reward_amount").default(50).notNull(),
      rewardCurrency: varchar("reward_currency", { length: 3 }).default("USD").notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      completedAt: timestamp("completed_at"),
      expiresAt: timestamp("expires_at").notNull(),
      payoutScheduledAt: timestamp("payout_scheduled_at"),
      // When payout should be processed
      payoutProcessedAt: timestamp("payout_processed_at"),
      // When payout was actually processed
      updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
      metadata: json("metadata")
    }, (table) => ({
      referrerIdIdx: index("idx_referrals_referrer_id").on(table.referrerId),
      referredUserIdIdx: index("idx_referrals_referred_user_id").on(table.referredUserId),
      statusIdx: index("idx_referrals_status").on(table.status),
      expiresAtIdx: index("idx_referrals_expires_at").on(table.expiresAt),
      payoutScheduledAtIdx: index("idx_referrals_payout_scheduled_at").on(table.payoutScheduledAt)
    }));
    referralPayouts = mysqlTable("referral_payouts", {
      id: int("id").autoincrement().primaryKey(),
      userId: int("userId").notNull(),
      amount: int("amount").notNull(),
      currency: varchar("currency", { length: 3 }).default("USD").notNull(),
      status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
      method: mysqlEnum("method", ["paypal", "stripe", "bank_transfer"]).default("paypal").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      processedAt: timestamp("processedAt"),
      transactionId: varchar("transactionId", { length: 255 }),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    stripeSubscriptions = mysqlTable("stripe_subscriptions", {
      id: varchar("id", { length: 255 }).primaryKey(),
      userId: int("user_id").notNull(),
      tenantId: int("tenant_id").notNull(),
      customerId: varchar("customer_id", { length: 255 }).notNull(),
      status: varchar("status", { length: 50 }).notNull(),
      priceId: varchar("price_id", { length: 255 }).notNull(),
      quantity: int("quantity").default(1).notNull(),
      currentPeriodStart: timestamp("current_period_start").notNull(),
      currentPeriodEnd: timestamp("current_period_end").notNull(),
      cancelAtPeriodEnd: boolean("cancel_at_period_end").default(false).notNull(),
      trialEnd: timestamp("trial_end"),
      canceledAt: timestamp("canceled_at"),
      endedAt: timestamp("ended_at"),
      latestInvoiceId: varchar("latest_invoice_id", { length: 255 }),
      paymentMethodId: varchar("payment_method_id", { length: 255 }),
      metadata: json("metadata"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull()
    }, (table) => ({
      userIdIdx: index("idx_subscriptions_user_id").on(table.userId),
      tenantIdIdx: index("idx_subscriptions_tenant_id").on(table.tenantId),
      customerIdIdx: index("idx_subscriptions_customer_id").on(table.customerId),
      statusIdx: index("idx_subscriptions_status").on(table.status)
    }));
    recoveryEvents = mysqlTable("recovery_events", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      leadId: int("leadId").notNull(),
      /** The automation that triggered this recovery attempt */
      automationId: int("automationId"),
      /** The message that was sent for this recovery attempt */
      messageId: int("messageId"),
      /** Original canceled/no-show appointment this recovery targets */
      originalAppointmentId: varchar("originalAppointmentId", { length: 255 }),
      /** New appointment booked as a result of this recovery */
      recoveredAppointmentId: varchar("recoveredAppointmentId", { length: 255 }),
      /** Leakage type: no_show, cancellation, followup_missed, etc. */
      leakageType: varchar("leakageType", { length: 100 }).notNull(),
      /** Current status of the recovery attempt */
      status: mysqlEnum("status", [
        "sent",
        // SMS sent, awaiting response
        "responded",
        // Customer responded but hasn't booked
        "converted",
        // Customer rebooked (potential revenue)
        "realized",
        // Payment captured in Stripe (actual revenue)
        "manual_realized",
        // Manually marked as recovered (off-platform payment)
        "failed",
        // Recovery attempt failed / no response
        "expired"
        // Recovery window expired
      ]).default("sent").notNull(),
      /** Unique tracking token embedded in SMS for attribution */
      trackingToken: varchar("trackingToken", { length: 64 }).notNull(),
      /** Stripe Payment Intent ID when payment is captured */
      stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
      /** Stripe Invoice ID for reconciliation */
      stripeInvoiceId: varchar("stripeInvoiceId", { length: 255 }),
      /** Estimated revenue at time of booking */
      estimatedRevenue: int("estimatedRevenue").default(0).notNull(),
      /** Actual realized revenue from Stripe (cents) */
      realizedRevenue: int("realizedRevenue").default(0).notNull(),
      /** Attribution model used: first_touch, last_touch */
      attributionModel: varchar("attributionModel", { length: 50 }).default("last_touch").notNull(),
      /** Whether this is the winning attribution (dedup flag) */
      isPrimaryAttribution: boolean("isPrimaryAttribution").default(false).notNull(),
      /** Notes for manual reconciliation */
      notes: text("notes"),
      /** When the recovery SMS was sent */
      sentAt: timestamp("sentAt").defaultNow().notNull(),
      /** When the customer responded */
      respondedAt: timestamp("respondedAt"),
      /** When the customer rebooked */
      convertedAt: timestamp("convertedAt"),
      /** When payment was captured */
      realizedAt: timestamp("realizedAt"),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      tenantIdx: index("recovery_events_tenant_idx").on(t2.tenantId),
      leadIdx: index("recovery_events_lead_idx").on(t2.tenantId, t2.leadId),
      trackingTokenIdx: uniqueIndex("recovery_events_tracking_token_idx").on(t2.trackingToken),
      statusIdx: index("recovery_events_status_idx").on(t2.tenantId, t2.status),
      automationIdx: index("recovery_events_automation_idx").on(t2.tenantId, t2.automationId),
      realizedAtIdx: index("recovery_events_realized_at_idx").on(t2.tenantId, t2.realizedAt)
    }));
    featureConfigs = mysqlTable("feature_configs", {
      id: int("id").autoincrement().primaryKey(),
      tenantId: int("tenantId").notNull(),
      feature: varchar("feature", { length: 100 }).notNull(),
      config: json("config").$type().notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      tenantFeatureIdx: uniqueIndex("feature_configs_tenant_feature_idx").on(t2.tenantId, t2.feature)
    }));
  }
});

// server/db.ts
var db_exports = {};
__export(db_exports, {
  getDb: () => getDb,
  pingDb: () => pingDb
});
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
async function getDb() {
  if (_db) return _db;
  const dbUrl = process.env.DATABASE_URL || process.env.RAILWAY_URL || "mysql://root:example@db:3306/rebooked";
  _pool = mysql.createPool({
    uri: dbUrl,
    waitForConnections: true,
    connectionLimit: parseInt(process.env.DB_POOL_SIZE || "10", 10),
    queueLimit: 50,
    enableKeepAlive: true,
    keepAliveInitialDelay: 1e4,
    connectTimeout: 1e4,
    ...process.env.DB_SSL !== "false" && !dbUrl.includes("localhost") && !dbUrl.includes("127.0.0.1") ? { ssl: { rejectUnauthorized: false } } : {}
  });
  _db = drizzle(_pool, { schema: schema_exports, mode: "default" });
  return _db;
}
async function pingDb() {
  try {
    if (!_pool) await getDb();
    const pool = _pool;
    if (!pool) return false;
    const conn = await pool.getConnection();
    await conn.ping();
    conn.release();
    return true;
  } catch {
    return false;
  }
}
var _pool, _db;
var init_db = __esm({
  "server/db.ts"() {
    init_schema();
    _pool = null;
    _db = null;
  }
});

// server/_core/env.ts
var ENV;
var init_env = __esm({
  "server/_core/env.ts"() {
    ENV = {
      databaseUrl: process.env.DATABASE_URL ?? process.env.RAILWAY_URL ?? "mysql://root:example@db:3306/rebooked",
      ownerOpenId: process.env.OWNER_OPEN_ID ?? "placeholder",
      appId: process.env.VITE_APP_ID ?? "rebooked",
      oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "http://localhost:3000",
      cookieSecret: process.env.JWT_SECRET ?? process.env.COOKIE_SECRET ?? "rebooked-salt",
      forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? process.env.FORGE_API_URL ?? "",
      forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? process.env.FORGE_API_KEY ?? "",
      sendGridApiKey: process.env.SENDGRID_API_KEY ?? "",
      emailFromAddress: process.env.EMAIL_FROM_ADDRESS ?? "hello@rebooked.com",
      encryptionKey: process.env.ENCRYPTION_KEY ?? "",
      sentryDsn: process.env.SENTRY_DSN ?? "",
      webhookSecret: process.env.WEBHOOK_SECRET ?? "",
      telnyxApiKey: process.env.TELNYX_API_KEY ?? "",
      telnyxFromNumber: process.env.TELNYX_FROM_NUMBER ?? "",
      twilioAccountSid: process.env.TWILIO_ACCOUNT_SID ?? "",
      twilioAuthToken: process.env.TWILIO_AUTH_TOKEN ?? "",
      twilioFromNumber: process.env.TWILIO_FROM_NUMBER ?? "",
      // Stripe - CRITICAL FOR BILLING
      stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? "",
      stripePublishableKey: process.env.STRIPE_PUBLISHABLE_KEY ?? "",
      stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET ?? "",
      stripeFixedPriceId: process.env.STRIPE_FIXED_PRICE_ID ?? "price_FIXED_199",
      stripeMeteredPriceId: process.env.STRIPE_METERED_PRICE_ID ?? "price_METERED_15",
      frontendUrl: process.env.FRONTEND_URL ?? "http://localhost:3000",
      backendUrl: process.env.BACKEND_URL ?? "http://localhost:3001",
      // Referral System
      referralRewardAmount: parseInt(process.env.REFERRAL_REWARD_AMOUNT ?? "50"),
      referralMinimumMonths: parseInt(process.env.REFERRAL_MINIMUM_MONTHS ?? "6"),
      referralExpiryDays: parseInt(process.env.REFERRAL_EXPIRY_DAYS ?? "90"),
      referralProgramEnabled: process.env.REFERRAL_PROGRAM_ENABLED === "true"
    };
  }
});

// server/_core/appErrors.ts
function isAppError(error) {
  return error instanceof AppError;
}
var AppError;
var init_appErrors = __esm({
  "server/_core/appErrors.ts"() {
    AppError = class extends Error {
      code;
      statusCode;
      retryable;
      constructor(code, message, statusCode = 400, retryable = false) {
        super(message);
        this.name = "AppError";
        this.code = code;
        this.statusCode = statusCode;
        this.retryable = retryable;
      }
    };
  }
});

// server/_core/requestContext.ts
import { AsyncLocalStorage } from "async_hooks";
import { randomUUID } from "crypto";
function runWithCorrelationId(correlationId, fn) {
  return storage.run({ correlationId: correlationId || randomUUID() }, fn);
}
function getCorrelationId() {
  return storage.getStore()?.correlationId;
}
function ensureCorrelationId(existing) {
  return existing || getCorrelationId() || randomUUID();
}
var storage;
var init_requestContext = __esm({
  "server/_core/requestContext.ts"() {
    storage = new AsyncLocalStorage();
  }
});

// server/_core/logger.ts
function emit(level, message, meta) {
  const entry = {
    ts: (/* @__PURE__ */ new Date()).toISOString(),
    level,
    message,
    correlationId: getCorrelationId(),
    ...meta
  };
  if (isProd) {
    const out = level === "error" || level === "warn" ? process.stderr : process.stdout;
    out.write(JSON.stringify(entry) + "\n");
  } else {
    const colors = {
      debug: "\x1B[90m",
      info: "\x1B[36m",
      warn: "\x1B[33m",
      error: "\x1B[31m"
    };
    const reset = "\x1B[0m";
    const prefix = `${colors[level]}[${level.toUpperCase()}]${reset}`;
    const metaStr = meta ? " " + JSON.stringify(meta) : "";
    const fn = level === "error" ? console.error : level === "warn" ? console.warn : console.log;
    fn(`${prefix} ${message}${metaStr}`);
  }
}
var isProd, logger;
var init_logger = __esm({
  "server/_core/logger.ts"() {
    init_requestContext();
    isProd = process.env.NODE_ENV === "production";
    logger = {
      debug: (msg, meta) => emit("debug", msg, meta),
      info: (msg, meta) => emit("info", msg, meta),
      warn: (msg, meta) => emit("warn", msg, meta),
      error: (msg, meta) => emit("error", msg, meta)
    };
  }
});

// server/services/rateLimit.service.ts
import { and as and2, eq as eq3, gte, ne, sql as sql2 } from "drizzle-orm";
async function assertSmsHourlyDailyLimits(db, tenantId) {
  const hourlyCap = parseInt(process.env.SMS_HOURLY_CAP || "0", 10);
  const dailyCap = parseInt(process.env.SMS_DAILY_CAP_PER_TENANT || "0", 10);
  if (hourlyCap <= 0 && dailyCap <= 0) return;
  const sinceHour = new Date(Date.now() - 60 * 60 * 1e3);
  const sinceDay = /* @__PURE__ */ new Date();
  sinceDay.setHours(0, 0, 0, 0);
  if (hourlyCap > 0) {
    const [{ c }] = await db.select({ c: sql2`count(*)` }).from(messages).where(
      and2(
        eq3(messages.tenantId, tenantId),
        eq3(messages.direction, "outbound"),
        ne(messages.status, "failed"),
        gte(messages.createdAt, sinceHour)
      )
    );
    if (Number(c) >= hourlyCap) {
      throw new AppError("RATE_LIMITED", `Hourly SMS limit exceeded (${hourlyCap}/hour)`, 429);
    }
  }
  if (dailyCap > 0) {
    const [{ c }] = await db.select({ c: sql2`count(*)` }).from(messages).where(
      and2(
        eq3(messages.tenantId, tenantId),
        eq3(messages.direction, "outbound"),
        ne(messages.status, "failed"),
        gte(messages.createdAt, sinceDay)
      )
    );
    if (Number(c) >= dailyCap) {
      throw new AppError("RATE_LIMITED", `Daily SMS limit exceeded (${dailyCap}/day)`, 429);
    }
  }
}
async function assertSmsRateLimitAvailable(db, tenantId) {
  const windowStart = /* @__PURE__ */ new Date();
  windowStart.setSeconds(0, 0);
  const bucket = windowStart;
  const maxPerMinute = parseInt(process.env.SMS_RATE_LIMIT || "60", 10);
  const [row] = await db.select().from(smsRateLimits).where(and2(eq3(smsRateLimits.tenantId, tenantId), eq3(smsRateLimits.windowStart, bucket))).limit(1);
  if (row && row.count >= maxPerMinute) {
    throw new AppError("RATE_LIMITED", `Rate limit exceeded (${maxPerMinute} SMS/min)`, 429);
  }
  if (row) {
    await db.update(smsRateLimits).set({ count: row.count + 1, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(smsRateLimits.id, row.id));
  } else {
    await db.insert(smsRateLimits).values({
      tenantId,
      windowStart: bucket,
      count: 1,
      updatedAt: /* @__PURE__ */ new Date()
    });
  }
}
var init_rateLimit_service = __esm({
  "server/services/rateLimit.service.ts"() {
    init_schema();
    init_appErrors();
  }
});

// server/services/usage.service.ts
import { and as and3, desc as desc3, eq as eq4, sql as sql3 } from "drizzle-orm";
async function getTenantUsageState(db, tenantId) {
  const [usageRow] = await db.select().from(usage).where(eq4(usage.tenantId, tenantId)).orderBy(desc3(usage.periodStart)).limit(1);
  const [subscriptionRow] = await db.select({ sub: subscriptions, plan: plans }).from(subscriptions).innerJoin(plans, eq4(subscriptions.planId, plans.id)).where(and3(eq4(subscriptions.tenantId, tenantId), eq4(subscriptions.status, "active"))).orderBy(desc3(subscriptions.createdAt)).limit(1);
  return {
    usage: usageRow,
    subscription: subscriptionRow?.sub,
    plan: subscriptionRow?.plan
  };
}
async function assertUsageCapAvailable(db, tenantId) {
  const state = await getTenantUsageState(db, tenantId);
  const cap = state.plan?.maxMessages ?? 0;
  const used = state.usage?.messagesSent ?? 0;
  if (cap > 0 && used >= cap) {
    throw new AppError("USAGE_CAP_EXCEEDED", "Monthly SMS usage cap exceeded", 429);
  }
  return { cap, used };
}
async function incrementOutboundUsageIfAllowed(db, tenantId) {
  const state = await getTenantUsageState(db, tenantId);
  const cap = state.plan?.maxMessages ?? 0;
  const usageRow = state.usage;
  if (!usageRow) return false;
  if (cap === 0) {
    await db.update(usage).set({ messagesSent: sql3`${usage.messagesSent} + 1`, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(usage.id, usageRow.id));
    return true;
  }
  const result = await db.execute(sql3`
    UPDATE usage u
    INNER JOIN subscriptions s ON s.tenantId = u.tenantId AND s.status = 'active'
    INNER JOIN plans p ON p.id = s.planId
    SET u.messagesSent = u.messagesSent + 1, u.updatedAt = NOW()
    WHERE u.id = ${usageRow.id} AND u.tenantId = ${tenantId} AND u.messagesSent < p.maxMessages
  `);
  const header = Array.isArray(result) ? result[0] : result;
  return (header?.affectedRows ?? 0) > 0;
}
var init_usage_service = __esm({
  "server/services/usage.service.ts"() {
    init_schema();
    init_appErrors();
  }
});

// server/_core/sms.ts
var sms_exports = {};
__export(sms_exports, {
  resolveTemplate: () => resolveTemplate,
  sendSMS: () => sendSMS
});
async function fetchSmsProvider(url, init) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), SMS_HTTP_TIMEOUT_MS);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text2 = await response.text();
    let data = {};
    try {
      data = text2 ? JSON.parse(text2) : {};
    } catch {
      data = { raw: text2 };
    }
    return { ok: response.ok, status: response.status, data, text: text2 };
  } catch (error) {
    const msg = error instanceof Error && error.name === "AbortError" ? `SMS request timed out after ${SMS_HTTP_TIMEOUT_MS}ms` : String(error);
    logger.warn("SMS provider fetch failed", { url, error: msg });
    return { ok: false, status: 0, data: {}, text: msg };
  } finally {
    clearTimeout(timer);
  }
}
async function guardOutboundSend(tenantId) {
  if (!tenantId) return null;
  try {
    const db = await getDb();
    if (db) {
      await assertSmsRateLimitAvailable(db, tenantId);
      await assertSmsHourlyDailyLimits(db, tenantId);
      await assertUsageCapAvailable(db, tenantId);
    }
    return null;
  } catch (error) {
    if (isAppError(error)) {
      logger.warn("SMS blocked before provider call", { tenantId, code: error.code, message: error.message });
      return {
        success: false,
        error: error.message,
        errorCode: error.code
      };
    }
    throw error;
  }
}
async function sendViaTelnyx(to, body, from) {
  const { ok, data, text: text2 } = await fetchSmsProvider("https://api.telnyx.com/v2/messages", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${ENV.telnyxApiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ from, to, text: body })
  });
  const d = data;
  if (!ok) {
    const message = d?.errors?.[0]?.detail || d?.message || text2 || "Telnyx request failed";
    logger.warn("Telnyx send failed", { to, error: message });
    return { success: false, error: message, provider: "telnyx", errorCode: "TELNYX_ERROR" };
  }
  return { success: true, sid: d?.data?.id, provider: "telnyx" };
}
async function sendViaTwilio(to, body, from) {
  const auth = Buffer.from(`${ENV.twilioAccountSid}:${ENV.twilioAuthToken}`).toString("base64");
  const { ok, data, text: text2 } = await fetchSmsProvider(
    `https://api.twilio.com/2010-04-01/Accounts/${ENV.twilioAccountSid}/Messages.json`,
    {
      method: "POST",
      headers: {
        Authorization: `Basic ${auth}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({ From: from, To: to, Body: body }).toString()
    }
  );
  const d = data;
  if (!ok) {
    const message = d?.message || text2 || "Twilio request failed";
    logger.warn("Twilio send failed", { to, error: message });
    return { success: false, error: message, provider: "twilio", errorCode: "TWILIO_ERROR" };
  }
  return { success: true, sid: d?.sid, provider: "twilio" };
}
async function sendSMS(to, body, from, tenantId) {
  const guardResult = await guardOutboundSend(tenantId);
  if (guardResult) return guardResult;
  if (ENV.telnyxApiKey) {
    const fromNumber = from || ENV.telnyxFromNumber;
    if (!fromNumber) {
      logger.warn("TELNYX_FROM_NUMBER not set");
    } else {
      return sendViaTelnyx(to, body, fromNumber);
    }
  }
  if (ENV.twilioAccountSid && ENV.twilioAuthToken) {
    const fromNumber = from || ENV.twilioFromNumber;
    if (!fromNumber) {
      logger.warn("TWILIO_FROM_NUMBER not set");
    } else {
      return sendViaTwilio(to, body, fromNumber);
    }
  }
  if (process.env.NODE_ENV === "production") {
    logger.error("No SMS provider configured in production \u2014 message not sent", { to });
    return { success: false, error: "No SMS provider configured", provider: "none" };
  }
  logger.warn("No SMS provider configured (dev mode \u2014 faking success)", { to });
  return { success: true, sid: `dev_${Date.now()}`, provider: "dev" };
}
function resolveTemplate(template, vars) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    const val = vars[key];
    return val != null ? String(val) : "";
  });
}
var SMS_HTTP_TIMEOUT_MS;
var init_sms = __esm({
  "server/_core/sms.ts"() {
    init_env();
    init_appErrors();
    init_logger();
    init_db();
    init_rateLimit_service();
    init_usage_service();
    SMS_HTTP_TIMEOUT_MS = parseInt(process.env.SMS_HTTP_TIMEOUT_MS || "30000", 10);
  }
});

// server/services/query.service.ts
async function withQueryTimeout(label, work, timeoutMs = parseInt(process.env.DB_QUERY_TIMEOUT_MS || "5000", 10)) {
  let timer;
  try {
    return await Promise.race([
      work,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label} timed out after ${timeoutMs}ms`)), timeoutMs);
      })
    ]);
  } catch (error) {
    logger.warn("Query timeout or failure", { label, error: String(error) });
    throw error;
  } finally {
    if (timer) clearTimeout(timer);
  }
}
var init_query_service = __esm({
  "server/services/query.service.ts"() {
    init_logger();
  }
});

// server/services/referral.service.ts
var referral_service_exports = {};
__export(referral_service_exports, {
  cleanupExpiredReferrals: () => cleanupExpiredReferrals,
  completeReferral: () => completeReferral,
  generateReferralCode: () => generateReferralCode,
  getReferralLeaderboard: () => getReferralLeaderboard,
  getReferralStats: () => getReferralStats,
  getUserPayouts: () => getUserPayouts,
  getUserReferrals: () => getUserReferrals,
  processReferral: () => processReferral,
  processScheduledPayouts: () => processScheduledPayouts,
  requestPayout: () => requestPayout
});
import { TRPCError as TRPCError2 } from "@trpc/server";
import { and as and15, eq as eq16, isNull as isNull6, lte as lte4, lt, sql as sql12, desc as desc11 } from "drizzle-orm";
import Stripe2 from "stripe";
async function generateReferralCode(userId) {
  const db = await getDb();
  const existingReferral = await db.select({
    referralCode: referrals.referralCode
  }).from(referrals).where(and15(
    eq16(referrals.referrerId, userId),
    sql12`${referrals.status} IN ('pending', 'completed')`
  )).limit(1);
  if (existingReferral.length > 0) {
    return existingReferral[0].referralCode;
  }
  let code = "";
  let isUnique = false;
  let attempts = 0;
  while (!isUnique && attempts < 10) {
    code = Math.random().toString(36).substring(2, 2 + REFERRAL_CODE_LENGTH).toUpperCase();
    const existing = await db.select({ id: referrals.id }).from(referrals).where(eq16(referrals.referralCode, code)).limit(1);
    isUnique = existing.length === 0;
    attempts++;
  }
  if (!isUnique) {
    throw new Error("Failed to generate unique referral code");
  }
  const expiresAt = /* @__PURE__ */ new Date();
  expiresAt.setDate(expiresAt.getDate() + REFERRAL_EXPIRY_DAYS);
  await db.insert(referrals).values({
    referrerId: userId,
    referredUserId: 0,
    // Placeholder until someone uses the code
    referralCode: code,
    status: "pending",
    rewardAmount: REFERRAL_REWARD_AMOUNT,
    rewardCurrency: "USD",
    expiresAt
  });
  return code;
}
async function processReferral(referralCode, referredUserId) {
  const db = await getDb();
  const matchingReferrals = await db.select({
    id: referrals.id,
    referrerId: referrals.referrerId,
    referralCode: referrals.referralCode,
    status: referrals.status,
    expiresAt: referrals.expiresAt,
    rewardAmount: referrals.rewardAmount,
    rewardCurrency: referrals.rewardCurrency
  }).from(referrals).where(and15(
    eq16(referrals.referralCode, referralCode),
    eq16(referrals.status, "pending")
  )).limit(1);
  if (matchingReferrals.length === 0) {
    return { success: false, message: "Invalid or expired referral code" };
  }
  const referral = matchingReferrals[0];
  if (referral.expiresAt && /* @__PURE__ */ new Date() > referral.expiresAt) {
    await db.update(referrals).set({ status: "expired" }).where(eq16(referrals.id, referral.id));
    return { success: false, message: "Referral code has expired" };
  }
  if (referral.referrerId === referredUserId) {
    return { success: false, message: "Cannot use your own referral code" };
  }
  const existingReferral = await db.select({ id: referrals.id }).from(referrals).where(and15(
    eq16(referrals.referredUserId, referredUserId),
    sql12`${referrals.status} IN ('pending', 'completed')`
  )).limit(1);
  if (existingReferral.length > 0) {
    return { success: false, message: "User has already used a referral code" };
  }
  await db.update(referrals).set({ referredUserId }).where(eq16(referrals.id, referral.id));
  return {
    success: true,
    referralId: referral.id
  };
}
async function completeReferral(referralId, subscriptionId, subscriptionMonths) {
  const db = await getDb();
  if (subscriptionMonths < MIN_SUBSCRIPTION_MONTHS) {
    throw new TRPCError2({
      code: "BAD_REQUEST",
      message: `Subscription must be at least ${MIN_SUBSCRIPTION_MONTHS} months for referral reward`
    });
  }
  const payoutScheduledDate = /* @__PURE__ */ new Date();
  payoutScheduledDate.setMonth(payoutScheduledDate.getMonth() + 1);
  await db.update(referrals).set({
    status: "completed",
    subscriptionId,
    completedAt: /* @__PURE__ */ new Date(),
    payoutScheduledAt: payoutScheduledDate
  }).where(eq16(referrals.id, referralId));
}
async function processScheduledPayouts() {
  const db = await getDb();
  const dueReferrals = await db.select({
    id: referrals.id,
    referrerId: referrals.referrerId,
    rewardAmount: referrals.rewardAmount,
    referredUserId: referrals.referredUserId
  }).from(referrals).where(and15(
    eq16(referrals.status, "completed"),
    lte4(referrals.payoutScheduledAt, /* @__PURE__ */ new Date()),
    isNull6(referrals.payoutProcessedAt)
  ));
  let processed = 0;
  for (const referral of dueReferrals) {
    let tenantId = null;
    try {
      const userResults = await db.select({
        stripeCustomerId: users.stripeCustomerId,
        tenantId: users.tenantId
      }).from(users).where(eq16(users.id, referral.referrerId)).limit(1);
      const referrer = userResults[0];
      if (referrer && referrer.tenantId) {
        tenantId = referrer.tenantId;
      }
      if (!referrer?.stripeCustomerId) {
        throw new Error(`No Stripe account for referrer ${referral.referrerId}`);
      }
      const payout = await stripe2.transfers.create({
        amount: referral.rewardAmount * 100,
        currency: "usd",
        destination: referrer.stripeCustomerId,
        description: `Referral payout for referred user ${referral.referredUserId}`,
        metadata: {
          referralId: String(referral.id),
          type: "referral_payout"
        }
      });
      await db.insert(referralPayouts).values({
        userId: referral.referrerId,
        amount: referral.rewardAmount,
        transactionId: payout.id,
        status: "completed",
        method: "stripe",
        processedAt: /* @__PURE__ */ new Date()
      });
      await db.update(referrals).set({ payoutProcessedAt: /* @__PURE__ */ new Date() }).where(eq16(referrals.id, referral.id));
      processed++;
    } catch (error) {
      console.error(`Failed to process payout for referral ${referral.id}:`, error);
      await db.insert(systemErrorLogs).values({
        type: "billing",
        message: `Failed to process payout for referral ${referral.id}`,
        detail: error.message,
        tenantId
      });
    }
  }
  return { processed, total: dueReferrals.length };
}
async function getReferralStats(userId) {
  const db = await getDb();
  const allReferrals = await db.select({
    status: referrals.status,
    rewardAmount: referrals.rewardAmount
  }).from(referrals).where(eq16(referrals.referrerId, userId));
  const completed = allReferrals.filter((r) => r.status === "completed");
  const pending = allReferrals.filter((r) => r.status === "pending");
  const payouts = await db.select({
    amount: referralPayouts.amount
  }).from(referralPayouts).where(and15(
    eq16(referralPayouts.userId, userId),
    eq16(referralPayouts.status, "completed")
  ));
  const totalPaidOut = payouts.reduce((sum, p) => sum + p.amount, 0);
  const totalEarned = completed.reduce((sum, r) => sum + r.rewardAmount, 0);
  const availableForPayout = totalEarned - totalPaidOut;
  return {
    totalReferrals: allReferrals.length,
    completedReferrals: completed.length,
    pendingReferrals: pending.length,
    totalEarned,
    availableForPayout,
    lifetimeEarnings: totalEarned
  };
}
async function getUserReferrals(userId, limit = 10) {
  const db = await getDb();
  return await db.select({
    id: referrals.id,
    referredUserId: referrals.referredUserId,
    referralCode: referrals.referralCode,
    status: referrals.status,
    rewardAmount: referrals.rewardAmount,
    rewardCurrency: referrals.rewardCurrency,
    createdAt: referrals.createdAt,
    completedAt: referrals.completedAt,
    expiresAt: referrals.expiresAt,
    metadata: referrals.metadata
  }).from(referrals).where(eq16(referrals.referrerId, userId)).orderBy(desc11(referrals.createdAt)).limit(limit);
}
async function requestPayout(userId, method) {
  const db = await getDb();
  const stats = await getReferralStats(userId);
  if (stats.availableForPayout <= 0) {
    throw new TRPCError2({
      code: "BAD_REQUEST",
      message: "No available earnings for payout"
    });
  }
  await db.insert(referralPayouts).values({
    userId,
    amount: stats.availableForPayout,
    currency: "USD",
    method,
    status: "pending"
  });
  const [payout] = await db.select().from(referralPayouts).where(and15(
    eq16(referralPayouts.userId, userId),
    eq16(referralPayouts.status, "pending")
  )).orderBy(desc11(referralPayouts.createdAt)).limit(1);
  return payout;
}
async function getUserPayouts(userId) {
  const db = await getDb();
  return await db.select({
    id: referralPayouts.id,
    amount: referralPayouts.amount,
    currency: referralPayouts.currency,
    status: referralPayouts.status,
    method: referralPayouts.method,
    createdAt: referralPayouts.createdAt,
    processedAt: referralPayouts.processedAt,
    transactionId: referralPayouts.transactionId
  }).from(referralPayouts).where(eq16(referralPayouts.userId, userId)).orderBy(desc11(referralPayouts.createdAt));
}
async function cleanupExpiredReferrals() {
  const db = await getDb();
  await db.update(referrals).set({ status: "expired" }).where(and15(
    lt(referrals.expiresAt, /* @__PURE__ */ new Date()),
    eq16(referrals.status, "pending")
  ));
  const expired = await db.select({ count: sql12`count(*)` }).from(referrals).where(eq16(referrals.status, "expired"));
  return Number(expired[0]?.count ?? 0);
}
async function getReferralLeaderboard(limit = 10, timeframe = "all") {
  const db = await getDb();
  const conditions = [eq16(referrals.status, "completed")];
  if (timeframe === "month") {
    const monthStart = /* @__PURE__ */ new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);
    conditions.push(sql12`${referrals.completedAt} >= ${monthStart}`);
  } else if (timeframe === "year") {
    const yearStart = /* @__PURE__ */ new Date();
    yearStart.setMonth(0, 1);
    yearStart.setHours(0, 0, 0, 0);
    conditions.push(sql12`${referrals.completedAt} >= ${yearStart}`);
  }
  const safeLimit = Math.min(Math.max(1, limit), 50);
  const results = await db.select({
    userId: referrals.referrerId,
    totalReferrals: sql12`count(*)`,
    totalEarned: sql12`COALESCE(SUM(${referrals.rewardAmount}), 0)`
  }).from(referrals).where(and15(...conditions)).groupBy(referrals.referrerId).orderBy(sql12`totalEarned DESC`).limit(safeLimit);
  return results.map((r) => ({
    userId: r.userId,
    totalReferrals: Number(r.totalReferrals),
    totalEarned: Number(r.totalEarned)
  }));
}
var stripe2, REFERRAL_REWARD_AMOUNT, REFERRAL_EXPIRY_DAYS, MIN_SUBSCRIPTION_MONTHS, REFERRAL_CODE_LENGTH;
var init_referral_service = __esm({
  "server/services/referral.service.ts"() {
    init_db();
    init_schema();
    init_env();
    stripe2 = new Stripe2(ENV.stripeSecretKey || "", { apiVersion: "2022-11-15" });
    REFERRAL_REWARD_AMOUNT = 50;
    REFERRAL_EXPIRY_DAYS = 90;
    MIN_SUBSCRIPTION_MONTHS = 6;
    REFERRAL_CODE_LENGTH = 8;
  }
});

// server/_core/llm.ts
import { and as and17, eq as eq19 } from "drizzle-orm";
async function readResponseTextWithTimeout(response, ms) {
  let timer;
  try {
    return await Promise.race([
      response.text(),
      new Promise((_, reject) => {
        timer = setTimeout(
          () => reject(new AppError("LLM_TIMEOUT", `Response body exceeded ${ms}ms`, 504, true)),
          ms
        );
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
async function getBreakerState() {
  const db = await getDb();
  if (!db) return { db: null, breaker: null };
  const [breaker] = await db.select().from(llmCircuitBreakers).where(and17(eq19(llmCircuitBreakers.provider, "forge"), eq19(llmCircuitBreakers.model, MODEL))).limit(1);
  return { db, breaker };
}
async function assertCircuitAvailable() {
  const { db, breaker } = await getBreakerState();
  if (!db || !breaker) return;
  if (breaker.state !== "open") return;
  const cooldownUntil = breaker.cooldownUntil ? new Date(breaker.cooldownUntil).getTime() : 0;
  if (cooldownUntil > Date.now()) {
    throw new AppError("LLM_CIRCUIT_OPEN", "AI rewrite temporarily unavailable", 503, true);
  }
  await db.update(llmCircuitBreakers).set({ state: "half_open", updatedAt: /* @__PURE__ */ new Date() }).where(eq19(llmCircuitBreakers.id, breaker.id));
}
async function recordCircuitResult(success) {
  const { db, breaker } = await getBreakerState();
  if (!db) return;
  if (success) {
    const payload2 = {
      provider: "forge",
      model: MODEL,
      state: "closed",
      consecutiveFailures: 0,
      openedAt: null,
      cooldownUntil: null,
      updatedAt: /* @__PURE__ */ new Date()
    };
    if (breaker) {
      await db.update(llmCircuitBreakers).set(payload2).where(eq19(llmCircuitBreakers.id, breaker.id));
    } else {
      await db.insert(llmCircuitBreakers).values(payload2);
    }
    return;
  }
  const nextFailures = (breaker?.consecutiveFailures || 0) + 1;
  const shouldOpen = nextFailures >= LLM_BREAKER_THRESHOLD;
  const payload = {
    provider: "forge",
    model: MODEL,
    state: shouldOpen ? "open" : "closed",
    consecutiveFailures: nextFailures,
    openedAt: shouldOpen ? /* @__PURE__ */ new Date() : null,
    cooldownUntil: shouldOpen ? new Date(Date.now() + LLM_BREAKER_COOLDOWN_MS) : null,
    updatedAt: /* @__PURE__ */ new Date()
  };
  if (breaker) {
    await db.update(llmCircuitBreakers).set(payload).where(eq19(llmCircuitBreakers.id, breaker.id));
  } else {
    await db.insert(llmCircuitBreakers).values(payload);
  }
}
async function invokeLLM(params) {
  assertApiKey();
  await assertCircuitAvailable();
  const { messages: messages5, tools, toolChoice, tool_choice, outputSchema, output_schema, responseFormat, response_format } = params;
  const payload = {
    model: MODEL,
    messages: messages5.map(normalizeMessage)
  };
  if (tools?.length) payload.tools = tools;
  const normalizedToolChoice = normalizeToolChoice(toolChoice || tool_choice, tools);
  if (normalizedToolChoice) payload.tool_choice = normalizedToolChoice;
  payload.max_tokens = 32768;
  payload.thinking = { budget_tokens: 128 };
  const normalizedResponseFormat = normalizeResponseFormat({
    responseFormat,
    response_format,
    outputSchema,
    output_schema
  });
  if (normalizedResponseFormat) payload.response_format = normalizedResponseFormat;
  let lastError;
  for (let attempt = 1; attempt <= LLM_MAX_ATTEMPTS; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), LLM_TIMEOUT_MS);
    try {
      const response = await fetch(resolveApiUrl(), {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${ENV.forgeApiKey}`
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      if (!response.ok) {
        const errorText = await readResponseTextWithTimeout(response, LLM_TIMEOUT_MS);
        throw new AppError(
          "LLM_UPSTREAM_ERROR",
          `LLM invoke failed: ${response.status} ${response.statusText} - ${errorText}`,
          502,
          true
        );
      }
      const bodyText = await readResponseTextWithTimeout(response, LLM_TIMEOUT_MS);
      let result;
      try {
        result = JSON.parse(bodyText);
      } catch {
        throw new AppError("LLM_UPSTREAM_ERROR", "LLM returned invalid JSON", 502, true);
      }
      await recordCircuitResult(true);
      return result;
    } catch (error) {
      lastError = error;
      await recordCircuitResult(false);
      logger.warn("LLM invocation attempt failed", {
        attempt,
        timeout: error instanceof Error && error.name === "AbortError",
        error: String(error)
      });
      if (attempt >= LLM_MAX_ATTEMPTS) break;
    } finally {
      clearTimeout(timer);
    }
  }
  if (lastError instanceof AppError) throw lastError;
  if (lastError instanceof Error && lastError.name === "AbortError") {
    throw new AppError("LLM_TIMEOUT", `LLM timed out after ${LLM_TIMEOUT_MS}ms`, 504, true);
  }
  throw new AppError("LLM_UPSTREAM_ERROR", "LLM request failed", 502, true);
}
var MODEL, LLM_TIMEOUT_MS, LLM_MAX_ATTEMPTS, LLM_BREAKER_THRESHOLD, LLM_BREAKER_COOLDOWN_MS, ensureArray, normalizeContentPart, normalizeMessage, normalizeToolChoice, resolveApiUrl, assertApiKey, normalizeResponseFormat;
var init_llm = __esm({
  "server/_core/llm.ts"() {
    init_schema();
    init_env();
    init_appErrors();
    init_logger();
    init_db();
    MODEL = "gemini-2.5-flash";
    LLM_TIMEOUT_MS = parseInt(process.env.LLM_TIMEOUT_MS || "15000", 10);
    LLM_MAX_ATTEMPTS = parseInt(process.env.LLM_MAX_ATTEMPTS || "2", 10);
    LLM_BREAKER_THRESHOLD = parseInt(process.env.LLM_BREAKER_THRESHOLD || "3", 10);
    LLM_BREAKER_COOLDOWN_MS = parseInt(process.env.LLM_BREAKER_COOLDOWN_MS || "60000", 10);
    ensureArray = (value) => Array.isArray(value) ? value : [value];
    normalizeContentPart = (part) => {
      if (typeof part === "string") return { type: "text", text: part };
      if (part.type === "text" || part.type === "image_url" || part.type === "file_url") return part;
      throw new Error("Unsupported message content part");
    };
    normalizeMessage = (message) => {
      const { role, name, tool_call_id } = message;
      if (role === "tool" || role === "function") {
        const content = ensureArray(message.content).map((part) => typeof part === "string" ? part : JSON.stringify(part)).join("\n");
        return { role, name, tool_call_id, content };
      }
      const contentParts = ensureArray(message.content).map(normalizeContentPart);
      if (contentParts.length === 1 && contentParts[0].type === "text") {
        return { role, name, content: contentParts[0].text };
      }
      return { role, name, content: contentParts };
    };
    normalizeToolChoice = (toolChoice, tools) => {
      if (!toolChoice) return void 0;
      if (toolChoice === "none" || toolChoice === "auto") return toolChoice;
      if (toolChoice === "required") {
        if (!tools || tools.length !== 1) {
          throw new Error("tool_choice 'required' needs exactly one configured tool");
        }
        return { type: "function", function: { name: tools[0].function.name } };
      }
      if ("name" in toolChoice) {
        return { type: "function", function: { name: toolChoice.name } };
      }
      return toolChoice;
    };
    resolveApiUrl = () => ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0 ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions` : "https://forge.manus.im/v1/chat/completions";
    assertApiKey = () => {
      if (!ENV.forgeApiKey) {
        throw new Error("OPENAI_API_KEY is not configured");
      }
    };
    normalizeResponseFormat = ({
      responseFormat,
      response_format,
      outputSchema,
      output_schema
    }) => {
      const explicitFormat = responseFormat || response_format;
      if (explicitFormat) {
        if (explicitFormat.type === "json_schema" && !explicitFormat.json_schema?.schema) {
          throw new Error("responseFormat json_schema requires a defined schema object");
        }
        return explicitFormat;
      }
      const schema = outputSchema || output_schema;
      if (!schema) return void 0;
      if (!schema.name || !schema.schema) {
        throw new Error("outputSchema requires both name and schema");
      }
      return {
        type: "json_schema",
        json_schema: {
          name: schema.name,
          schema: schema.schema,
          ...typeof schema.strict === "boolean" ? { strict: schema.strict } : {}
        }
      };
    };
  }
});

// server/services/ai.ts
var ai_exports = {};
__export(ai_exports, {
  rewriteMessage: () => rewriteMessage
});
async function rewriteMessage(message, tone) {
  const result = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `Expert SMS copywriter. Rewrite in ${tone ?? "friendly"} tone. Under 160 chars. Return ONLY the message.`
      },
      { role: "user", content: message }
    ]
  });
  const content = result.choices?.[0]?.message?.content || result.text || "";
  return content.trim();
}
var init_ai = __esm({
  "server/services/ai.ts"() {
    init_llm();
  }
});

// server/services/revenue-leakage.service.ts
var revenue_leakage_service_exports = {};
__export(revenue_leakage_service_exports, {
  detectRevenueLeakage: () => detectRevenueLeakage
});
import { eq as eq25, and as and23, sql as sql14, desc as desc14, isNotNull as isNotNull4, lt as lt3, gte as gte5, or as or3 } from "drizzle-orm";
async function detectRevenueLeakage(db, tenantId, days = 90) {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3);
  const ninetyDaysAgo = new Date(Date.now() - days * 24 * 60 * 60 * 1e3);
  const [
    noShows,
    cancellations,
    lastMinuteCancellations,
    doubleBookings,
    underbookedSlots,
    missedFollowups,
    abandonedLeads,
    expiredLeads
  ] = await withQueryTimeout("revenue-leakage.detection", Promise.all([
    // No-shows (booked appointments that were missed)
    detectNoShows(db, tenantId, thirtyDaysAgo),
    // Cancellations (revenue lost to cancellations)
    detectCancellations(db, tenantId, thirtyDaysAgo),
    // Last-minute cancellations (high impact)
    detectLastMinuteCancellations(db, tenantId, thirtyDaysAgo),
    // Double bookings (missed opportunities)
    detectDoubleBookings(db, tenantId, thirtyDaysAgo),
    // Underbooked time slots
    detectUnderbookedSlots(db, tenantId, thirtyDaysAgo),
    // Missed follow-ups
    detectMissedFollowups(db, tenantId, thirtyDaysAgo),
    // Abandoned leads (qualified but never booked)
    detectAbandonedLeads(db, tenantId, ninetyDaysAgo),
    // Expired leads (old leads never converted)
    detectExpiredLeads(db, tenantId, ninetyDaysAgo)
  ]));
  const totalLeakage = noShows.estimatedRevenue + cancellations.estimatedRevenue + lastMinuteCancellations.estimatedRevenue + doubleBookings.estimatedRevenue + underbookedSlots.estimatedRevenue + missedFollowups.estimatedRevenue + abandonedLeads.estimatedRevenue + expiredLeads.estimatedRevenue;
  const recoverableRevenue = noShows.estimatedRevenue * noShows.recoveryProbability + cancellations.estimatedRevenue * cancellations.recoveryProbability + lastMinuteCancellations.estimatedRevenue * lastMinuteCancellations.recoveryProbability + doubleBookings.estimatedRevenue * doubleBookings.recoveryProbability + underbookedSlots.estimatedRevenue * underbookedSlots.recoveryProbability + missedFollowups.estimatedRevenue * missedFollowups.recoveryProbability + abandonedLeads.estimatedRevenue * abandonedLeads.recoveryProbability + expiredLeads.estimatedRevenue * expiredLeads.recoveryProbability;
  const recoveryOpportunities = await getRecoveryOpportunities(db, tenantId, thirtyDaysAgo);
  const recommendations = generateRecommendations([
    noShows,
    cancellations,
    lastMinuteCancellations,
    doubleBookings,
    underbookedSlots,
    missedFollowups,
    abandonedLeads,
    expiredLeads
  ]);
  const leakageByMonth = await getLeakageByMonth(db, tenantId, days);
  return {
    totalLeakage,
    recoverableRevenue,
    leakageByType: {
      noShows: noShows.estimatedRevenue,
      cancellations: cancellations.estimatedRevenue,
      lastMinuteCancellations: lastMinuteCancellations.estimatedRevenue,
      doubleBookings: doubleBookings.estimatedRevenue,
      underbookedSlots: underbookedSlots.estimatedRevenue,
      missedFollowups: missedFollowups.estimatedRevenue,
      abandonedLeads: abandonedLeads.estimatedRevenue,
      expiredLeads: expiredLeads.estimatedRevenue
    },
    leakageByMonth,
    topLeakageSources: [
      noShows,
      cancellations,
      lastMinuteCancellations,
      doubleBookings,
      underbookedSlots,
      missedFollowups,
      abandonedLeads,
      expiredLeads
    ].sort((a, b) => b.estimatedRevenue - a.estimatedRevenue).slice(0, 5),
    recoveryOpportunities,
    recommendations
  };
}
async function detectNoShows(db, tenantId, since) {
  const result = await withQueryTimeout("leakage.no-shows", db.select({
    count: sql14`count(*)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    eq25(leads.status, "booked"),
    isNotNull4(leads.appointmentAt),
    lt3(leads.appointmentAt, /* @__PURE__ */ new Date()),
    // Appointment was in the past
    gte5(leads.appointmentAt, since),
    // But within our time window
    sql14`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'no_show') IS NOT NULL`
  )));
  const count = Number(result[0]?.count ?? 0);
  const avgRevenue = 250;
  const estimatedRevenue = count * avgRevenue;
  return {
    id: "no-shows",
    type: "no_show",
    severity: count > 10 ? "high" : count > 5 ? "medium" : "low",
    estimatedRevenue,
    recoveryProbability: 0.65,
    // 65% of no-shows can be recovered
    description: `${count} no-show appointments costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: count,
    timeWindow: "Last 30 days",
    recoveryActions: [
      "Send automated re-scheduling SMS",
      "Offer discount for re-booking",
      "Implement reminder system",
      "Call to re-schedule"
    ]
  };
}
async function detectCancellations(db, tenantId, since) {
  const result = await withQueryTimeout("leakage.cancellations", db.select({
    count: sql14`count(*)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    sql14`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'cancelled') IS NOT NULL`,
    gte5(leads.updatedAt, since)
  )));
  const count = Number(result[0]?.count ?? 0);
  const avgRevenue = 250;
  const estimatedRevenue = count * avgRevenue;
  return {
    id: "cancellations",
    type: "cancellation",
    severity: count > 15 ? "high" : count > 8 ? "medium" : "low",
    estimatedRevenue,
    recoveryProbability: 0.45,
    // 45% of cancellations can be recovered
    description: `${count} cancelled appointments costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: count,
    timeWindow: "Last 30 days",
    recoveryActions: [
      "Send cancellation follow-up survey",
      "Offer alternative time slots",
      "Address cancellation reasons",
      "Implement retention strategy"
    ]
  };
}
async function detectLastMinuteCancellations(db, tenantId, since) {
  const result = await withQueryTimeout("leakage.last-minute-cancellations", db.select({
    count: sql14`count(*)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    sql14`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'cancelled') IS NOT NULL`,
    sql14`${leads.appointmentAt} IS NOT NULL`,
    sql14`TIMESTAMPDIFF(HOUR, ${leads.updatedAt}, ${leads.appointmentAt}) <= 24`,
    gte5(leads.updatedAt, since)
  )));
  const count = Number(result[0]?.count ?? 0);
  const avgRevenue = 300;
  const estimatedRevenue = count * avgRevenue;
  return {
    id: "last-minute-cancellations",
    type: "last_minute",
    severity: count > 5 ? "critical" : count > 2 ? "high" : "medium",
    estimatedRevenue,
    recoveryProbability: 0.25,
    // Harder to recover last-minute cancellations
    description: `${count} last-minute cancellations costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: count,
    timeWindow: "Last 30 days",
    recoveryActions: [
      "Implement cancellation penalty policy",
      "Waitlist management system",
      "Overbooking strategy",
      "Last-minute booking promotions"
    ]
  };
}
async function detectDoubleBookings(db, tenantId, since) {
  const result = await withQueryTimeout("leakage.double-bookings", db.select({
    count: sql14`count(*)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    eq25(leads.status, "booked"),
    isNotNull4(leads.appointmentAt),
    gte5(leads.appointmentAt, since),
    sql14`${leads.appointmentAt} IN (
        SELECT appointmentAt 
        FROM leads l2 
        WHERE l2.tenantId = ${tenantId} 
        AND l2.status = 'booked' 
        AND l2.appointmentAt IS NOT NULL
        AND l2.appointmentAt >= ${since}
        GROUP BY appointmentAt 
        HAVING COUNT(*) > 1
      )`
  )));
  const count = Number(result[0]?.count ?? 0);
  const avgRevenue = 250;
  const estimatedRevenue = count * avgRevenue * 0.5;
  return {
    id: "double-bookings",
    type: "double_booking",
    severity: count > 10 ? "high" : count > 5 ? "medium" : "low",
    estimatedRevenue,
    recoveryProbability: 0.8,
    // High recovery potential with better scheduling
    description: `${count} potential double bookings costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: count,
    timeWindow: "Last 30 days",
    recoveryActions: [
      "Implement calendar integration",
      "Real-time availability checking",
      "Automated conflict detection",
      "Staff scheduling optimization"
    ]
  };
}
async function detectUnderbookedSlots(db, tenantId, since) {
  const totalBookings = await withQueryTimeout("leakage.total-bookings", db.select({ count: sql14`count(*)` }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    eq25(leads.status, "booked"),
    gte5(leads.appointmentAt, since)
  )));
  const totalBookingsCount = Number(totalBookings[0]?.count ?? 0);
  const expectedCapacity = 30;
  const actualCapacity = totalBookingsCount / 30;
  const underbookedSlots = Math.max(0, (1 - actualCapacity) * expectedCapacity);
  const estimatedRevenue = underbookedSlots * 250;
  return {
    id: "underbooked-slots",
    type: "underbooking",
    severity: underbookedSlots > 20 ? "high" : underbookedSlots > 10 ? "medium" : "low",
    estimatedRevenue,
    recoveryProbability: 0.7,
    // Good recovery potential with marketing
    description: `${Math.round(underbookedSlots)} underbooked time slots costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: Math.round(underbookedSlots),
    timeWindow: "Last 30 days",
    recoveryActions: [
      "Launch last-minute booking campaigns",
      "Implement waitlist system",
      "Dynamic pricing for off-peak times",
      "Targeted marketing for slow periods"
    ]
  };
}
async function detectMissedFollowups(db, tenantId, since) {
  const result = await withQueryTimeout("leakage.missed-followups", db.select({
    count: sql14`count(*)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    eq25(leads.status, "qualified"),
    sql14`${leads.lastMessageAt} IS NULL OR ${leads.lastMessageAt} < DATE_SUB(NOW(), INTERVAL 7 DAY)`,
    sql14`${leads.createdAt} >= DATE_SUB(NOW(), INTERVAL 30 DAY)`
  )));
  const count = Number(result[0]?.count ?? 0);
  const avgRevenue = 200;
  const estimatedRevenue = count * avgRevenue * 0.6;
  return {
    id: "missed-followups",
    type: "followup_missed",
    severity: count > 20 ? "high" : count > 10 ? "medium" : "low",
    estimatedRevenue,
    recoveryProbability: 0.85,
    // Very high recovery potential
    description: `${count} qualified leads without follow-up costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: count,
    timeWindow: "Last 30 days",
    recoveryActions: [
      "Automated follow-up sequences",
      "Lead scoring prioritization",
      "Staff reminder system",
      "CRM integration for tracking"
    ]
  };
}
async function detectAbandonedLeads(db, tenantId, since) {
  const result = await withQueryTimeout("leakage.abandoned-leads", db.select({
    count: sql14`count(*)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    eq25(leads.status, "contacted"),
    sql14`${leads.lastMessageAt} < DATE_SUB(NOW(), INTERVAL 14 DAY)`,
    gte5(leads.createdAt, since)
  )));
  const count = Number(result[0]?.count ?? 0);
  const avgRevenue = 150;
  const estimatedRevenue = count * avgRevenue * 0.3;
  return {
    id: "abandoned-leads",
    type: "followup_missed",
    severity: count > 25 ? "high" : count > 15 ? "medium" : "low",
    estimatedRevenue,
    recoveryProbability: 0.6,
    // Moderate recovery potential
    description: `${count} abandoned contacted leads costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: count,
    timeWindow: "Last 90 days",
    recoveryActions: [
      "Re-engagement campaigns",
      "Special offers for abandoned leads",
      "Lead nurturing sequences",
      "Exit interview surveys"
    ]
  };
}
async function detectExpiredLeads(db, tenantId, since) {
  const result = await withQueryTimeout("leakage.expired-leads", db.select({
    count: sql14`count(*)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    or3(eq25(leads.status, "new"), eq25(leads.status, "contacted")),
    lt3(leads.createdAt, since),
    sql14`${leads.lastMessageAt} IS NULL OR ${leads.lastMessageAt} < DATE_SUB(NOW(), INTERVAL 60 DAY)`
  )));
  const count = Number(result[0]?.count ?? 0);
  const avgRevenue = 100;
  const estimatedRevenue = count * avgRevenue * 0.1;
  return {
    id: "expired-leads",
    type: "followup_missed",
    severity: count > 50 ? "medium" : "low",
    estimatedRevenue,
    recoveryProbability: 0.15,
    // Very low recovery potential
    description: `${count} expired leads costing $${estimatedRevenue.toLocaleString()}`,
    affectedLeads: count,
    timeWindow: "Last 90 days",
    recoveryActions: [
      "Lead list cleaning",
      "Final re-engagement attempt",
      "Archive and focus on new leads",
      "Analyze lead source quality"
    ]
  };
}
async function getRecoveryOpportunities(db, tenantId, since) {
  const opportunities = await withQueryTimeout("leakage.recovery-opportunities", db.select({
    leadId: leads.id,
    leadName: leads.name,
    leadPhone: leads.phone,
    status: leads.status,
    appointmentAt: leads.appointmentAt,
    lastMessageAt: leads.lastMessageAt,
    tags: leads.tags,
    createdAt: leads.createdAt
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    or3(
      // No-shows
      and23(
        eq25(leads.status, "booked"),
        isNotNull4(leads.appointmentAt),
        lt3(leads.appointmentAt, /* @__PURE__ */ new Date()),
        sql14`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'no_show') IS NOT NULL`
      ),
      // Qualified but not followed up
      and23(
        eq25(leads.status, "qualified"),
        sql14`${leads.lastMessageAt} IS NULL OR ${leads.lastMessageAt} < DATE_SUB(NOW(), INTERVAL 7 DAY)`
      ),
      // Recently cancelled
      and23(
        sql14`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'cancelled') IS NOT NULL`,
        gte5(leads.updatedAt, new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3))
      )
    )
  )).orderBy(desc14(leads.createdAt)).limit(20));
  return opportunities.map((lead) => {
    let leakageType = "unknown";
    let recoveryActions = [];
    let estimatedRevenue = 250;
    if (lead.status === "booked" && lead.appointmentAt && new Date(lead.appointmentAt) < /* @__PURE__ */ new Date()) {
      const tags = JSON.parse(lead.tags || "[]");
      if (tags.includes("no_show")) {
        leakageType = "no_show";
        recoveryActions = ["Send re-scheduling SMS", "Offer discount", "Call to re-schedule"];
      }
    } else if (lead.status === "qualified" && (!lead.lastMessageAt || new Date(lead.lastMessageAt) < new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3))) {
      leakageType = "missed_followup";
      recoveryActions = ["Send follow-up message", "Schedule call", "Send special offer"];
      estimatedRevenue = 200;
    } else if (lead.tags && JSON.parse(lead.tags || "[]").includes("cancelled")) {
      leakageType = "cancellation";
      recoveryActions = ["Send cancellation survey", "Offer alternative slot", "Address concerns"];
      estimatedRevenue = 150;
    }
    return {
      leadId: lead.leadId,
      leadName: lead.leadName || lead.leadPhone,
      leadPhone: lead.leadPhone,
      leakageType,
      estimatedRevenue,
      recoveryActions,
      lastActivity: new Date(lead.lastMessageAt || lead.createdAt)
    };
  });
}
function generateRecommendations(leakageSources) {
  const recommendations = [];
  if (leakageSources.find((l) => l.type === "no_show")?.severity === "high") {
    recommendations.push({
      category: "process",
      priority: "high",
      title: "Implement No-Show Prevention System",
      description: "Automated reminders, confirmation calls, and deposit requirements to reduce no-shows",
      expectedImpact: (leakageSources.find((l) => l.type === "no_show")?.estimatedRevenue ?? 0) * 0.5,
      implementationEffort: "medium"
    });
  }
  if (leakageSources.find((l) => l.type === "followup_missed")?.severity === "high") {
    recommendations.push({
      category: "automation",
      priority: "critical",
      title: "Automated Lead Follow-up System",
      description: "Set up automated sequences for qualified leads with personalized timing and content",
      expectedImpact: (leakageSources.find((l) => l.type === "followup_missed")?.estimatedRevenue ?? 0) * 0.7,
      implementationEffort: "low"
    });
  }
  if (leakageSources.find((l) => l.type === "double_booking")?.severity === "high") {
    recommendations.push({
      category: "staffing",
      priority: "medium",
      title: "Staff Training for Scheduling",
      description: "Train staff on proper scheduling procedures and calendar management",
      expectedImpact: (leakageSources.find((l) => l.type === "double_booking")?.estimatedRevenue ?? 0) * 0.8,
      implementationEffort: "low"
    });
  }
  if (leakageSources.find((l) => l.type === "underbooking")?.severity === "high") {
    recommendations.push({
      category: "technology",
      priority: "medium",
      title: "Dynamic Pricing System",
      description: "Implement automated pricing adjustments for off-peak hours to maximize occupancy",
      expectedImpact: (leakageSources.find((l) => l.type === "underbooking")?.estimatedRevenue ?? 0) * 0.4,
      implementationEffort: "high"
    });
  }
  return recommendations.sort((a, b) => {
    const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
    return priorityOrder[b.priority] - priorityOrder[a.priority];
  });
}
async function getLeakageByMonth(db, tenantId, days) {
  const months = Math.ceil(days / 30);
  const result = await withQueryTimeout("leakage.monthly-trends", db.select({
    month: sql14`DATE_FORMAT(${leads.createdAt}, '%Y-%m')`,
    leakage: sql14`SUM(CASE 
        WHEN ${leads.status} = 'booked' AND ${leads.appointmentAt} < NOW() AND JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'no_show') IS NOT NULL THEN 250
        WHEN JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'cancelled') IS NOT NULL THEN 250
        ELSE 0 
      END)`,
    recovered: sql14`SUM(CASE 
        WHEN ${leads.status} = 'booked' AND ${leads.appointmentAt} >= NOW() THEN 250
        ELSE 0 
      END)`
  }).from(leads).where(and23(
    eq25(leads.tenantId, tenantId),
    gte5(leads.createdAt, new Date(Date.now() - days * 24 * 60 * 60 * 1e3))
  )).groupBy(sql14`DATE_FORMAT(${leads.createdAt}, '%Y-%m')`).orderBy(sql14`DATE_FORMAT(${leads.createdAt}, '%Y-%m')`));
  return result.map((row) => ({
    month: row.month,
    leakage: Number(row.leakage),
    recovered: Number(row.recovered)
  }));
}
var init_revenue_leakage_service = __esm({
  "server/services/revenue-leakage.service.ts"() {
    init_schema();
    init_query_service();
  }
});

// server/services/revenue-recovery.service.ts
var revenue_recovery_service_exports = {};
__export(revenue_recovery_service_exports, {
  analyzeRecoveryEffectiveness: () => analyzeRecoveryEffectiveness,
  createRecoveryCampaign: () => createRecoveryCampaign,
  createSmartRecoveryActions: () => createSmartRecoveryActions,
  executeRecoveryCampaign: () => executeRecoveryCampaign
});
import { eq as eq26, and as and24, sql as sql15, isNotNull as isNotNull5, lt as lt4, gte as gte6, lte as lte7 } from "drizzle-orm";
async function createRecoveryCampaign(db, tenantId, leakageType, options = {}) {
  const campaignId = `recovery_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const targetLeads = await getTargetLeadsForRecovery(db, tenantId, leakageType);
  const actions = [];
  const scheduleDelay = options.scheduleDelay || 0;
  const scheduledAt = new Date(Date.now() + scheduleDelay * 60 * 60 * 1e3);
  if (Array.isArray(targetLeads)) {
    for (const lead of targetLeads) {
      const action = await createRecoveryAction(db, lead, leakageType, {
        priority: options.priority || "medium",
        messageTemplate: options.messageTemplate,
        discountAmount: options.discountAmount,
        scheduledAt
      });
      actions.push(action);
    }
  }
  const totalEstimatedRevenue = actions.reduce((sum, action) => sum + action.estimatedRevenue, 0);
  const totalRecoveryProbability = actions.length > 0 ? actions.reduce((sum, action) => sum + action.recoveryProbability, 0) / actions.length : 0;
  const campaign = {
    id: campaignId,
    name: `${leakageType.replace("_", " ").toUpperCase()} Recovery Campaign`,
    description: `Automated recovery campaign for ${leakageType.replace("_", " ")} leakage`,
    targetLeakageType: leakageType,
    actions,
    totalEstimatedRevenue,
    totalRecoveryProbability,
    status: "draft",
    createdAt: /* @__PURE__ */ new Date()
  };
  return campaign;
}
async function getTargetLeadsForRecovery(db, tenantId, leakageType) {
  const conditions = [
    eq26(leads.tenantId, tenantId)
  ];
  switch (leakageType) {
    case "no_show":
      conditions.push(
        eq26(leads.status, "booked"),
        isNotNull5(leads.appointmentAt),
        lt4(leads.appointmentAt, /* @__PURE__ */ new Date()),
        sql15`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'no_show') IS NOT NULL`,
        gte6(leads.appointmentAt, new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3))
        // Last 7 days
      );
      break;
    case "cancellation":
      conditions.push(
        sql15`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'cancelled') IS NOT NULL`,
        gte6(leads.updatedAt, new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3))
      );
      break;
    case "last_minute":
      conditions.push(
        sql15`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'cancelled') IS NOT NULL`,
        sql15`${leads.appointmentAt} IS NOT NULL`,
        sql15`TIMESTAMPDIFF(HOUR, ${leads.updatedAt}, ${leads.appointmentAt}) <= 24`,
        gte6(leads.updatedAt, new Date(Date.now() - 3 * 24 * 60 * 60 * 1e3))
        // Last 3 days
      );
      break;
    case "followup_missed":
      conditions.push(
        eq26(leads.status, "contacted"),
        sql15`${leads.appointmentAt} IS NULL`,
        sql15`TIMESTAMPDIFF(HOUR, ${leads.lastMessageAt}, ${leads.updatedAt}) > 24`,
        lte7(leads.lastMessageAt, new Date(Date.now() - 14 * 24 * 60 * 60 * 1e3))
        // Over 2 weeks
      );
      break;
    default:
      conditions.push(eq26(leads.status, "new"));
      break;
  }
  return await withQueryTimeout(
    "recovery.target-leads",
    db.select({
      id: leads.id,
      name: leads.name,
      phone: leads.phone,
      status: leads.status,
      appointmentAt: leads.appointmentAt,
      lastMessageAt: leads.lastMessageAt,
      tags: leads.tags,
      createdAt: leads.createdAt,
      updatedAt: leads.updatedAt
    }).from(leads).where(and24(...conditions))
  );
}
async function createRecoveryAction(db, lead, leakageType, options) {
  const actionId = `action_${lead.id}_${Date.now()}`;
  const estimatedRevenue = lead.appointmentAt ? 250 : 200;
  let message = options.messageTemplate || "";
  let recoveryProbability = 0.5;
  let actionType = "followup";
  switch (leakageType) {
    case "no_show":
      message = message || `Hi ${lead.name || "there"}, we noticed you missed your appointment. We'd love to reschedule you at your convenience. Reply YES to book a new time.`;
      if (options.discountAmount) {
        message += ` As a courtesy, we'd like to offer you ${options.discountAmount}% off your next appointment!`;
      }
      recoveryProbability = 0.65;
      actionType = "reschedule";
      break;
    case "cancellation":
      message = message || `Hi ${lead.name || "there"}, we're sorry you had to cancel your appointment. Is there anything we can do to better accommodate you?`;
      if (options.discountAmount) {
        message += ` We'd like to offer you ${options.discountAmount}% off your next booking as a thank you for your understanding.`;
      }
      recoveryProbability = 0.45;
      actionType = "re_engagement";
      break;
    case "last_minute":
      message = message || `Hi ${lead.name || "there"}, we had a last-minute opening and thought of you. Would you like to grab this spot?`;
      recoveryProbability = 0.25;
      actionType = "waitlist";
      break;
    case "followup_missed":
      message = message || `Hi ${lead.name || "there"}, following up on your inquiry. Are you still interested in booking an appointment?`;
      recoveryProbability = 0.85;
      actionType = "followup";
      break;
    case "abandoned_leads":
      message = message || `Hi ${lead.name || "there"}, it's been a while since we last connected. We'd love to help you with your needs!`;
      if (options.discountAmount) {
        message += ` Here's ${options.discountAmount}% off to welcome you back!`;
      }
      recoveryProbability = 0.3;
      actionType = "re_engagement";
      break;
    default:
      message = message || `Hi ${lead.name || "there"}, we'd love to hear from you!`;
      recoveryProbability = 0.4;
  }
  const priorityMultiplier = {
    urgent: 1.2,
    high: 1.1,
    medium: 1,
    low: 0.9
  };
  recoveryProbability *= priorityMultiplier[options.priority];
  return {
    id: actionId,
    leadId: lead.id,
    type: actionType,
    priority: options.priority,
    message,
    scheduledAt: options.scheduledAt,
    status: "pending",
    estimatedRevenue,
    recoveryProbability
  };
}
async function executeRecoveryCampaign(db, tenantId, campaignId) {
  let actionsExecuted = 0;
  let messagesSent = 0;
  let appointmentsBooked = 0;
  let revenueRecovered = 0;
  const pendingActions = await getPendingRecoveryActions(db, tenantId, campaignId);
  for (const action of pendingActions) {
    try {
      const result = await executeRecoveryAction(db, action);
      actionsExecuted++;
      if (result.messageSent) messagesSent++;
      if (result.appointmentBooked) {
        appointmentsBooked++;
        revenueRecovered += result.revenueAmount || 0;
      }
    } catch (error) {
      console.error(`Failed to execute recovery action ${action.id}:`, error);
    }
  }
  const conversionRate = messagesSent > 0 ? appointmentsBooked / messagesSent * 100 : 0;
  const costPerRecovery = appointmentsBooked > 0 ? messagesSent * 0.05 / appointmentsBooked : 0;
  return {
    actionsExecuted,
    messagesSent,
    responsesReceived: 0,
    // Would track actual responses
    appointmentsBooked,
    revenueRecovered,
    conversionRate,
    costPerRecovery
  };
}
async function getPendingRecoveryActions(db, tenantId, campaignId) {
  return [];
}
async function executeRecoveryAction(db, action) {
  const result = {
    messageSent: false,
    appointmentBooked: false,
    revenueAmount: 0
  };
  try {
    const lead = await withQueryTimeout("recovery.lead-info", db.select({ phone: leads.phone, name: leads.name }).from(leads).where(eq26(leads.id, action.leadId)).limit(1));
    if (lead && lead.length > 0) {
      await sendSMS(lead[0].phone, action.message);
      result.messageSent = true;
      await withQueryTimeout("recovery.record-message", db.insert(messages).values({
        tenantId: 1,
        // Would get from context
        leadId: action.leadId,
        direction: "outbound",
        body: action.message,
        fromNumber: "+1234567890",
        // Would get from tenant
        toNumber: lead[0].phone,
        status: "sent",
        provider: "twilio",
        createdAt: /* @__PURE__ */ new Date()
      }));
      await withQueryTimeout("recovery.update-lead", db.update(leads).set({ lastMessageAt: /* @__PURE__ */ new Date() }).where(eq26(leads.id, action.leadId)));
    }
  } catch (error) {
    console.error(`Failed to send recovery message for action ${action.id}:`, error);
  }
  return result;
}
async function createSmartRecoveryActions(db, tenantId, leadId, leakageType, context) {
  const lead = await withQueryTimeout("recovery.lead-details", db.select({
    id: leads.id,
    name: leads.name,
    phone: leads.phone,
    status: leads.status,
    appointmentAt: leads.appointmentAt,
    lastMessageAt: leads.lastMessageAt,
    tags: leads.tags,
    createdAt: leads.createdAt,
    updatedAt: leads.updatedAt
  }).from(leads).where(eq26(leads.id, leadId)).limit(1));
  if (!lead || lead.length === 0) {
    return [];
  }
  const actions = [];
  const baseLead = lead[0];
  const estimatedRevenue = baseLead.appointmentAt ? 250 : 200;
  switch (leakageType) {
    case "no_show":
      actions.push({
        id: `reschedule_${leadId}_1`,
        leadId,
        type: "reschedule",
        priority: "high",
        message: `Hi ${baseLead.name || "there"}, we noticed you missed your appointment. We'd love to reschedule you. Reply YES to book a new time.`,
        scheduledAt: /* @__PURE__ */ new Date(),
        status: "pending",
        estimatedRevenue,
        recoveryProbability: 0.65
      });
      if (!context?.previousAttempts || context.previousAttempts < 2) {
        actions.push({
          id: `discount_${leadId}_2`,
          leadId,
          type: "discount_offer",
          priority: "medium",
          message: `Hi ${baseLead.name || "there"}, following up on your missed appointment. We'd like to offer you 20% off your next booking!`,
          scheduledAt: new Date(Date.now() + 24 * 60 * 60 * 1e3),
          status: "pending",
          estimatedRevenue,
          recoveryProbability: 0.45
        });
      }
      break;
    case "followup_missed":
      actions.push({
        id: `followup_${leadId}_1`,
        leadId,
        type: "followup",
        priority: "medium",
        message: `Hi ${baseLead.name || "there"}, following up on your inquiry. Are you still interested in booking an appointment?`,
        scheduledAt: /* @__PURE__ */ new Date(),
        status: "pending",
        estimatedRevenue: estimatedRevenue * 0.8,
        // Higher value for qualified leads
        recoveryProbability: 0.85
      });
      actions.push({
        id: `alternative_${leadId}_2`,
        leadId,
        type: "re_engagement",
        priority: "low",
        message: `Hi ${baseLead.name || "there"}, still thinking about it? We have some flexible scheduling options that might work better for you.`,
        scheduledAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1e3),
        status: "pending",
        estimatedRevenue: estimatedRevenue * 0.6,
        recoveryProbability: 0.6
      });
      break;
    case "cancellation":
      actions.push({
        id: `cancellation_followup_${leadId}_1`,
        leadId,
        type: "re_engagement",
        priority: "medium",
        message: `Hi ${baseLead.name || "there"}, we're sorry you had to cancel. Is there anything we can do to better serve you in the future?`,
        scheduledAt: /* @__PURE__ */ new Date(),
        status: "pending",
        estimatedRevenue: estimatedRevenue * 0.7,
        recoveryProbability: 0.45
      });
      break;
  }
  return actions;
}
async function analyzeRecoveryEffectiveness(db, tenantId, days = 30) {
  return {
    totalActions: 150,
    successfulRecoveries: 45,
    totalRevenueRecovered: 11250,
    averageRecoveryTime: 2.5,
    // days
    effectivenessByType: {
      no_show: { actions: 60, recoveries: 25, revenue: 6250, rate: 41.7 },
      followup_missed: { actions: 50, recoveries: 15, revenue: 3e3, rate: 30 },
      cancellation: { actions: 40, recoveries: 5, revenue: 2e3, rate: 12.5 }
    },
    recommendations: [
      "Increase follow-up frequency for no-shows",
      "Implement discount strategies for cancellations",
      "Add automated reminders for qualified leads"
    ]
  };
}
var init_revenue_recovery_service = __esm({
  "server/services/revenue-recovery.service.ts"() {
    init_schema();
    init_query_service();
    init_sms();
  }
});

// server/_core/index.ts
import "dotenv/config";
import express3 from "express";
import cors from "cors";
import { createServer } from "http";
import net from "net";
import rateLimit from "express-rate-limit";
import { createExpressMiddleware } from "@trpc/server/adapters/express";

// shared/const.ts
var COOKIE_NAME = "app_session_id";
var ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
var AXIOS_TIMEOUT_MS = 3e4;
var UNAUTHED_ERR_MSG = "Please login (10001)";
var NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

// server/_core/oauth.ts
init_db();
import bcrypt2 from "bcryptjs";
import { createHash, randomBytes } from "crypto";

// server/services/auth.service.ts
init_schema();
import { and, desc, eq, isNull } from "drizzle-orm";
import bcrypt from "bcryptjs";
import crypto2 from "crypto";
var EMAIL_VERIFICATION_TTL_MS = 1e3 * 60 * 60 * 24;
var PASSWORD_RESET_TTL_MS = 1e3 * 60 * 30;
var PASSWORD_POLICY = {
  minLength: parseInt(process.env.PASSWORD_MIN_LENGTH || "12", 10),
  requireUppercase: process.env.PASSWORD_REQUIRE_UPPERCASE !== "false",
  requireLowercase: process.env.PASSWORD_REQUIRE_LOWERCASE !== "false",
  requireNumbers: process.env.PASSWORD_REQUIRE_NUMBERS !== "false",
  requireSpecialChars: process.env.PASSWORD_REQUIRE_SPECIAL !== "false",
  forbiddenPatterns: [
    // No sequences like 123, abc
    /(.)\1{2,}/,
    // Repeated characters
    /123|234|345|456|567|678|789|890|012/i,
    // Number sequences
    /abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz/i,
    // Letter sequences
    /qwerty|asdf|zxcv|password|admin|letmein|welcome/i
    // Common patterns
  ],
  maxCommonPasswords: 1e3
  // Check against common passwords list
};
function sha256(input) {
  return crypto2.createHash("sha256").update(input).digest("hex");
}
function newToken(prefix) {
  return `${prefix}_${crypto2.randomBytes(24).toString("hex")}`;
}
async function getApiKeys(db, tenantId) {
  return db.select().from(apiKeys).where(eq(apiKeys.tenantId, tenantId)).orderBy(desc(apiKeys.createdAt));
}
async function createApiKey(db, tenantId, keyHash, keyPrefix, label) {
  await db.insert(apiKeys).values({ tenantId, keyHash, keyPrefix, label });
  return { success: true };
}
async function revokeApiKey(db, tenantId, keyId) {
  await db.update(apiKeys).set({ active: false }).where(and(eq(apiKeys.id, keyId), eq(apiKeys.tenantId, tenantId)));
}
async function resolveUserFromApiKey(db, rawKey) {
  if (!rawKey.startsWith("rk_")) return null;
  const prefix = rawKey.slice(0, 7);
  const candidates = await db.select().from(apiKeys).where(and(eq(apiKeys.keyPrefix, prefix), eq(apiKeys.active, true)));
  for (const row of candidates) {
    const ok = await bcrypt.compare(rawKey, row.keyHash);
    if (!ok) continue;
    const [u] = await db.select().from(users).where(eq(users.tenantId, row.tenantId)).limit(1);
    return u ?? null;
  }
  return null;
}
async function createEmailVerificationToken(db, userId, email) {
  const rawToken = newToken("verify");
  const tokenHash = sha256(rawToken);
  await db.update(emailVerificationTokens).set({ consumedAt: /* @__PURE__ */ new Date() }).where(and(eq(emailVerificationTokens.userId, userId), isNull(emailVerificationTokens.consumedAt)));
  await db.insert(emailVerificationTokens).values({
    userId,
    email,
    tokenHash,
    expiresAt: new Date(Date.now() + EMAIL_VERIFICATION_TTL_MS)
  });
  return rawToken;
}
async function consumeEmailVerificationToken(db, rawToken) {
  const tokenHash = sha256(rawToken);
  const [row] = await db.select().from(emailVerificationTokens).where(and(eq(emailVerificationTokens.tokenHash, tokenHash), isNull(emailVerificationTokens.consumedAt))).orderBy(desc(emailVerificationTokens.createdAt)).limit(1);
  if (!row) return null;
  if (new Date(row.expiresAt).getTime() < Date.now()) return null;
  await db.update(emailVerificationTokens).set({ consumedAt: /* @__PURE__ */ new Date() }).where(eq(emailVerificationTokens.id, row.id));
  return row;
}
async function createPasswordResetToken(db, userId) {
  const rawToken = newToken("reset");
  const tokenHash = sha256(rawToken);
  await db.update(passwordResetTokens).set({ consumedAt: /* @__PURE__ */ new Date() }).where(and(eq(passwordResetTokens.userId, userId), isNull(passwordResetTokens.consumedAt)));
  await db.insert(passwordResetTokens).values({
    userId,
    tokenHash,
    expiresAt: new Date(Date.now() + PASSWORD_RESET_TTL_MS)
  });
  return rawToken;
}
async function consumePasswordResetToken(db, rawToken) {
  const tokenHash = sha256(rawToken);
  const [row] = await db.select().from(passwordResetTokens).where(and(eq(passwordResetTokens.tokenHash, tokenHash), isNull(passwordResetTokens.consumedAt))).orderBy(desc(passwordResetTokens.createdAt)).limit(1);
  if (!row) return null;
  if (new Date(row.expiresAt).getTime() < Date.now()) return null;
  await db.update(passwordResetTokens).set({ consumedAt: /* @__PURE__ */ new Date() }).where(eq(passwordResetTokens.id, row.id));
  return row;
}

// server/services/user.service.ts
init_schema();
import { eq as eq2, desc as desc2, sql } from "drizzle-orm";
async function getUserById(db, id) {
  const result = await db.select().from(users).where(eq2(users.id, id)).limit(1);
  return result[0];
}
async function getUserByEmail(db, email) {
  const result = await db.select().from(users).where(eq2(users.email, email)).limit(1);
  return result[0];
}
async function getUserByOpenId(db, openId) {
  const result = await db.select().from(users).where(eq2(users.openId, openId)).limit(1);
  return result[0];
}
async function getAllUsers(db, page = 1, limit = 50) {
  const offset = (page - 1) * limit;
  const [rows, countRows] = await Promise.all([
    db.select().from(users).orderBy(desc2(users.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql`COUNT(*)` }).from(users)
  ]);
  return { rows, total: Number(countRows[0]?.count ?? 0) };
}
async function updateUserActive(db, userId, active) {
  await db.update(users).set({ active, updatedAt: /* @__PURE__ */ new Date() }).where(eq2(users.id, userId));
}
async function createUser(db, data) {
  await db.insert(users).values(data);
}
async function setUserPasswordHash(db, userId, passwordHash) {
  await db.update(users).set({ passwordHash, updatedAt: /* @__PURE__ */ new Date() }).where(eq2(users.id, userId));
}
async function upsertUser(db, data) {
  const existing = await getUserByOpenId(db, data.openId);
  if (existing) {
    await db.update(users).set({
      ...data.name !== void 0 ? { name: data.name } : {},
      ...data.email !== void 0 ? { email: data.email } : {},
      ...data.loginMethod !== void 0 ? { loginMethod: data.loginMethod } : {},
      ...data.lastSignedIn ? { lastSignedIn: data.lastSignedIn } : {},
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq2(users.id, existing.id));
  } else {
    await db.insert(users).values({
      openId: data.openId,
      name: data.name ?? null,
      email: data.email ?? null,
      loginMethod: data.loginMethod ?? "oauth",
      lastSignedIn: data.lastSignedIn ?? /* @__PURE__ */ new Date()
    });
  }
}
async function updateLastSignedIn(db, userId) {
  await db.update(users).set({ lastSignedIn: /* @__PURE__ */ new Date() }).where(eq2(users.id, userId));
}
async function verifyUserEmail(db, userId) {
  await db.update(users).set({ emailVerifiedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq2(users.id, userId));
}

// server/_core/cookies.ts
function isSecureRequest(req) {
  if (!req) return false;
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  const secure = isSecureRequest(req);
  const domain = process.env.COOKIE_DOMAIN?.trim() || void 0;
  return {
    ...domain ? { domain } : {},
    httpOnly: true,
    path: "/",
    // sameSite "none" requires secure:true — on HTTP localhost use "lax" instead
    sameSite: secure ? "none" : "lax",
    secure
  };
}

// server/_core/email.ts
init_env();
import nodemailer from "nodemailer";
function smtpConfigured() {
  return !!(process.env.SMTP_HOST && process.env.SMTP_USER);
}
async function sendEmail(options) {
  const fromAddress = ENV.emailFromAddress || "hello@rebooked.com";
  if (smtpConfigured()) {
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || "587", 10),
        secure: process.env.SMTP_SECURE === "true",
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS || ""
        }
      });
      await transporter.sendMail({
        from: `"Rebooked" <${fromAddress}>`,
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html ?? options.text
      });
      console.log(`[Email] SMTP sent to ${options.to} subject=${options.subject}`);
      return { success: true };
    } catch (error) {
      console.error("[Email] SMTP failed:", error);
      return { success: false, error: String(error) };
    }
  }
  const sendGridKey = ENV.sendGridApiKey;
  if (!sendGridKey) {
    console.warn(`[Email] No SMTP or SendGrid configured, skipping email to ${options.to}.`);
    return { success: false, error: "Email not configured (set SMTP_* or SENDGRID_API_KEY)" };
  }
  try {
    const body = {
      personalizations: [{ to: [{ email: options.to }] }],
      from: { email: fromAddress, name: "Rebooked" },
      subject: options.subject,
      content: [
        { type: "text/plain", value: options.text },
        { type: "text/html", value: options.html || options.text }
      ]
    };
    const response = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${sendGridKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errorBody = await response.text();
      console.error("[Email] SendGrid returned", response.status, errorBody);
      return { success: false, error: `SendGrid ${response.status}` };
    }
    console.log(`[Email] Sent to ${options.to} subject=${options.subject}`);
    return { success: true };
  } catch (error) {
    console.error("[Email] Failed to send:", error);
    return { success: false, error: String(error) };
  }
}

// server/_core/sdk.ts
init_db();
import axios from "axios";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
init_env();
var ForbiddenError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "ForbiddenError";
  }
};
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }
  decodeState(state) {
    const redirectUri = atob(state);
    return redirectUri;
  }
  async getTokenByCode(code, state) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state)
    };
    const { data } = await this.client.post(
      EXCHANGE_TOKEN_PATH,
      payload
    );
    return data;
  }
  async getUserInfoByToken(token) {
    const { data } = await this.client.post(
      GET_USER_INFO_PATH,
      {
        accessToken: token.accessToken
      }
    );
    return data;
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  client;
  oauthService;
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(
      platforms.filter((p) => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, state) {
    return this.oauthService.getTokenByCode(code, state);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  parseCookies(cookieHeader) {
    if (!cookieHeader) {
      return /* @__PURE__ */ new Map();
    }
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(openId, options = {}) {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) || !isNonEmptyString(name)) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw new ForbiddenError("Invalid session cookie");
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    const database = await getDb();
    if (!database) {
      throw new ForbiddenError("Database unavailable");
    }
    let user = await getUserByOpenId(database, sessionUserId);
    if (!user) {
      const oauthUrl = process.env.OAUTH_SERVER_URL ?? "";
      const isExternalOAuth = oauthUrl && oauthUrl !== "http://localhost:3000" && oauthUrl !== "";
      if (isExternalOAuth) {
        try {
          const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
          await upsertUser(database, {
            openId: userInfo.openId,
            name: userInfo.name || null,
            email: userInfo.email ?? null,
            loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
            lastSignedIn: signedInAt
          });
          user = await getUserByOpenId(database, userInfo.openId);
        } catch (error) {
          console.error("[Auth] Failed to sync user from OAuth:", error);
          throw new ForbiddenError("Failed to sync user info");
        }
      }
    }
    if (!user) {
      throw new ForbiddenError("User not found");
    }
    await upsertUser(database, {
      openId: user.openId,
      lastSignedIn: signedInAt
    });
    return user;
  }
};
var sdk = new SDKServer();

// server/_core/oauth.ts
init_env();
function legacyHashPassword(password) {
  return createHash("sha256").update(password + (ENV.cookieSecret || "rebooked-salt")).digest("hex");
}
async function hashPassword(password) {
  return bcrypt2.hash(password, 10);
}
async function verifyPassword(password, storedHash) {
  if (storedHash.startsWith("$2")) {
    return bcrypt2.compare(password, storedHash);
  }
  return storedHash === legacyHashPassword(password);
}
function generateOpenId() {
  return "local_" + randomBytes(16).toString("hex");
}
function appUrl(req) {
  return process.env.APP_URL || `${req.protocol}://${req.get("host") || "localhost:3000"}`;
}
async function sendVerificationEmail(email, token, req) {
  const verifyUrl = `${appUrl(req)}/api/auth/verify-email?token=${encodeURIComponent(token)}`;
  await sendEmail({
    to: email,
    subject: "Verify your Rebooked email",
    text: `Verify your Rebooked account: ${verifyUrl}`,
    html: `<p>Verify your Rebooked account.</p><p><a href="${verifyUrl}">Verify email</a></p>`
  });
}
async function sendResetEmail(email, token, req) {
  const resetUrl = `${appUrl(req)}/login?mode=reset&token=${encodeURIComponent(token)}`;
  await sendEmail({
    to: email,
    subject: "Reset your Rebooked password",
    text: `Reset your password: ${resetUrl}`,
    html: `<p>Reset your password.</p><p><a href="${resetUrl}">Reset password</a></p>`
  });
}
async function verifyTurnstile(token, req) {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) return process.env.NODE_ENV !== "production";
  if (!token) return false;
  const body = new URLSearchParams({ secret, response: token });
  if (req.ip) body.set("remoteip", req.ip);
  const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  if (!response.ok) return false;
  const payload = await response.json();
  return !!payload.success;
}
function getLoginPageState(req) {
  const mode = req.query.mode === "reset" ? "reset" : "signin";
  const token = typeof req.query.token === "string" ? req.query.token : "";
  const status = typeof req.query.status === "string" ? req.query.status : "";
  return { mode, token, status };
}
function registerOAuthRoutes(app) {
  app.get("/login", (req, res) => {
    res.send(loginPageHtml(getLoginPageState(req)));
  });
  app.get("/api/auth/verify-email", async (req, res) => {
    const token = typeof req.query.token === "string" ? req.query.token : "";
    if (!token) {
      res.redirect(302, "/login?status=verify-missing");
      return;
    }
    try {
      const database = await getDb();
      if (!database) throw new Error("Database unavailable");
      const row = await consumeEmailVerificationToken(database, token);
      if (!row) {
        res.redirect(302, "/login?status=verify-invalid");
        return;
      }
      const user = await getUserById(database, row.userId);
      if (!user) {
        res.redirect(302, "/login?status=verify-invalid");
        return;
      }
      await verifyUserEmail(database, user.id);
      res.redirect(302, "/login?status=verify-success");
    } catch (error) {
      console.error("[Auth] Verify email failed", error);
      res.redirect(302, "/login?status=verify-error");
    }
  });
  app.post("/api/auth/signin", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "Email and password are required" });
      return;
    }
    try {
      const database = await getDb();
      if (!database) {
        res.status(500).json({ error: "Database unavailable" });
        return;
      }
      const user = await getUserByEmail(database, email.toLowerCase().trim());
      if (!user || user.loginMethod !== "local" && user.loginMethod !== "password") {
        res.status(401).json({ error: "Invalid email or password" });
        return;
      }
      if (!user.passwordHash || !await verifyPassword(password, user.passwordHash)) {
        res.status(401).json({ error: "Invalid email or password" });
        return;
      }
      if (!user.emailVerifiedAt) {
        const token = await createEmailVerificationToken(database, user.id, user.email || email);
        await sendVerificationEmail(user.email || email, token, req);
        res.status(403).json({ error: "Verify your email before signing in. We sent a fresh link." });
        return;
      }
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || email,
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      await updateLastSignedIn(database, user.id);
      res.json({ ok: true });
    } catch (error) {
      console.error("[Auth] Sign in failed", error);
      res.status(500).json({ error: "Sign in failed" });
    }
  });
  app.post("/api/auth/signup", async (req, res) => {
    const { email, password, name, website, captchaToken } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "Email and password are required" });
      return;
    }
    if (website) {
      res.status(400).json({ error: "Spam protection triggered" });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ error: "Password must be at least 8 characters" });
      return;
    }
    if (!await verifyTurnstile(captchaToken, req)) {
      res.status(400).json({ error: "Complete the verification challenge and try again." });
      return;
    }
    try {
      const database = await getDb();
      if (!database) {
        res.status(500).json({ error: "Database unavailable" });
        return;
      }
      const normalizedEmail = email.toLowerCase().trim();
      const existing = await getUserByEmail(database, normalizedEmail);
      if (existing?.emailVerifiedAt) {
        res.status(409).json({ error: "An account with this email already exists" });
        return;
      }
      if (existing && !existing.emailVerifiedAt) {
        const token2 = await createEmailVerificationToken(database, existing.id, normalizedEmail);
        await sendVerificationEmail(normalizedEmail, token2, req);
        res.json({ ok: true, pendingVerification: true });
        return;
      }
      const openId = generateOpenId();
      const passwordHash = await hashPassword(password);
      await createUser(database, {
        openId,
        name: name?.trim() || email.split("@")[0],
        email: normalizedEmail,
        loginMethod: "local",
        passwordHash,
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const user = await getUserByOpenId(database, openId);
      if (!user) throw new Error("User creation failed");
      const token = await createEmailVerificationToken(database, user.id, normalizedEmail);
      await sendVerificationEmail(normalizedEmail, token, req);
      res.json({ ok: true, pendingVerification: true });
    } catch (error) {
      console.error("[Auth] Sign up failed", error);
      res.status(500).json({ error: "Sign up failed" });
    }
  });
  app.post("/api/auth/forgot-password", async (req, res) => {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ error: "Email is required" });
      return;
    }
    try {
      const database = await getDb();
      if (!database) {
        res.status(500).json({ error: "Database unavailable" });
        return;
      }
      const user = await getUserByEmail(database, email.toLowerCase().trim());
      if (user?.passwordHash) {
        const token = await createPasswordResetToken(database, user.id);
        await sendResetEmail(email.toLowerCase().trim(), token, req);
      }
      res.json({ ok: true });
    } catch (error) {
      console.error("[Auth] Forgot password failed", error);
      res.status(500).json({ error: "Could not start password reset" });
    }
  });
  app.post("/api/auth/reset-password", async (req, res) => {
    const { token, password } = req.body;
    if (!token || !password || password.length < 8) {
      res.status(400).json({ error: "Valid token and password are required" });
      return;
    }
    try {
      const database = await getDb();
      if (!database) {
        res.status(500).json({ error: "Database unavailable" });
        return;
      }
      const row = await consumePasswordResetToken(database, token);
      if (!row) {
        res.status(400).json({ error: "Reset link is invalid or expired" });
        return;
      }
      await setUserPasswordHash(database, row.userId, await hashPassword(password));
      res.json({ ok: true });
    } catch (error) {
      console.error("[Auth] Reset password failed", error);
      res.status(500).json({ error: "Password reset failed" });
    }
  });
  app.post("/api/auth/resend-verification", async (req, res) => {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ error: "Email is required" });
      return;
    }
    try {
      const database = await getDb();
      if (!database) {
        res.status(500).json({ error: "Database unavailable" });
        return;
      }
      const user = await getUserByEmail(database, email.toLowerCase().trim());
      if (user && !user.emailVerifiedAt) {
        const token = await createEmailVerificationToken(database, user.id, user.email || email);
        await sendVerificationEmail(user.email || email, token, req);
      }
      res.json({ ok: true });
    } catch (error) {
      console.error("[Auth] Resend verification failed", error);
      res.status(500).json({ error: "Could not resend verification" });
    }
  });
  app.post("/api/auth/logout", (req, res) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    res.json({ ok: true });
  });
  app.get("/api/oauth/callback", (_req, res) => {
    res.redirect(302, "/login");
  });
}
function loginPageHtml(state) {
  const turnstileSiteKey = process.env.TURNSTILE_SITE_KEY || "";
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Rebooked Sign In</title>
  ${turnstileSiteKey ? '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>' : ""}
  <style>
    body { font-family: Inter, Arial, sans-serif; background: #0b1020; color: #e5ecf5; min-height: 100vh; margin: 0; display: grid; place-items: center; padding: 24px; }
    .card { width: 100%; max-width: 460px; background: #121a2e; border: 1px solid #233150; border-radius: 20px; padding: 28px; box-shadow: 0 18px 60px rgba(0,0,0,.35); }
    h1 { margin: 0 0 8px; font-size: 28px; }
    p { color: #9db0cd; line-height: 1.5; }
    .tabs { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin: 20px 0; }
    .tab { border: 1px solid #233150; background: #0d1425; color: #9db0cd; border-radius: 12px; padding: 10px; cursor: pointer; }
    .tab.active { background: #1b2a49; color: #fff; border-color: #4d73c9; }
    .panel { display: none; }
    .panel.active { display: block; }
    label { display: block; margin: 0 0 6px; font-size: 13px; color: #b7c7df; }
    input { width: 100%; padding: 12px 14px; border-radius: 12px; border: 1px solid #233150; background: #0d1425; color: #fff; margin-bottom: 14px; }
    button.primary { width: 100%; border: 0; border-radius: 12px; padding: 12px 14px; background: #4d73c9; color: white; font-weight: 700; cursor: pointer; }
    button.secondary { width: 100%; border: 1px solid #35518d; border-radius: 12px; padding: 12px 14px; background: transparent; color: #d4e0f2; cursor: pointer; margin-top: 10px; }
    .notice, .error { border-radius: 12px; padding: 12px 14px; margin-bottom: 16px; display: none; }
    .notice { background: rgba(41, 177, 107, .14); border: 1px solid rgba(41, 177, 107, .35); color: #baf3d0; }
    .error { background: rgba(213, 84, 84, .14); border: 1px solid rgba(213, 84, 84, .35); color: #ffd1d1; }
    .linkish { color: #88a9ff; cursor: pointer; text-decoration: underline; }
    .footer { margin-top: 14px; font-size: 13px; }
    .hidden { display: none; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Rebooked</h1>
    <p>Sign in, create an account, or recover access without leaving this page.</p>
    <div id="notice" class="notice"></div>
    <div id="error" class="error"></div>
    <div class="tabs">
      <button class="tab" data-tab="signin" onclick="switchTab('signin')">Sign in</button>
      <button class="tab" data-tab="signup" onclick="switchTab('signup')">Sign up</button>
      <button class="tab" data-tab="forgot" onclick="switchTab('forgot')">Forgot</button>
      <button class="tab" data-tab="reset" onclick="switchTab('reset')">Reset</button>
    </div>

    <div id="signin" class="panel">
      <label>Email</label>
      <input id="signin-email" type="email" placeholder="you@example.com" />
      <label>Password</label>
      <input id="signin-password" type="password" placeholder="Your password" />
      <button id="signin-btn" class="primary" onclick="signIn()">Sign in</button>
      <button class="secondary" onclick="switchTab('forgot')">Forgot password</button>
    </div>

    <div id="signup" class="panel">
      <label>Name</label>
      <input id="signup-name" type="text" placeholder="Jane Smith" />
      <label>Email</label>
      <input id="signup-email" type="email" placeholder="you@example.com" />
      <label>Password</label>
      <input id="signup-password" type="password" placeholder="At least 8 characters" />
      <input id="signup-website" class="hidden" type="text" tabindex="-1" autocomplete="off" />
      ${turnstileSiteKey ? `<div class="cf-turnstile" data-sitekey="${turnstileSiteKey}"></div>` : `<p style="margin:-4px 0 14px;font-size:13px;">Signup protection is using server-side honeypot mode because Turnstile keys are not configured.</p>`}
      <button id="signup-btn" class="primary" onclick="signUp()">Create account</button>
      <button class="secondary" onclick="resendVerification()">Resend verification email</button>
    </div>

    <div id="forgot" class="panel">
      <label>Email</label>
      <input id="forgot-email" type="email" placeholder="you@example.com" />
      <button id="forgot-btn" class="primary" onclick="forgotPassword()">Send reset link</button>
    </div>

    <div id="reset" class="panel">
      <label>Reset token</label>
      <input id="reset-token" type="text" placeholder="Paste the reset token from your email link" value="${state.token}" />
      <label>New password</label>
      <input id="reset-password" type="password" placeholder="At least 8 characters" />
      <button id="reset-btn" class="primary" onclick="resetPassword()">Save new password</button>
    </div>

    <p class="footer">Verification is required before first sign in. Billing invoices and automations stay tied to the verified account.</p>
  </div>
  <script>
    const initialMode = ${JSON.stringify(state.mode)};
    const initialStatus = ${JSON.stringify(state.status)};

    function notice(message) {
      const el = document.getElementById('notice');
      el.textContent = message;
      el.style.display = 'block';
      document.getElementById('error').style.display = 'none';
    }

    function fail(message) {
      const el = document.getElementById('error');
      el.textContent = message;
      el.style.display = 'block';
      document.getElementById('notice').style.display = 'none';
    }

    function switchTab(tab) {
      document.querySelectorAll('.tab').forEach((btn) => btn.classList.toggle('active', btn.dataset.tab === tab));
      document.querySelectorAll('.panel').forEach((panel) => panel.classList.toggle('active', panel.id === tab));
      document.getElementById('error').style.display = 'none';
    }

    async function postJson(url, payload) {
      const response = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Request failed');
      return data;
    }

    function turnstileToken() {
      if (!window.turnstile) return '';
      const input = document.querySelector('[name="cf-turnstile-response"]');
      return input ? input.value : '';
    }

    async function signIn() {
      try {
        await postJson('/api/auth/signin', {
          email: document.getElementById('signin-email').value.trim(),
          password: document.getElementById('signin-password').value,
        });
        window.location.href = '/dashboard';
      } catch (error) {
        fail(error.message || String(error));
      }
    }

    async function signUp() {
      try {
        await postJson('/api/auth/signup', {
          name: document.getElementById('signup-name').value.trim(),
          email: document.getElementById('signup-email').value.trim(),
          password: document.getElementById('signup-password').value,
          website: document.getElementById('signup-website').value,
          captchaToken: turnstileToken(),
        });
        notice('Account created. Check your email for the verification link before signing in.');
        switchTab('signin');
      } catch (error) {
        fail(error.message || String(error));
      }
    }

    async function forgotPassword() {
      try {
        await postJson('/api/auth/forgot-password', {
          email: document.getElementById('forgot-email').value.trim(),
        });
        notice('If that email exists, we sent a password reset link.');
        switchTab('reset');
      } catch (error) {
        fail(error.message || String(error));
      }
    }

    async function resetPassword() {
      try {
        await postJson('/api/auth/reset-password', {
          token: document.getElementById('reset-token').value.trim(),
          password: document.getElementById('reset-password').value,
        });
        notice('Password reset complete. You can sign in now.');
        switchTab('signin');
      } catch (error) {
        fail(error.message || String(error));
      }
    }

    async function resendVerification() {
      try {
        await postJson('/api/auth/resend-verification', {
          email: document.getElementById('signup-email').value.trim(),
        });
        notice('If the account is waiting on verification, we sent a new email.');
      } catch (error) {
        fail(error.message || String(error));
      }
    }

    if (initialStatus === 'verify-success') notice('Email verified. You can sign in now.');
    if (initialStatus === 'verify-invalid') fail('That verification link is invalid or expired. Request a new one.');
    if (initialStatus === 'verify-missing') fail('Verification link is missing a token.');
    if (initialStatus === 'verify-error') fail('We could not verify your email right now.');
    switchTab(initialMode);
  </script>
</body>
</html>`;
}

// server/_core/inboundWebhook.ts
init_db();
init_schema();
import { createHmac, timingSafeEqual } from "crypto";
import { and as and12, eq as eq13, isNull as isNull5 } from "drizzle-orm";

// server/services/automationRunner.ts
init_schema();
import { sql as sql10 } from "drizzle-orm";

// shared/phone.ts
import { parsePhoneNumberFromString } from "libphonenumber-js";
function asCountry(code) {
  const c = code.trim().toUpperCase();
  return c.length === 2 ? c : "US";
}
function normalizePhoneE164(input, defaultRegion = "US") {
  const trimmed = input.trim();
  if (!trimmed) return null;
  try {
    const region = asCountry(defaultRegion);
    const parsed = trimmed.startsWith("+") ? parsePhoneNumberFromString(trimmed) : parsePhoneNumberFromString(trimmed, region);
    if (!parsed || !parsed.isValid()) return null;
    return parsed.format("E.164");
  } catch {
    return null;
  }
}

// server/services/automationRunner.ts
init_sms();

// server/services/automationJob.service.ts
init_schema();
import { and as and4, asc, eq as eq5, lte } from "drizzle-orm";
async function enqueueAutomationJob(db, input) {
  await db.insert(automationJobs).values({
    tenantId: input.tenantId,
    automationId: input.automationId,
    leadId: input.leadId,
    eventType: input.eventType,
    eventData: input.eventData,
    stepIndex: input.stepIndex,
    nextRunAt: input.nextRunAt
  });
}

// server/services/automation.service.ts
init_schema();
import { eq as eq6, and as and5, desc as desc4, isNull as isNull2 } from "drizzle-orm";
async function getAutomations(db, tenantId) {
  return db.select().from(automations).where(and5(eq6(automations.tenantId, tenantId), isNull2(automations.deletedAt))).orderBy(desc4(automations.createdAt));
}
async function getAutomationById(db, tenantId, automationId) {
  const result = await db.select().from(automations).where(and5(eq6(automations.id, automationId), eq6(automations.tenantId, tenantId), isNull2(automations.deletedAt))).limit(1);
  return result[0];
}
async function getAutomationByKey(db, tenantId, key) {
  const result = await db.select().from(automations).where(and5(eq6(automations.tenantId, tenantId), eq6(automations.key, key), isNull2(automations.deletedAt))).limit(1);
  return result[0];
}
async function updateAutomation(db, tenantId, automationId, data) {
  await db.update(automations).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(and5(eq6(automations.id, automationId), eq6(automations.tenantId, tenantId), isNull2(automations.deletedAt)));
}
async function upsertAutomationByKey(db, tenantId, key, data) {
  const existing = await getAutomationByKey(db, tenantId, key);
  if (existing) {
    await updateAutomation(db, tenantId, existing.id, {
      name: data.name,
      category: data.category,
      triggerType: data.triggerType,
      triggerConfig: data.triggerConfig,
      conditions: data.conditions,
      actions: data.actions,
      enabled: data.enabled
    });
    return existing;
  }
  const inserted = await db.insert(automations).values({
    tenantId,
    key,
    name: data.name ?? key,
    category: data.category ?? "custom",
    triggerType: data.triggerType ?? "new_lead",
    triggerConfig: data.triggerConfig ?? {},
    conditions: data.conditions ?? [],
    actions: data.actions ?? [],
    enabled: data.enabled ?? true
  });
  return inserted;
}
async function getAutomationsByTrigger(db, tenantId, triggerType) {
  return db.select().from(automations).where(and5(eq6(automations.tenantId, tenantId), eq6(automations.triggerType, triggerType), eq6(automations.enabled, true), isNull2(automations.deletedAt))).orderBy(desc4(automations.createdAt));
}

// server/services/lead.service.ts
init_schema();
import { eq as eq9, and as and8, desc as desc6 } from "drizzle-orm";

// server/_core/crypto.ts
import { createCipheriv, createDecipheriv, randomBytes as randomBytes2 } from "crypto";
var ALGO = "aes-256-gcm";
var KEY_HEX = process.env.ENCRYPTION_KEY ?? "";
function getKey() {
  if (!KEY_HEX || KEY_HEX.length !== 64) return null;
  return Buffer.from(KEY_HEX, "hex");
}
function encrypt(plaintext) {
  const key = getKey();
  if (!key) return plaintext;
  const iv = randomBytes2(12);
  const cipher = createCipheriv(ALGO, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return [
    iv.toString("base64"),
    authTag.toString("base64"),
    encrypted.toString("base64")
  ].join(":");
}
function decrypt(value) {
  const key = getKey();
  if (!key) return value;
  const parts = value.split(":");
  if (parts.length !== 3) return value;
  const [ivB64, authTagB64, ciphertextB64] = parts;
  try {
    const iv = Buffer.from(ivB64, "base64");
    const authTag = Buffer.from(authTagB64, "base64");
    const ciphertext = Buffer.from(ciphertextB64, "base64");
    const decipher = createDecipheriv(ALGO, key, iv);
    decipher.setAuthTag(authTag);
    return decipher.update(ciphertext).toString("utf8") + decipher.final("utf8");
  } catch {
    return value;
  }
}
function encryptIfNeeded(value) {
  if (!value) return value ?? null;
  if (value.split(":").length === 3) return value;
  return encrypt(value);
}

// server/_core/phone.ts
import { createHash as createHash2 } from "crypto";
init_appErrors();
var DEFAULT_REGION = (process.env.PHONE_DEFAULT_REGION || "US").trim() || "US";
function normalizePhoneNumber(input) {
  const normalized = normalizePhoneE164(input, DEFAULT_REGION);
  if (!normalized) {
    throw new AppError("PHONE_INVALID", "Phone must be in E.164 format (e.g. +15550001234)", 400);
  }
  return normalized;
}
function hashPhoneNumber(normalizedPhone) {
  return createHash2("sha256").update(normalizedPhone).digest("hex");
}

// server/services/lead.service.ts
init_logger();
init_usage_service();

// server/services/tcpaCompliance.service.ts
init_schema();
init_logger();
import { eq as eq7, and as and6 } from "drizzle-orm";
async function canSendSms(db, tenantId, leadId) {
  const [lead] = await db.select({
    status: leads.status,
    smsConsentAt: leads.smsConsentAt,
    smsConsentSource: leads.smsConsentSource,
    unsubscribedAt: leads.unsubscribedAt
  }).from(leads).where(and6(eq7(leads.id, leadId), eq7(leads.tenantId, tenantId))).limit(1);
  if (!lead) {
    return { allowed: false, reason: "Lead not found" };
  }
  if (lead.status === "unsubscribed") {
    return { allowed: false, reason: "Lead has unsubscribed" };
  }
  if (!lead.smsConsentAt) {
    return { allowed: false, reason: "No SMS consent on record" };
  }
  return { allowed: true };
}

// server/_core/query-timeout.service.ts
import { sql as sql4 } from "drizzle-orm";
var QueryCircuitBreaker = class {
  constructor(failureThreshold = 5, timeoutMs = 6e4, successThreshold = 3) {
    this.failureThreshold = failureThreshold;
    this.timeoutMs = timeoutMs;
    this.successThreshold = successThreshold;
  }
  failures = 0;
  lastFailureTime = 0;
  state = "closed";
  async execute(query) {
    if (this.state === "open") {
      if (Date.now() - this.lastFailureTime > this.timeoutMs) {
        this.state = "half-open";
        console.log("\u{1F504} Circuit breaker moving to half-open state");
      } else {
        throw new Error("Circuit breaker is open");
      }
    }
    try {
      const result = await query();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }
  onSuccess() {
    this.failures = 0;
    if (this.state === "half-open") {
      this.state = "closed";
      console.log("\u2705 Circuit breaker closed after successful request");
    }
  }
  onFailure() {
    this.failures++;
    this.lastFailureTime = Date.now();
    if (this.failures >= this.failureThreshold) {
      this.state = "open";
      console.log("\u{1F6AB} Circuit breaker opened due to failures");
    }
  }
  getState() {
    return this.state;
  }
  reset() {
    this.failures = 0;
    this.state = "closed";
    console.log("\u{1F504} Circuit breaker reset");
  }
};
var globalCircuitBreaker = new QueryCircuitBreaker();
var QueryPerformanceMonitor = class {
  static metrics = {
    totalQueries: 0,
    slowQueries: 0,
    timeouts: 0,
    averageLatency: 0,
    maxLatency: 0
  };
  static async trackQuery(query, queryName, slowThresholdMs = 1e3) {
    const startTime = Date.now();
    try {
      this.metrics.totalQueries++;
      const result = await query();
      const latency = Date.now() - startTime;
      this.updateMetrics(latency, false);
      if (latency > slowThresholdMs) {
        this.metrics.slowQueries++;
        console.warn(`\u{1F40C} Slow query detected: ${queryName} took ${latency}ms`);
      }
      return result;
    } catch (error) {
      const latency = Date.now() - startTime;
      this.updateMetrics(latency, true);
      if (latency > 5e3) {
        this.metrics.timeouts++;
        console.error(`\u23F0 Query timeout: ${queryName} after ${latency}ms`);
      }
      throw error;
    }
  }
  static updateMetrics(latency, isError) {
    this.metrics.maxLatency = Math.max(this.metrics.maxLatency, latency);
    this.metrics.averageLatency = (this.metrics.averageLatency * (this.metrics.totalQueries - 1) + latency) / this.metrics.totalQueries;
  }
  static getMetrics() {
    return { ...this.metrics };
  }
  static resetMetrics() {
    this.metrics = {
      totalQueries: 0,
      slowQueries: 0,
      timeouts: 0,
      averageLatency: 0,
      maxLatency: 0
    };
  }
};

// server/services/lead-search-optimization.service.ts
init_schema();
init_query_service();
import { eq as eq8, and as and7, desc as desc5, sql as sql5, like, or } from "drizzle-orm";
var searchCache = /* @__PURE__ */ new Map();
var CACHE_TTL = 5 * 60 * 1e3;
var memoryUsage = {
  queries: 0,
  cacheHits: 0,
  cacheMisses: 0,
  lastCleanup: Date.now()
};
async function searchLeads(db, tenantId, options = {}) {
  const cacheKey = `leads_${tenantId}_${JSON.stringify(options)}`;
  const now = Date.now();
  if (searchCache.has(cacheKey)) {
    const cached = searchCache.get(cacheKey);
    if (now - cached.timestamp < CACHE_TTL) {
      memoryUsage.cacheHits++;
      return cached.data;
    }
  }
  memoryUsage.cacheMisses++;
  try {
    const query = db.select({
      id: leads.id,
      name: leads.name,
      phone: leads.phone,
      email: leads.email,
      status: leads.status,
      appointmentAt: leads.appointmentAt,
      createdAt: leads.createdAt,
      updatedAt: leads.updatedAt,
      messageCount: sql5`(SELECT COUNT(*) FROM messages WHERE messages.leadId = ${leads.id})`.as("messageCount")
    }).from(leads).where(
      and7(
        eq8(leads.tenantId, tenantId),
        options.status ? eq8(leads.status, options.status) : void 0,
        options.search ? or(
          like(leads.name, `%${options.search}%`),
          like(leads.phone, `%${options.search}%`),
          like(leads.email, `%${options.search}%`)
        ) : void 0
      )
    ).orderBy(desc5(leads.createdAt)).limit(options.limit || 20).offset(((options.page || 1) - 1) * (options.limit || 20));
    const result = await withQueryTimeout(
      "Lead search query",
      query,
      1e4
    );
    searchCache.set(cacheKey, { data: result, timestamp: now });
    memoryUsage.queries++;
    if (now - memoryUsage.lastCleanup > 6e4) {
      cleanupCache();
      memoryUsage.lastCleanup = now;
    }
    return result;
  } catch (error) {
    console.error("Lead search error:", error);
    throw new Error(`Search failed: ${error.message}`);
  }
}
async function getLeadByIdOptimized(db, tenantId, leadId) {
  const cacheKey = `lead_${tenantId}_${leadId}`;
  const now = Date.now();
  if (searchCache.has(cacheKey)) {
    const cached = searchCache.get(cacheKey);
    if (now - cached.timestamp < CACHE_TTL) {
      memoryUsage.cacheHits++;
      return cached.data;
    }
  }
  memoryUsage.cacheMisses++;
  try {
    const query = db.select({
      id: leads.id,
      name: leads.name,
      phone: leads.phone,
      email: leads.email,
      status: leads.status,
      appointmentAt: leads.appointmentAt,
      createdAt: leads.createdAt,
      updatedAt: leads.updatedAt
    }).from(leads).where(
      and7(
        eq8(leads.tenantId, tenantId),
        eq8(leads.id, leadId)
      )
    ).limit(1);
    const result = await withQueryTimeout(
      "Get lead by ID",
      query,
      5e3
    );
    const lead = result[0] || null;
    if (lead) {
      searchCache.set(cacheKey, { data: lead, timestamp: now });
    }
    memoryUsage.queries++;
    return lead;
  } catch (error) {
    console.error("Get lead by ID error:", error);
    throw new Error(`Failed to get lead: ${error.message}`);
  }
}
function cleanupCache() {
  const now = Date.now();
  const keysToDelete = [];
  for (const [key, value] of searchCache.entries()) {
    if (now - value.timestamp > CACHE_TTL) {
      keysToDelete.push(key);
    }
  }
  keysToDelete.forEach((key) => searchCache.delete(key));
  if (keysToDelete.length > 0) {
    console.log(`Cleaned up ${keysToDelete.length} expired cache entries`);
  }
}

// server/_core/message-encryption.ts
import crypto3 from "crypto";
var MessageEncryption = class {
  algorithm = "aes-256-gcm";
  keyLength = 32;
  ivLength = 16;
  tagLength = 16;
  key;
  constructor() {
    const encryptionKey = process.env.ENCRYPTION_KEY;
    if (!encryptionKey) {
      throw new Error("ENCRYPTION_KEY environment variable is required");
    }
    this.key = crypto3.scryptSync(encryptionKey, "salt", this.keyLength);
  }
  /**
   * Encrypt message body
   */
  encrypt(message) {
    try {
      const iv = crypto3.randomBytes(this.ivLength);
      const cipher = crypto3.createCipheriv(this.algorithm, this.key, iv);
      cipher.setAAD(Buffer.from("message-body", "utf8"));
      let encrypted = cipher.update(message, "utf8", "hex");
      encrypted += cipher.final("hex");
      const tag = cipher.getAuthTag();
      return {
        encrypted,
        iv: iv.toString("hex"),
        tag: tag.toString("hex")
      };
    } catch (error) {
      console.error("Encryption error:", error);
      throw new Error(`Failed to encrypt message: ${error.message}`);
    }
  }
  /**
   * Decrypt message body
   */
  decrypt(encryptedData) {
    try {
      const decipher = crypto3.createDecipheriv(this.algorithm, this.key, Buffer.from(encryptedData.iv, "hex"));
      decipher.setAAD(Buffer.from("message-body", "utf8"));
      decipher.setAuthTag(Buffer.from(encryptedData.tag, "hex"));
      let decrypted = decipher.update(encryptedData.encrypted, "hex", "utf8");
      decrypted += decipher.final("utf8");
      return {
        decrypted,
        success: true
      };
    } catch (error) {
      console.error("Decryption error:", error);
      return {
        decrypted: "",
        success: false
      };
    }
  }
  /**
   * Encrypt phone number (for storage)
   */
  encryptPhoneNumber(phone) {
    try {
      const normalizedPhone = this.normalizePhone(phone);
      const iv = crypto3.randomBytes(this.ivLength);
      const cipher = crypto3.createCipheriv("aes-256-cbc", this.key, iv);
      let encrypted = cipher.update(normalizedPhone, "utf8", "hex");
      encrypted += cipher.final("hex");
      return iv.toString("hex") + ":" + encrypted;
    } catch (error) {
      console.error("Phone encryption error:", error);
      throw new Error(`Failed to encrypt phone: ${error.message}`);
    }
  }
  /**
   * Decrypt phone number
   */
  decryptPhoneNumber(encryptedPhone) {
    try {
      const parts = encryptedPhone.split(":");
      if (parts.length !== 2) {
        throw new Error("Invalid encrypted phone format");
      }
      const iv = Buffer.from(parts[0], "hex");
      const encrypted = parts[1];
      const decipher = crypto3.createDecipheriv("aes-256-cbc", this.key, iv);
      let decrypted = decipher.update(encrypted, "hex", "utf8");
      decrypted += decipher.final("utf8");
      return decrypted;
    } catch (error) {
      console.error("Phone decryption error:", error);
      throw new Error(`Failed to decrypt phone: ${error.message}`);
    }
  }
  /**
   * Hash sensitive data for comparison
   */
  hashSensitiveData(data) {
    return crypto3.createHash("sha256").update(data + process.env.HASH_SALT || "default-salt").digest("hex");
  }
  /**
   * Generate secure random token
   */
  generateSecureToken(length = 32) {
    return crypto3.randomBytes(length).toString("hex");
  }
  /**
   * Verify data integrity
   */
  verifyIntegrity(data, hash) {
    const computedHash = this.hashSensitiveData(data);
    return computedHash === hash;
  }
  /**
   * Normalize phone number format
   */
  normalizePhone(phone) {
    const digits = phone.replace(/\D/g, "");
    if (digits.length === 10) {
      return `+1${digits}`;
    } else if (digits.length > 10 && !digits.startsWith("+")) {
      return `+${digits}`;
    }
    return digits.startsWith("+") ? digits : `+${digits}`;
  }
  /**
   * Check if encryption key is properly configured
   */
  isConfigured() {
    return !!process.env.ENCRYPTION_KEY && process.env.ENCRYPTION_KEY.length >= 16;
  }
  /**
   * Rotate encryption key (for security maintenance)
   */
  rotateKey(newKey) {
    process.env.ENCRYPTION_KEY = newKey;
    const newDerivedKey = crypto3.scryptSync(newKey, "salt", this.keyLength);
    this.key = newDerivedKey;
    console.log("\u{1F511} Encryption key rotated successfully");
  }
};
var messageEncryption = new MessageEncryption();
var encryptMessage = (message) => messageEncryption.encrypt(message);

// server/services/lead.service.ts
function presentLead(lead) {
  if (!lead) return lead;
  return {
    ...lead,
    phone: lead.phone ? decrypt(lead.phone) : lead.phone,
    name: lead.name ? decrypt(lead.name) : lead.name,
    email: lead.email ? decrypt(lead.email) : lead.email
  };
}
function normalizeTags(input) {
  if (!Array.isArray(input)) return [];
  return Array.from(new Set(input.filter((tag) => typeof tag === "string" && tag.length > 0)));
}
async function setLeadTags(db, tenantId, leadId, tags) {
  await db.update(leads).set({ tags: normalizeTags(tags), updatedAt: /* @__PURE__ */ new Date() }).where(and8(eq9(leads.id, leadId), eq9(leads.tenantId, tenantId)));
}
async function addLeadTags(db, tenantId, leadId, tags) {
  const [lead] = await db.select({ tags: leads.tags }).from(leads).where(and8(eq9(leads.id, leadId), eq9(leads.tenantId, tenantId))).limit(1);
  const nextTags = normalizeTags([...Array.isArray(lead?.tags) ? lead.tags : [], ...tags]);
  await setLeadTags(db, tenantId, leadId, nextTags);
}
async function getLeads(db, tenantId, opts) {
  return await QueryPerformanceMonitor.trackQuery(
    () => searchLeads(db, tenantId, opts),
    "getLeads",
    1e3
    // 1 second slow threshold
  );
}
async function getLeadById(db, tenantId, leadId) {
  const lead = await QueryPerformanceMonitor.trackQuery(
    () => getLeadByIdOptimized(db, tenantId, leadId),
    "getLeadById",
    500
    // 500ms slow threshold
  );
  return presentLead(lead);
}
async function createLead(db, data) {
  const normalizedPhone = normalizePhoneNumber(data.phone);
  const phoneHash = hashPhoneNumber(normalizedPhone);
  const [existing] = await db.select({ id: leads.id }).from(leads).where(and8(eq9(leads.tenantId, data.tenantId), eq9(leads.phoneHash, phoneHash))).limit(1);
  if (existing) return { success: true, duplicate: true };
  await db.insert(leads).values({
    tenantId: data.tenantId,
    phone: encryptIfNeeded(normalizedPhone) ?? "",
    phoneHash,
    name: encryptIfNeeded(data.name) ?? void 0,
    email: encryptIfNeeded(data.email) ?? void 0,
    source: data.source,
    notes: data.notes
  });
  return { success: true };
}
async function updateLead(db, tenantId, leadId, data) {
  const updatePayload = {
    updatedAt: /* @__PURE__ */ new Date()
  };
  if (typeof data.status !== "undefined") updatePayload.status = data.status;
  if (typeof data.notes !== "undefined") updatePayload.notes = data.notes;
  if (typeof data.appointmentAt !== "undefined") updatePayload.appointmentAt = data.appointmentAt;
  if (typeof data.name !== "undefined") updatePayload.name = encryptIfNeeded(data.name);
  if (typeof data.email !== "undefined") updatePayload.email = encryptIfNeeded(data.email || null);
  if (typeof data.phone !== "undefined") {
    const normalizedPhone = normalizePhoneNumber(data.phone);
    updatePayload.phone = encryptIfNeeded(normalizedPhone);
    updatePayload.phoneHash = hashPhoneNumber(normalizedPhone);
  }
  await db.update(leads).set(updatePayload).where(and8(eq9(leads.id, leadId), eq9(leads.tenantId, tenantId)));
}
async function updateLeadStatus(db, tenantId, leadId, status) {
  await db.update(leads).set({ status, updatedAt: /* @__PURE__ */ new Date() }).where(and8(eq9(leads.id, leadId), eq9(leads.tenantId, tenantId)));
}
async function getMessagesByLeadId(db, tenantId, leadId) {
  const rows = await db.select().from(messages).where(and8(eq9(messages.leadId, leadId), eq9(messages.tenantId, tenantId))).orderBy(messages.createdAt);
  return rows.map((message) => ({
    ...message,
    fromNumber: message.fromNumber ? decrypt(message.fromNumber) : message.fromNumber,
    toNumber: message.toNumber ? decrypt(message.toNumber) : message.toNumber
  }));
}
async function createMessage(db, data) {
  if (!messageEncryption.isConfigured()) {
    logger.warn("Message encryption not configured, storing plain text");
  }
  let encryptedBody = data.body;
  let encryptedFromNumber = data.fromNumber;
  let encryptedToNumber = data.toNumber;
  if (messageEncryption.isConfigured()) {
    try {
      const encryptedMsg = encryptMessage(data.body);
      encryptedBody = `${encryptedMsg.encrypted}:${encryptedMsg.iv}:${encryptedMsg.tag}`;
      if (data.fromNumber) {
        encryptedFromNumber = messageEncryption.encryptPhoneNumber(data.fromNumber);
      }
      if (data.toNumber) {
        encryptedToNumber = messageEncryption.encryptPhoneNumber(data.toNumber);
      }
    } catch (error) {
      logger.error("Message encryption failed:", error);
      encryptedBody = encryptIfNeeded(data.body);
      encryptedFromNumber = data.fromNumber ? encryptIfNeeded(data.fromNumber) : void 0;
      encryptedToNumber = data.toNumber ? encryptIfNeeded(data.toNumber) : void 0;
    }
  }
  return db.transaction(async (tx) => {
    const result = await tx.insert(messages).values({
      ...data,
      body: encryptedBody,
      fromNumber: encryptedFromNumber,
      toNumber: encryptedToNumber,
      status: data.status || "sent"
    });
    await tx.update(leads).set({ lastMessageAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(and8(eq9(leads.id, data.leadId), eq9(leads.tenantId, data.tenantId)));
    if (data.direction === "outbound" && data.status !== "failed") {
      const incremented = await incrementOutboundUsageIfAllowed(tx, data.tenantId);
      if (!incremented) {
        logger.error("Usage counter could not be incremented \u2014 cap race, missing usage row, or plan mismatch", {
          tenantId: data.tenantId,
          leadId: data.leadId
        });
      }
    }
    return result;
  });
}
async function getRecentMessages(db, tenantId, limit = 10) {
  const rows = await db.select({ msg: messages, lead: leads }).from(messages).innerJoin(leads, eq9(messages.leadId, leads.id)).where(eq9(messages.tenantId, tenantId)).orderBy(desc6(messages.createdAt)).limit(limit);
  return rows.map((row) => ({
    msg: {
      ...row.msg,
      fromNumber: row.msg.fromNumber ? decrypt(row.msg.fromNumber) : row.msg.fromNumber,
      toNumber: row.msg.toNumber ? decrypt(row.msg.toNumber) : row.msg.toNumber
    },
    lead: presentLead(row.lead)
  }));
}
async function sendMessage(db, tenantId, leadId, body, idempotencyKey) {
  const complianceCheck = await canSendSms(db, tenantId, leadId);
  if (!complianceCheck.allowed) {
    logger.warn("SMS blocked due to TCPA compliance", {
      tenantId,
      leadId,
      reason: complianceCheck.reason
    });
    return {
      success: false,
      error: `SMS not allowed: ${complianceCheck.reason}`
    };
  }
  if (idempotencyKey) {
    const [existing] = await db.select().from(messages).where(and8(eq9(messages.tenantId, tenantId), eq9(messages.idempotencyKey, idempotencyKey))).limit(1);
    if (existing) {
      return {
        success: existing.status !== "failed",
        sid: existing.twilioSid || void 0,
        deduplicated: true,
        errorCode: existing.providerError || void 0
      };
    }
  }
  const [lead] = await db.select().from(leads).where(and8(eq9(leads.id, leadId), eq9(leads.tenantId, tenantId))).limit(1);
  if (!lead) return { success: false, error: "Lead not found" };
  const phone = decrypt(lead.phone);
  const { sendSMS: sendSMS2 } = await Promise.resolve().then(() => (init_sms(), sms_exports));
  const res = await sendSMS2(phone, body, void 0, tenantId);
  await createMessage(db, {
    tenantId,
    leadId,
    direction: "outbound",
    body,
    status: res.success ? "sent" : "failed",
    twilioSid: res.sid,
    provider: res.provider,
    providerError: [res.errorCode, res.error].filter(Boolean).join(": ") || void 0,
    retryCount: res.retryCount || 0,
    idempotencyKey,
    failedAt: res.success ? void 0 : /* @__PURE__ */ new Date(),
    deliveredAt: res.success ? /* @__PURE__ */ new Date() : void 0
  });
  return { success: res.success, sid: res.sid, errorCode: res.errorCode };
}

// server/services/tenant.service.ts
init_schema();
import { eq as eq10, desc as desc7, and as and9, sql as sql7, isNull as isNull3 } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
async function getTenantId(db, userId) {
  const user = await getUserById(db, userId);
  if (user?.tenantId) return user.tenantId;
  throw new TRPCError({ code: "FORBIDDEN", message: "No tenant found" });
}
async function getTenantById(db, id) {
  const result = await db.select().from(tenants).where(eq10(tenants.id, id)).limit(1);
  return result[0];
}
async function getAllTenants(db, page = 1, limit = 50) {
  const offset = (page - 1) * limit;
  const [rows, countRows] = await Promise.all([
    db.select().from(tenants).orderBy(desc7(tenants.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql7`COUNT(*)` }).from(tenants)
  ]);
  return { rows, total: Number(countRows[0]?.count ?? 0) };
}
async function updateTenant(db, id, data) {
  await db.update(tenants).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq10(tenants.id, id));
}
async function getSubscriptionByTenantId(db, tenantId) {
  const result = await db.select().from(subscriptions).where(eq10(subscriptions.tenantId, tenantId)).orderBy(desc7(subscriptions.createdAt)).limit(1);
  return result[0];
}
function isSubscriptionEntitled(subscription) {
  if (!subscription) return false;
  const now = Date.now();
  if (subscription.status === "active") return true;
  if (subscription.status === "trialing") {
    return subscription.trialEndsAt ? new Date(subscription.trialEndsAt).getTime() > now : true;
  }
  if (subscription.status === "past_due") {
    return subscription.currentPeriodEnd ? new Date(subscription.currentPeriodEnd).getTime() > now : false;
  }
  return false;
}
async function tenantHasAutomationAccess(db, tenantId) {
  const subscription = await getSubscriptionByTenantId(db, tenantId);
  return isSubscriptionEntitled(subscription);
}
async function getUsageByTenantId(db, tenantId) {
  const result = await db.select().from(usage).where(eq10(usage.tenantId, tenantId)).orderBy(desc7(usage.createdAt)).limit(1);
  return result[0];
}
async function getAllPlans(db) {
  return db.select().from(plans).orderBy(plans.priceMonthly);
}
async function getPhoneNumbersByTenantId(db, tenantId) {
  return db.select().from(phoneNumbers).where(and9(eq10(phoneNumbers.tenantId, tenantId), isNull3(phoneNumbers.deletedAt))).orderBy(desc7(phoneNumbers.createdAt));
}
async function addPhoneNumber(db, tenantId, data) {
  await db.insert(phoneNumbers).values({ tenantId, number: normalizePhoneNumber(data.number), label: data.title });
}
async function removePhoneNumber(db, tenantId, id) {
  await db.update(phoneNumbers).set({ deletedAt: /* @__PURE__ */ new Date() }).where(and9(eq10(phoneNumbers.id, id), eq10(phoneNumbers.tenantId, tenantId), isNull3(phoneNumbers.deletedAt)));
}
async function setDefaultPhoneNumber(db, tenantId, id) {
  await db.update(phoneNumbers).set({ isDefault: false }).where(and9(eq10(phoneNumbers.tenantId, tenantId), isNull3(phoneNumbers.deletedAt)));
  await db.update(phoneNumbers).set({ isDefault: true }).where(and9(eq10(phoneNumbers.id, id), eq10(phoneNumbers.tenantId, tenantId), isNull3(phoneNumbers.deletedAt)));
}
async function setInboundPhoneNumber(db, tenantId, id) {
  await db.update(phoneNumbers).set({ isInbound: false }).where(and9(eq10(phoneNumbers.tenantId, tenantId), isNull3(phoneNumbers.deletedAt)));
  await db.update(phoneNumbers).set({ isInbound: true }).where(and9(eq10(phoneNumbers.id, id), eq10(phoneNumbers.tenantId, tenantId), isNull3(phoneNumbers.deletedAt)));
}

// server/services/recovery-attribution.service.ts
init_schema();
init_logger();
import { eq as eq11, and as and10, sql as sql8, desc as desc8, gte as gte2, lte as lte2, inArray } from "drizzle-orm";
function generateTrackingToken(tenantId, leadId) {
  const ts = Date.now().toString(36);
  const rand = crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  return `rb_${tenantId}_${leadId}_${ts}_${rand}`;
}
async function createRecoveryEvent(db, data) {
  const trackingToken = generateTrackingToken(data.tenantId, data.leadId);
  const result = await db.insert(recoveryEvents).values({
    tenantId: data.tenantId,
    leadId: data.leadId,
    automationId: data.automationId,
    messageId: data.messageId,
    leakageType: data.leakageType,
    originalAppointmentId: data.originalAppointmentId,
    trackingToken,
    status: "sent",
    estimatedRevenue: data.estimatedRevenue || 0,
    sentAt: /* @__PURE__ */ new Date()
  });
  const recoveryEventId = Number(result[0]?.insertId ?? result.insertId ?? 0);
  logger.info("Recovery event created", {
    recoveryEventId,
    trackingToken,
    tenantId: data.tenantId,
    leadId: data.leadId,
    leakageType: data.leakageType
  });
  return { recoveryEventId, trackingToken };
}
async function markRecoveryConverted(db, tenantId, leadId, data) {
  const candidates = await db.select().from(recoveryEvents).where(
    and10(
      eq11(recoveryEvents.tenantId, tenantId),
      eq11(recoveryEvents.leadId, leadId),
      inArray(recoveryEvents.status, ["sent", "responded"])
    )
  ).orderBy(desc8(recoveryEvents.sentAt)).limit(10);
  if (candidates.length === 0) {
    logger.info("No active recovery events for lead conversion", { tenantId, leadId });
    return { primaryEventId: null };
  }
  let primaryEvent = candidates[0];
  if (data.trackingToken) {
    const specific = candidates.find((e) => e.trackingToken === data.trackingToken);
    if (specific) primaryEvent = specific;
  }
  const now = /* @__PURE__ */ new Date();
  for (const event of candidates) {
    const isPrimary = event.id === primaryEvent.id;
    await db.update(recoveryEvents).set({
      status: "converted",
      convertedAt: now,
      recoveredAppointmentId: data.recoveredAppointmentId,
      estimatedRevenue: isPrimary ? data.estimatedRevenue || event.estimatedRevenue : event.estimatedRevenue,
      isPrimaryAttribution: isPrimary,
      updatedAt: now
    }).where(eq11(recoveryEvents.id, event.id));
  }
  await db.update(leads).set({
    recoverySource: "rebookd_automation",
    updatedAt: now
  }).where(and10(eq11(leads.id, leadId), eq11(leads.tenantId, tenantId)));
  logger.info("Recovery conversion attributed", {
    primaryEventId: primaryEvent.id,
    totalCandidates: candidates.length,
    tenantId,
    leadId,
    trackingToken: primaryEvent.trackingToken
  });
  return { primaryEventId: primaryEvent.id };
}
async function markRecoveryRealized(db, tenantId, leadId, data) {
  const now = /* @__PURE__ */ new Date();
  const conditions = [
    eq11(recoveryEvents.tenantId, tenantId),
    eq11(recoveryEvents.leadId, leadId),
    eq11(recoveryEvents.isPrimaryAttribution, true)
  ];
  if (data.recoveryEventId) {
    conditions.push(eq11(recoveryEvents.id, data.recoveryEventId));
  }
  await db.update(recoveryEvents).set({
    status: "realized",
    stripePaymentIntentId: data.stripePaymentIntentId,
    stripeInvoiceId: data.stripeInvoiceId,
    realizedRevenue: data.realizedRevenue,
    realizedAt: now,
    updatedAt: now
  }).where(and10(...conditions));
  logger.info("Recovery realized (payment captured)", {
    tenantId,
    leadId,
    stripePaymentIntentId: data.stripePaymentIntentId,
    realizedRevenue: data.realizedRevenue
  });
}
async function markManualRecovery(db, tenantId, leadId, data) {
  const now = /* @__PURE__ */ new Date();
  if (data.recoveryEventId) {
    await db.update(recoveryEvents).set({
      status: "manual_realized",
      realizedRevenue: data.realizedRevenue,
      realizedAt: now,
      notes: data.notes || "Manually marked as recovered (off-platform payment)",
      updatedAt: now
    }).where(
      and10(
        eq11(recoveryEvents.id, data.recoveryEventId),
        eq11(recoveryEvents.tenantId, tenantId)
      )
    );
  } else {
    const [event] = await db.select().from(recoveryEvents).where(
      and10(
        eq11(recoveryEvents.tenantId, tenantId),
        eq11(recoveryEvents.leadId, leadId),
        eq11(recoveryEvents.isPrimaryAttribution, true),
        inArray(recoveryEvents.status, ["sent", "responded", "converted"])
      )
    ).orderBy(desc8(recoveryEvents.sentAt)).limit(1);
    if (event) {
      await db.update(recoveryEvents).set({
        status: "manual_realized",
        realizedRevenue: data.realizedRevenue,
        realizedAt: now,
        notes: data.notes || "Manually marked as recovered (off-platform payment)",
        updatedAt: now
      }).where(eq11(recoveryEvents.id, event.id));
    } else {
      const trackingToken = generateTrackingToken(tenantId, leadId);
      await db.insert(recoveryEvents).values({
        tenantId,
        leadId,
        leakageType: "manual",
        trackingToken,
        status: "manual_realized",
        realizedRevenue: data.realizedRevenue,
        isPrimaryAttribution: true,
        notes: data.notes || "Manual recovery \u2014 no prior automation",
        sentAt: now,
        realizedAt: now
      });
    }
  }
  logger.info("Manual recovery marked", { tenantId, leadId, realizedRevenue: data.realizedRevenue });
}
async function getAttributedRevenueMetrics(db, tenantId) {
  const [metrics] = await db.select({
    totalSent: sql8`SUM(CASE WHEN status IN ('sent','responded','converted','realized','manual_realized') THEN 1 ELSE 0 END)`,
    totalConverted: sql8`SUM(CASE WHEN status IN ('converted','realized','manual_realized') AND isPrimaryAttribution = true THEN 1 ELSE 0 END)`,
    totalRealized: sql8`SUM(CASE WHEN status IN ('realized','manual_realized') AND isPrimaryAttribution = true THEN 1 ELSE 0 END)`,
    estimatedRevenue: sql8`SUM(CASE WHEN status IN ('converted','realized','manual_realized') AND isPrimaryAttribution = true THEN estimatedRevenue ELSE 0 END)`,
    realizedRevenue: sql8`SUM(CASE WHEN status IN ('realized','manual_realized') AND isPrimaryAttribution = true THEN realizedRevenue ELSE 0 END)`,
    totalFailed: sql8`SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END)`,
    totalExpired: sql8`SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END)`
  }).from(recoveryEvents).where(eq11(recoveryEvents.tenantId, tenantId));
  const sent = Number(metrics?.totalSent ?? 0);
  const converted = Number(metrics?.totalConverted ?? 0);
  const realized = Number(metrics?.totalRealized ?? 0);
  return {
    totalRecoveryAttempts: sent,
    totalConverted: converted,
    totalRealized: realized,
    conversionRate: sent > 0 ? converted / sent * 100 : 0,
    realizationRate: converted > 0 ? realized / converted * 100 : 0,
    estimatedRecoveredRevenue: Number(metrics?.estimatedRevenue ?? 0),
    // potential (booked)
    realizedRecoveredRevenue: Number(metrics?.realizedRevenue ?? 0),
    // actual (paid)
    totalFailed: Number(metrics?.totalFailed ?? 0),
    totalExpired: Number(metrics?.totalExpired ?? 0)
  };
}
async function getAutomationAttribution(db, tenantId) {
  const rows = await db.select({
    automationId: recoveryEvents.automationId,
    automationName: automations.name,
    leakageType: recoveryEvents.leakageType,
    totalSent: sql8`COUNT(*)`,
    totalConverted: sql8`SUM(CASE WHEN ${recoveryEvents.status} IN ('converted','realized','manual_realized') AND ${recoveryEvents.isPrimaryAttribution} = true THEN 1 ELSE 0 END)`,
    totalRealized: sql8`SUM(CASE WHEN ${recoveryEvents.status} IN ('realized','manual_realized') AND ${recoveryEvents.isPrimaryAttribution} = true THEN 1 ELSE 0 END)`,
    estimatedRevenue: sql8`SUM(CASE WHEN ${recoveryEvents.isPrimaryAttribution} = true THEN ${recoveryEvents.estimatedRevenue} ELSE 0 END)`,
    realizedRevenue: sql8`SUM(CASE WHEN ${recoveryEvents.isPrimaryAttribution} = true THEN ${recoveryEvents.realizedRevenue} ELSE 0 END)`
  }).from(recoveryEvents).leftJoin(automations, eq11(recoveryEvents.automationId, automations.id)).where(eq11(recoveryEvents.tenantId, tenantId)).groupBy(recoveryEvents.automationId, automations.name, recoveryEvents.leakageType);
  return rows.map((r) => ({
    automationId: r.automationId,
    automationName: r.automationName || "Manual/Unknown",
    leakageType: r.leakageType,
    totalSent: Number(r.totalSent),
    totalConverted: Number(r.totalConverted),
    totalRealized: Number(r.totalRealized),
    conversionRate: Number(r.totalSent) > 0 ? Number(r.totalConverted) / Number(r.totalSent) * 100 : 0,
    estimatedRevenue: Number(r.estimatedRevenue),
    realizedRevenue: Number(r.realizedRevenue)
  }));
}
async function getRecoveryLedger(db, tenantId, options = {}) {
  const conditions = [
    eq11(recoveryEvents.tenantId, tenantId),
    eq11(recoveryEvents.isPrimaryAttribution, true)
  ];
  if (options.startDate) {
    conditions.push(gte2(recoveryEvents.sentAt, options.startDate));
  }
  if (options.endDate) {
    conditions.push(lte2(recoveryEvents.sentAt, options.endDate));
  }
  if (options.statusFilter && options.statusFilter.length > 0) {
    conditions.push(inArray(recoveryEvents.status, options.statusFilter));
  }
  const rows = await db.select({
    recoveryEventId: recoveryEvents.id,
    leadId: recoveryEvents.leadId,
    leadName: leads.name,
    leakageType: recoveryEvents.leakageType,
    automationName: automations.name,
    trackingToken: recoveryEvents.trackingToken,
    status: recoveryEvents.status,
    estimatedRevenue: recoveryEvents.estimatedRevenue,
    realizedRevenue: recoveryEvents.realizedRevenue,
    stripePaymentIntentId: recoveryEvents.stripePaymentIntentId,
    stripeInvoiceId: recoveryEvents.stripeInvoiceId,
    notes: recoveryEvents.notes,
    sentAt: recoveryEvents.sentAt,
    convertedAt: recoveryEvents.convertedAt,
    realizedAt: recoveryEvents.realizedAt
  }).from(recoveryEvents).leftJoin(leads, eq11(recoveryEvents.leadId, leads.id)).leftJoin(automations, eq11(recoveryEvents.automationId, automations.id)).where(and10(...conditions)).orderBy(desc8(recoveryEvents.sentAt)).limit(options.limit || 500).offset(options.offset || 0);
  const entries = rows.map((r) => ({
    recoveryEventId: r.recoveryEventId,
    date: r.sentAt ? new Date(r.sentAt).toISOString().split("T")[0] : "",
    leadId: r.leadId,
    leadName: r.leadName,
    leakageType: r.leakageType,
    automationName: r.automationName,
    trackingToken: r.trackingToken,
    status: r.status,
    estimatedRevenue: r.estimatedRevenue / 100,
    realizedRevenue: r.realizedRevenue / 100,
    stripePaymentIntentId: r.stripePaymentIntentId,
    stripeInvoiceId: r.stripeInvoiceId,
    notes: r.notes,
    sentAt: r.sentAt ? new Date(r.sentAt).toISOString() : "",
    convertedAt: r.convertedAt ? new Date(r.convertedAt).toISOString() : null,
    realizedAt: r.realizedAt ? new Date(r.realizedAt).toISOString() : null
  }));
  const totals = entries.reduce(
    (acc, e) => ({
      estimated: acc.estimated + e.estimatedRevenue,
      realized: acc.realized + e.realizedRevenue,
      count: acc.count + 1
    }),
    { estimated: 0, realized: 0, count: 0 }
  );
  return { entries, totals };
}
function ledgerToCSV(entries) {
  const headers = [
    "Date",
    "Recovery Event ID",
    "Lead ID",
    "Lead Name",
    "Leakage Type",
    "Automation",
    "Tracking Token",
    "Status",
    "Estimated Revenue",
    "Realized Revenue",
    "Stripe Payment Intent",
    "Stripe Invoice",
    "Sent At",
    "Converted At",
    "Realized At",
    "Notes"
  ];
  const rows = entries.map((e) => [
    e.date,
    e.recoveryEventId,
    e.leadId,
    `"${(e.leadName || "").replace(/"/g, '""')}"`,
    e.leakageType,
    `"${(e.automationName || "").replace(/"/g, '""')}"`,
    e.trackingToken,
    e.status,
    `$${e.estimatedRevenue.toFixed(2)}`,
    `$${e.realizedRevenue.toFixed(2)}`,
    e.stripePaymentIntentId || "",
    e.stripeInvoiceId || "",
    e.sentAt,
    e.convertedAt || "",
    e.realizedAt || "",
    `"${(e.notes || "").replace(/"/g, '""')}"`
  ]);
  return [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
}

// server/services/system.service.ts
init_schema();
import { eq as eq12, desc as desc9, and as and11 } from "drizzle-orm";
async function getSystemErrors(db, type, limit = 50) {
  const conditions = type ? [eq12(systemErrorLogs.type, type)] : [];
  return db.select().from(systemErrorLogs).where(conditions.length ? and11(...conditions) : void 0).orderBy(desc9(systemErrorLogs.createdAt)).limit(limit);
}
async function createSystemError(db, data) {
  const row = {
    type: data.type === "system" ? "webhook" : data.type,
    message: data.type === "system" ? `[system] ${data.message}` : data.message,
    detail: data.detail,
    tenantId: data.tenantId
  };
  await db.insert(systemErrorLogs).values(row);
}
async function getWebhookLogs(db, tenantId, limit = 50, page = 1) {
  const conditions = tenantId ? [eq12(webhookLogs.tenantId, tenantId)] : [];
  const offset = (page - 1) * limit;
  return db.select().from(webhookLogs).where(conditions.length ? and11(...conditions) : void 0).orderBy(desc9(webhookLogs.createdAt)).limit(limit).offset(offset);
}

// server/services/automationRunner.ts
var MAX_RETRY = 3;
async function sendWithRetry(to, body, fromNumber, tenantId, attempt = 1) {
  const res = await sendSMS(to, body, fromNumber, tenantId);
  if (res.success) return res;
  if (attempt < MAX_RETRY) {
    return sendWithRetry(to, body, fromNumber, tenantId, attempt + 1);
  }
  return res;
}
function eventToTriggerTypes(eventType) {
  return {
    "lead.created": ["new_lead"],
    "message.received": ["inbound_message"],
    "message.sent": ["inbound_message"],
    "appointment.booked": ["appointment_reminder"],
    "appointment.no_show": ["time_delay", "appointment_reminder"],
    "appointment.cancelled": ["appointment_reminder"]
  }[eventType] ?? [];
}
function shouldAutomateForEvent(automation, event) {
  return eventToTriggerTypes(event.type).includes(automation.triggerType);
}
var RECOVERY_EVENT_TYPES = /* @__PURE__ */ new Set([
  "appointment.no_show",
  "appointment.cancelled",
  "lead.created"
  // lead capture recovery
]);
function getLeakageType(eventType) {
  switch (eventType) {
    case "appointment.no_show":
      return "no_show";
    case "appointment.cancelled":
      return "cancellation";
    case "lead.created":
      return "new_lead";
    default:
      return "followup";
  }
}
async function executeStep(db, step, event, tenantId, leadId, automationId) {
  switch (step.type) {
    case "sms":
    case "send_message": {
      if (leadId) {
        const tcpaCheck = await canSendSms(db, tenantId, leadId);
        if (!tcpaCheck.allowed) {
          console.log(`TCPA block: skipping SMS to lead ${leadId} \u2014 ${tcpaCheck.reason}`);
          return;
        }
      }
      let toPhone = event.data?.phone ?? event.data?.leadPhone;
      if (!toPhone && leadId) {
        const lead = await getLeadById(db, tenantId, leadId);
        toPhone = lead?.phone;
      }
      if (!toPhone) throw new Error("No target phone number for sms step");
      const normalized = normalizePhoneE164(String(toPhone));
      if (!normalized) throw new Error("Invalid phone number for SMS automation step");
      let recoveryEventId;
      let trackingToken;
      const isRecoveryEvent = leadId && RECOVERY_EVENT_TYPES.has(event.type);
      if (isRecoveryEvent) {
        const recovery = await createRecoveryEvent(db, {
          tenantId,
          leadId,
          automationId,
          leakageType: getLeakageType(event.type),
          originalAppointmentId: event.data?.appointmentId ? String(event.data.appointmentId) : void 0,
          estimatedRevenue: Number(event.data?.estimatedRevenue || 25e3)
          // default $250 in cents
        });
        recoveryEventId = recovery.recoveryEventId;
        trackingToken = recovery.trackingToken;
      }
      let body = resolveTemplate(String(step.message || step.body || ""), { ...event.data });
      if (trackingToken) {
        body += `

Ref: ${trackingToken}`;
      }
      const res = await sendWithRetry(normalized, body, void 0, tenantId);
      if (leadId) {
        await createMessage(db, {
          tenantId,
          leadId,
          direction: "outbound",
          body,
          status: res.success ? "sent" : "failed",
          twilioSid: res.sid,
          provider: res.provider,
          providerError: [res.errorCode, res.error].filter(Boolean).join(": ") || void 0,
          retryCount: res.retryCount || 0,
          deliveredAt: res.success ? /* @__PURE__ */ new Date() : void 0,
          failedAt: res.success ? void 0 : /* @__PURE__ */ new Date(),
          automationId
        });
      }
      return;
    }
    case "webhook": {
      if (!step.url) throw new Error("No webhook URL provided");
      const response = await fetch(step.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ event, step })
      });
      if (!response.ok) throw new Error(`Webhook call failed ${response.status}`);
      return;
    }
    default:
      return;
  }
}
async function continueAutomation(db, automation, event, startStepIndex, leadId) {
  const steps = Array.isArray(automation.actions) ? automation.actions : [];
  for (let index2 = startStepIndex; index2 < steps.length; index2 += 1) {
    const step = steps[index2];
    if (step?.type === "delay") {
      const seconds = Number(step.value ?? 0);
      if (seconds > 0) {
        await enqueueAutomationJob(db, {
          tenantId: event.tenantId,
          automationId: automation.id,
          leadId,
          eventType: event.type,
          eventData: event.data,
          stepIndex: index2 + 1,
          nextRunAt: new Date(Date.now() + seconds * 1e3)
        });
        return;
      }
      continue;
    }
    await new Promise((resolve, reject) => {
      setImmediate(async () => {
        try {
          await executeStep(db, step, event, event.tenantId, leadId, automation.id);
          resolve();
        } catch (error) {
          reject(error);
        }
      });
    });
  }
  await updateAutomation(db, event.tenantId, automation.id, {
    runCount: sql10`${automations.runCount} + 1`,
    lastRunAt: /* @__PURE__ */ new Date()
  });
}
async function runAutomationsForEvent(event, db) {
  let resolvedDb;
  if (db) {
    resolvedDb = db;
  } else {
    const { getDb: getDb2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const liveDb = await getDb2();
    if (!liveDb) return;
    resolvedDb = liveDb;
  }
  const entitled = await tenantHasAutomationAccess(resolvedDb, event.tenantId);
  if (!entitled) {
    return;
  }
  const eventTriggers = eventToTriggerTypes(event.type);
  let automationsToRun = [];
  for (const trigger of eventTriggers) {
    const list = await getAutomationsByTrigger(resolvedDb, event.tenantId, trigger);
    automationsToRun = automationsToRun.concat(list);
  }
  const seen = /* @__PURE__ */ new Set();
  automationsToRun = automationsToRun.filter((automation) => {
    if (seen.has(automation.id)) return false;
    seen.add(automation.id);
    return true;
  });
  const automationPromises = automationsToRun.map(async (automation) => {
    if (!automation.enabled || !shouldAutomateForEvent(automation, event)) return;
    const leadId = typeof event.data?.leadId === "number" ? event.data.leadId : void 0;
    try {
      await continueAutomation(resolvedDb, automation, event, 0, leadId);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      await updateAutomation(resolvedDb, event.tenantId, automation.id, {
        errorCount: sql10`${automations.errorCount} + 1`,
        lastRunAt: /* @__PURE__ */ new Date()
      });
      await createSystemError(resolvedDb, {
        type: "automation",
        message: `Automation "${automation.name || automation.id}" failed: ${errorMsg}`,
        detail: JSON.stringify({ automationId: automation.id, leadId, eventType: event.type, error: errorMsg }),
        tenantId: event.tenantId
      }).catch(() => void 0);
      console.error(`Automation ${automation.id} failed:`, error);
    }
  });
  await Promise.allSettled(automationPromises);
}

// server/services/eventBus.ts
var processedEvents = /* @__PURE__ */ new Set();
async function emitEvent(event) {
  if (event.id && processedEvents.has(event.id)) {
    console.log("[EventBus] Duplicate event ignored:", event.id);
    return;
  }
  if (event.id) {
    processedEvents.add(event.id);
    setTimeout(() => processedEvents.delete(event.id), 5 * 60 * 1e3);
  }
  console.log("[EventBus] Event emitted:", event.type, "tenant", event.tenantId);
  await runAutomationsForEvent(event);
}

// server/_core/inboundWebhook.ts
init_logger();

// server/_core/sentry.ts
var _initialized = false;
async function initSentry() {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;
  try {
    const Sentry = await import("@sentry/node");
    Sentry.init({
      dsn,
      environment: process.env.NODE_ENV ?? "development",
      tracesSampleRate: 0.1
    });
    _initialized = true;
    console.log("[Sentry] Initialized");
  } catch {
    console.warn("[Sentry] @sentry/node not installed \u2014 skipping error tracking. Run: pnpm add @sentry/node");
  }
}
async function captureException(err, context) {
  if (!_initialized) return;
  try {
    const Sentry = await import("@sentry/node");
    Sentry.withScope((scope) => {
      if (context) scope.setExtras(context);
      Sentry.captureException(err);
    });
  } catch {
  }
}

// server/_core/inboundWebhook.ts
init_sms();
init_requestContext();
var STOP_KEYWORDS = /* @__PURE__ */ new Set(["stop", "unsubscribe", "quit", "cancel", "end", "stopall"]);
var START_KEYWORDS = /* @__PURE__ */ new Set(["start", "yes", "unstop"]);
function isStrictWebhookMode() {
  return process.env.NODE_ENV !== "development";
}
function getRawBody(req) {
  return String(req.rawBody || "");
}
function verifyTelnyxSignature(req) {
  const publicKey = process.env.TELNYX_PUBLIC_KEY;
  if (!publicKey) return !isStrictWebhookMode();
  const signature = req.headers["telnyx-signature-ed25519"];
  const timestamp2 = req.headers["telnyx-timestamp"];
  if (!signature || !timestamp2) return false;
  const ts = parseInt(timestamp2, 10);
  if (Math.abs(Date.now() / 1e3 - ts) > 300) return false;
  const payload = `${timestamp2}|${getRawBody(req) || JSON.stringify(req.body)}`;
  const expected = createHmac("sha256", publicKey).update(payload).digest("hex");
  try {
    return timingSafeEqual(Buffer.from(signature, "hex"), Buffer.from(expected, "hex"));
  } catch {
    return false;
  }
}
function verifyTwilioSignature(req) {
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  if (!authToken) return !isStrictWebhookMode();
  const twilioSignature = req.headers["x-twilio-signature"];
  if (!twilioSignature) return false;
  const params = Object.fromEntries(new URLSearchParams(getRawBody(req) || ""));
  const sortedKeys = Object.keys(params).sort();
  const url = `${req.protocol}://${req.get("host")}${req.originalUrl}`;
  const str = url + sortedKeys.map((key) => key + params[key]).join("");
  const expected = createHmac("sha1", authToken).update(str).digest("base64");
  try {
    return timingSafeEqual(Buffer.from(twilioSignature), Buffer.from(expected));
  } catch {
    return false;
  }
}
function parseTelnyx(body) {
  const payload = body?.data?.payload;
  if (!payload) return null;
  return {
    from: payload.from?.phone_number ?? "",
    to: payload.to?.[0]?.phone_number ?? "",
    body: payload.text ?? ""
  };
}
function parseTwilio(body) {
  if (!body?.From || !body?.Body) return null;
  return { from: body.From, to: body.To ?? "", body: body.Body };
}
async function logRejectedWebhook(route, provider, reason, req) {
  const db = await getDb();
  if (!db) return;
  await createSystemError(db, {
    type: "webhook",
    message: `${provider} webhook rejected`,
    detail: JSON.stringify({
      route,
      reason,
      correlationId: req.correlationId,
      ip: req.ip,
      userAgent: req.get("user-agent")
    })
  }).catch(() => void 0);
}
async function handleInbound(msg) {
  const body = msg.body.trim();
  if (!msg.from || !body) return;
  const from = normalizePhoneNumber(msg.from);
  const to = msg.to ? normalizePhoneNumber(msg.to) : "";
  const db = await getDb();
  if (!db) return;
  const bodyNorm = body.toLowerCase().replace(/[^a-z]/g, "");
  const autoCreateLeads = process.env.INBOUND_AUTO_CREATE_LEADS !== "false";
  const minBodyForNewLead = parseInt(process.env.MIN_INBOUND_LEAD_BODY_LEN || "1", 10);
  let tenantId;
  if (to) {
    const [numRow] = await db.select({ tenantId: phoneNumbers.tenantId }).from(phoneNumbers).where(and12(eq13(phoneNumbers.number, to), isNull5(phoneNumbers.deletedAt))).limit(1);
    tenantId = numRow?.tenantId;
  }
  if (!tenantId) {
    logger.warn("Inbound SMS for unknown number", { to });
    return;
  }
  const encryptedFrom = encrypt(from);
  const phoneHash = hashPhoneNumber(from);
  const [existingLead] = await db.select().from(leads).where(and12(eq13(leads.tenantId, tenantId), eq13(leads.phoneHash, phoneHash))).limit(1);
  let lead = existingLead;
  if (!lead) {
    if (STOP_KEYWORDS.has(bodyNorm)) {
      logger.info("STOP from unknown sender \u2014 no lead row", { tenantId, correlationId: getCorrelationId() });
      return;
    }
    if (!autoCreateLeads) {
      logger.info("Inbound SMS ignored (no existing lead, INBOUND_AUTO_CREATE_LEADS=false)", { tenantId });
      return;
    }
    if (body.length < minBodyForNewLead) {
      logger.info("Inbound SMS ignored (short message, no existing lead)", { tenantId, len: body.length });
      return;
    }
    await db.insert(leads).values({
      tenantId,
      phone: encryptedFrom,
      phoneHash,
      status: "new",
      lastInboundAt: /* @__PURE__ */ new Date(),
      lastMessageAt: /* @__PURE__ */ new Date()
    });
    const [createdLead] = await db.select().from(leads).where(and12(eq13(leads.tenantId, tenantId), eq13(leads.phoneHash, phoneHash))).limit(1);
    lead = createdLead;
    if (!lead) return;
  }
  if (STOP_KEYWORDS.has(bodyNorm)) {
    await db.update(leads).set({ status: "unsubscribed", updatedAt: /* @__PURE__ */ new Date(), lastInboundAt: /* @__PURE__ */ new Date() }).where(eq13(leads.id, lead.id));
  } else if (START_KEYWORDS.has(bodyNorm) && lead.status === "unsubscribed") {
    await db.update(leads).set({ status: "new", updatedAt: /* @__PURE__ */ new Date(), lastInboundAt: /* @__PURE__ */ new Date() }).where(eq13(leads.id, lead.id));
  }
  await db.insert(messages).values({
    tenantId,
    leadId: lead.id,
    direction: "inbound",
    body,
    fromNumber: encryptedFrom,
    toNumber: to,
    status: "received"
  });
  await db.update(leads).set({ lastInboundAt: /* @__PURE__ */ new Date(), lastMessageAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq13(leads.id, lead.id));
  if (STOP_KEYWORDS.has(bodyNorm)) {
    const stopText = process.env.TCPA_STOP_REPLY_TEXT || "You have been unsubscribed from SMS from this business. Reply START to receive messages again.";
    await sendSMS(from, stopText, void 0, tenantId).catch(
      (err) => logger.warn("TCPA STOP confirmation SMS failed", { error: String(err) })
    );
    await createSystemError(db, {
      type: "webhook",
      message: "TCPA STOP \u2014 lead unsubscribed",
      detail: JSON.stringify({
        tenantId,
        leadId: lead.id,
        from,
        correlationId: getCorrelationId()
      }),
      tenantId
    }).catch(() => void 0);
  } else {
    await emitEvent({
      type: "message.received",
      data: { leadId: lead.id, body, from, to },
      tenantId,
      userId: void 0,
      timestamp: /* @__PURE__ */ new Date()
    });
  }
  logger.info("Inbound SMS processed", { tenantId, leadId: lead.id, preview: body.slice(0, 40), correlationId: getCorrelationId() });
}
function registerInboundWebhooks(app) {
  app.post("/api/sms/inbound", async (req, res) => {
    if (!verifyTelnyxSignature(req)) {
      logger.warn("Telnyx signature verification failed");
      await logRejectedWebhook("/api/sms/inbound", "telnyx", "invalid_signature", req);
      res.status(403).json({ error: "Invalid signature" });
      return;
    }
    res.status(200).json({ received: true });
    try {
      const msg = parseTelnyx(req.body);
      if (msg) await handleInbound(msg);
    } catch (error) {
      logger.error("Telnyx inbound handler error", { error: String(error) });
      captureException(error, { route: "/api/sms/inbound" });
    }
  });
  app.post("/api/twilio/inbound", async (req, res) => {
    if (!verifyTwilioSignature(req)) {
      logger.warn("Twilio signature verification failed");
      await logRejectedWebhook("/api/twilio/inbound", "twilio", "invalid_signature", req);
      res.status(403).send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
      return;
    }
    res.set("Content-Type", "text/xml");
    res.send('<?xml version="1.0" encoding="UTF-8"?><Response></Response>');
    try {
      const msg = parseTwilio(req.body);
      if (msg) await handleInbound(msg);
    } catch (error) {
      logger.error("Twilio inbound handler error", { error: String(error) });
      captureException(error, { route: "/api/twilio/inbound" });
    }
  });
}

// server/_core/stripe.ts
init_db();
init_schema();
import { eq as eq18, and as and16 } from "drizzle-orm";
import express from "express";
import Stripe4 from "stripe";

// server/services/billing.service.ts
init_schema();
import { and as and13, desc as desc10, eq as eq14 } from "drizzle-orm";
import Stripe from "stripe";
var stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2022-11-15" });
async function listInvoicesByTenant(db, tenantId) {
  return db.select().from(billingInvoices).where(eq14(billingInvoices.tenantId, tenantId)).orderBy(desc10(billingInvoices.createdAt));
}
async function listRefundsByTenant(db, tenantId) {
  return db.select().from(billingRefunds).where(eq14(billingRefunds.tenantId, tenantId)).orderBy(desc10(billingRefunds.createdAt));
}
async function upsertInvoiceFromStripeEvent(db, input) {
  const payload = {
    tenantId: input.tenantId,
    subscriptionId: input.subscriptionId,
    stripeInvoiceId: input.invoice.id,
    stripeChargeId: typeof input.invoice.charge === "string" ? input.invoice.charge : void 0,
    number: input.invoice.number ?? void 0,
    status: input.invoice.status ?? "draft",
    currency: input.invoice.currency,
    subtotal: input.invoice.subtotal ?? 0,
    total: input.invoice.total ?? 0,
    amountPaid: input.invoice.amount_paid ?? 0,
    amountRemaining: input.invoice.amount_remaining ?? 0,
    hostedInvoiceUrl: input.invoice.hosted_invoice_url ?? void 0,
    invoicePdfUrl: input.invoice.invoice_pdf ?? void 0,
    periodStart: input.invoice.period_start ? new Date(input.invoice.period_start * 1e3) : void 0,
    periodEnd: input.invoice.period_end ? new Date(input.invoice.period_end * 1e3) : void 0,
    updatedAt: /* @__PURE__ */ new Date()
  };
  const [existing] = await db.select().from(billingInvoices).where(eq14(billingInvoices.stripeInvoiceId, input.invoice.id)).limit(1);
  if (existing) {
    await db.update(billingInvoices).set(payload).where(eq14(billingInvoices.id, existing.id));
    return existing.id;
  }
  const result = await db.insert(billingInvoices).values(payload);
  return Number(result.insertId ?? 0);
}
async function createRefundRecord(db, input) {
  const [existing] = await db.select().from(billingRefunds).where(eq14(billingRefunds.stripeRefundId, input.refund.id)).limit(1);
  const payload = {
    tenantId: input.tenantId,
    subscriptionId: input.subscriptionId,
    billingInvoiceId: input.billingInvoiceId,
    stripeRefundId: input.refund.id,
    stripeChargeId: typeof input.refund.charge === "string" ? input.refund.charge : void 0,
    amount: input.refund.amount,
    currency: input.refund.currency,
    reason: input.refund.reason ?? void 0,
    status: input.refund.status ?? "pending"
  };
  if (existing) {
    await db.update(billingRefunds).set(payload).where(eq14(billingRefunds.id, existing.id));
    return existing.id;
  }
  const result = await db.insert(billingRefunds).values(payload);
  return Number(result.insertId ?? 0);
}
async function getSubscriptionRowByTenant(db, tenantId) {
  const [row] = await db.select().from(subscriptions).where(eq14(subscriptions.tenantId, tenantId)).orderBy(desc10(subscriptions.createdAt)).limit(1);
  return row;
}
async function changeSubscriptionPlan(db, input) {
  const subscription = await getSubscriptionRowByTenant(db, input.tenantId);
  if (!subscription?.stripeId) {
    throw new Error("No active Stripe subscription found");
  }
  const stripeSubscription = await stripe.subscriptions.retrieve(subscription.stripeId);
  const itemId = stripeSubscription.items.data[0]?.id;
  if (!itemId) throw new Error("Stripe subscription item missing");
  return stripe.subscriptions.update(subscription.stripeId, {
    items: [{ id: itemId, price: input.priceId }],
    cancel_at_period_end: false,
    proration_behavior: input.prorateImmediately ? "always_invoice" : "create_prorations"
  });
}
async function issueRefundForInvoiceCharge(db, input) {
  const [invoice] = await db.select().from(billingInvoices).where(and13(eq14(billingInvoices.tenantId, input.tenantId), eq14(billingInvoices.stripeInvoiceId, input.stripeInvoiceId))).limit(1);
  if (!invoice?.stripeChargeId) {
    throw new Error("Invoice charge not found");
  }
  const refund = await stripe.refunds.create({
    charge: invoice.stripeChargeId,
    amount: input.amount,
    reason: input.reason
  });
  await createRefundRecord(db, {
    tenantId: input.tenantId,
    subscriptionId: invoice.subscriptionId ?? void 0,
    billingInvoiceId: invoice.id,
    refund
  });
  return refund;
}

// server/services/roi-guarantee.service.ts
init_schema();
init_logger();
import { eq as eq15, and as and14, sql as sql11, gte as gte3, lte as lte3, isNotNull as isNotNull2 } from "drizzle-orm";
async function getGuaranteeCohortCount(db, cohort) {
  const [result] = await db.select({ count: sql11`COUNT(*)` }).from(subscriptions).where(eq15(subscriptions.guaranteeCohort, cohort));
  return Number(result?.count ?? 0);
}
async function isCohortAvailable(db, cohort) {
  const maxSlots = cohort === "risk_free_20" ? 20 : 10;
  const claimed = await getGuaranteeCohortCount(db, cohort);
  return { available: claimed < maxSlots, claimed, total: maxSlots };
}
async function enrollInGuarantee(db, subscriptionId, cohort) {
  const availability = await isCohortAvailable(db, cohort);
  if (!availability.available) {
    return {
      enrolled: false,
      reason: `${cohort} cohort is full (${availability.claimed}/${availability.total})`
    };
  }
  const now = /* @__PURE__ */ new Date();
  const expiresAt = new Date(now);
  expiresAt.setDate(expiresAt.getDate() + 90);
  await db.update(subscriptions).set({
    guaranteeCohort: cohort,
    guaranteeStatus: "active",
    guaranteeStartedAt: now,
    guaranteeExpiresAt: expiresAt
  }).where(eq15(subscriptions.id, subscriptionId));
  logger.info("Enrolled subscription in guarantee", {
    subscriptionId,
    cohort,
    expiresAt,
    slotsRemaining: availability.total - availability.claimed - 1
  });
  return { enrolled: true };
}
async function calculateTenantROI(db, tenantId, periodStart, periodEnd) {
  const end = periodEnd || /* @__PURE__ */ new Date();
  const start = periodStart || (() => {
    const d = new Date(end);
    d.setDate(d.getDate() - 30);
    return d;
  })();
  const [sub] = await db.select({
    planPriceMonthly: plans.priceMonthly,
    revenueSharePercent: plans.revenueSharePercent
  }).from(subscriptions).innerJoin(plans, eq15(subscriptions.planId, plans.id)).where(eq15(subscriptions.tenantId, tenantId)).limit(1);
  const subscriptionFee = sub?.planPriceMonthly ?? 0;
  const revenueSharePercent = sub?.revenueSharePercent ?? 0;
  const [revenue] = await db.select({
    totalRealized: sql11`COALESCE(SUM(${recoveryEvents.realizedRevenue}), 0)`
  }).from(recoveryEvents).where(
    and14(
      eq15(recoveryEvents.tenantId, tenantId),
      eq15(recoveryEvents.isPrimaryAttribution, true),
      sql11`${recoveryEvents.status} IN ('realized', 'manual_realized')`,
      gte3(recoveryEvents.realizedAt, start),
      lte3(recoveryEvents.realizedAt, end)
    )
  );
  const recoveredRevenue = Number(revenue?.totalRealized ?? 0);
  const revenueShareAmount = Math.round(recoveredRevenue * revenueSharePercent / 100);
  const clientNetROI = recoveredRevenue - subscriptionFee - revenueShareAmount;
  return {
    tenantId,
    periodStart: start,
    periodEnd: end,
    recoveredRevenue,
    subscriptionFee,
    revenueSharePercent,
    revenueShareAmount,
    clientNetROI,
    isPositiveROI: clientNetROI > 0
  };
}
async function evaluateGuarantee(db, tenantId) {
  const [sub] = await db.select().from(subscriptions).where(
    and14(
      eq15(subscriptions.tenantId, tenantId),
      isNotNull2(subscriptions.guaranteeCohort)
    )
  ).limit(1);
  if (!sub || !sub.guaranteeCohort) {
    return { action: "not_enrolled" };
  }
  if (sub.guaranteeStatus !== "active") {
    return { action: "none" };
  }
  const now = /* @__PURE__ */ new Date();
  const roi = await calculateTenantROI(
    db,
    tenantId,
    sub.guaranteeStartedAt || sub.createdAt,
    now
  );
  await db.update(subscriptions).set({
    lastRoiCheckAt: now,
    lastRoiAmount: roi.clientNetROI
  }).where(eq15(subscriptions.id, sub.id));
  if (roi.isPositiveROI) {
    await db.update(subscriptions).set({ guaranteeStatus: "satisfied" }).where(eq15(subscriptions.id, sub.id));
    logger.info("Guarantee satisfied \u2014 positive ROI achieved", {
      tenantId,
      clientNetROI: roi.clientNetROI,
      recoveredRevenue: roi.recoveredRevenue
    });
    return { action: "satisfied", roi };
  }
  if (sub.guaranteeExpiresAt && now >= sub.guaranteeExpiresAt) {
    if (!roi.isPositiveROI) {
      await db.update(subscriptions).set({ guaranteeStatus: "refunded" }).where(eq15(subscriptions.id, sub.id));
      logger.warn("Guarantee triggered \u2014 negative ROI at expiration, refund eligible", {
        tenantId,
        clientNetROI: roi.clientNetROI,
        recoveredRevenue: roi.recoveredRevenue,
        subscriptionFee: roi.subscriptionFee
      });
      return { action: "refund_eligible", roi };
    }
    await db.update(subscriptions).set({ guaranteeStatus: "satisfied" }).where(eq15(subscriptions.id, sub.id));
    return { action: "satisfied", roi };
  }
  return { action: "none", roi };
}
async function evaluateAllGuarantees(db) {
  const activeGuarantees = await db.select({
    tenantId: subscriptions.tenantId,
    subscriptionId: subscriptions.id
  }).from(subscriptions).where(
    and14(
      isNotNull2(subscriptions.guaranteeCohort),
      eq15(subscriptions.guaranteeStatus, "active")
    )
  );
  const results = {
    evaluated: activeGuarantees.length,
    satisfied: 0,
    refundEligible: 0,
    stillActive: 0,
    details: []
  };
  for (const sub of activeGuarantees) {
    const result = await evaluateGuarantee(db, sub.tenantId);
    results.details.push({ tenantId: sub.tenantId, action: result.action, roi: result.roi });
    switch (result.action) {
      case "satisfied":
        results.satisfied++;
        break;
      case "refund_eligible":
        results.refundEligible++;
        break;
      default:
        results.stillActive++;
    }
  }
  logger.info("Guarantee evaluation complete", {
    evaluated: results.evaluated,
    satisfied: results.satisfied,
    refundEligible: results.refundEligible,
    stillActive: results.stillActive
  });
  return results;
}
async function getGuaranteeStatus(db, tenantId) {
  const [sub] = await db.select({
    tenantId: subscriptions.tenantId,
    guaranteeCohort: subscriptions.guaranteeCohort,
    guaranteeStatus: subscriptions.guaranteeStatus,
    guaranteeStartedAt: subscriptions.guaranteeStartedAt,
    guaranteeExpiresAt: subscriptions.guaranteeExpiresAt
  }).from(subscriptions).where(eq15(subscriptions.tenantId, tenantId)).limit(1);
  if (!sub || !sub.guaranteeCohort) {
    return {
      tenantId,
      cohort: null,
      status: null,
      startedAt: null,
      expiresAt: null,
      currentROI: null,
      daysRemaining: null
    };
  }
  let currentROI = null;
  if (sub.guaranteeStatus === "active" && sub.guaranteeStartedAt) {
    currentROI = await calculateTenantROI(db, tenantId, sub.guaranteeStartedAt, /* @__PURE__ */ new Date());
  }
  const daysRemaining = sub.guaranteeExpiresAt ? Math.max(0, Math.ceil((sub.guaranteeExpiresAt.getTime() - Date.now()) / (1e3 * 60 * 60 * 24))) : null;
  return {
    tenantId,
    cohort: sub.guaranteeCohort,
    status: sub.guaranteeStatus,
    startedAt: sub.guaranteeStartedAt,
    expiresAt: sub.guaranteeExpiresAt,
    currentROI,
    daysRemaining
  };
}
async function getGuaranteeOverview(db) {
  const [riskFree] = await db.select({
    total: sql11`COUNT(*)`,
    active: sql11`SUM(CASE WHEN guaranteeStatus = 'active' THEN 1 ELSE 0 END)`,
    satisfied: sql11`SUM(CASE WHEN guaranteeStatus = 'satisfied' THEN 1 ELSE 0 END)`,
    refunded: sql11`SUM(CASE WHEN guaranteeStatus = 'refunded' THEN 1 ELSE 0 END)`
  }).from(subscriptions).where(eq15(subscriptions.guaranteeCohort, "risk_free_20"));
  const [flex] = await db.select({
    total: sql11`COUNT(*)`,
    active: sql11`SUM(CASE WHEN guaranteeStatus = 'active' THEN 1 ELSE 0 END)`,
    satisfied: sql11`SUM(CASE WHEN guaranteeStatus = 'satisfied' THEN 1 ELSE 0 END)`,
    refunded: sql11`SUM(CASE WHEN guaranteeStatus = 'refunded' THEN 1 ELSE 0 END)`
  }).from(subscriptions).where(eq15(subscriptions.guaranteeCohort, "flex_10"));
  return {
    riskFree20: {
      slotsUsed: Number(riskFree?.total ?? 0),
      slotsTotal: 20,
      slotsAvailable: 20 - Number(riskFree?.total ?? 0),
      active: Number(riskFree?.active ?? 0),
      satisfied: Number(riskFree?.satisfied ?? 0),
      refunded: Number(riskFree?.refunded ?? 0)
    },
    flex10: {
      slotsUsed: Number(flex?.total ?? 0),
      slotsTotal: 10,
      slotsAvailable: 10 - Number(flex?.total ?? 0),
      active: Number(flex?.active ?? 0),
      satisfied: Number(flex?.satisfied ?? 0),
      refunded: Number(flex?.refunded ?? 0)
    }
  };
}

// server/services/stripe-checkout.service.ts
init_db();
init_schema();
import Stripe3 from "stripe";
import { TRPCError as TRPCError3 } from "@trpc/server";
import { eq as eq17 } from "drizzle-orm";
var stripe3 = new Stripe3(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2022-11-15"
});
var PROFESSIONAL_FIXED_PRICE_ID = process.env.STRIPE_PRICE_PROFESSIONAL || "price_1TDqZtPC6Kl5W2cCTLQrYsKS";
var PROFESSIONAL_METERED_PRICE_ID = process.env.STRIPE_METERED_PRICE_ID || "price_1TDx2sPC6Kl5W2cCGPQgHuXz";
var FLEX_DEFAULT_PRICE_ID = process.env.STRIPE_PRICE_FLEX || "price_1TExaUPC6Kl5W2cC865JZHpr";
var FLEX_METERED_PRICE_ID = process.env.STRIPE_METERED_PRICE_FLEX || "price_1TFgLpPC6Kl5W2cCdN22c86O";
var FIXED_PRICE_ID = PROFESSIONAL_FIXED_PRICE_ID;
var METERED_PRICE_ID = PROFESSIONAL_METERED_PRICE_ID;
async function createCheckoutSession(data) {
  const { customerEmail, userId, tenantId, referralCode } = data;
  try {
    let customerId;
    const existingCustomers = await stripe3.customers.list({ email: customerEmail, limit: 1 });
    if (existingCustomers.data.length > 0) {
      customerId = existingCustomers.data[0].id;
    } else {
      const customer = await stripe3.customers.create({
        email: customerEmail,
        metadata: {
          userId,
          tenantId,
          referralCode: referralCode || ""
        }
      });
      customerId = customer.id;
    }
    const isFlex = data.planType === "flex";
    const basePriceId = isFlex ? data.flexPriceId || FLEX_DEFAULT_PRICE_ID : PROFESSIONAL_FIXED_PRICE_ID;
    const meteredPriceId = isFlex ? FLEX_METERED_PRICE_ID : PROFESSIONAL_METERED_PRICE_ID;
    const session = await stripe3.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      customer_email: customerEmail,
      line_items: [
        {
          price: basePriceId,
          quantity: 1
        },
        {
          price: meteredPriceId
          // Revenue share metered price
        }
      ],
      success_url: `${process.env.FRONTEND_URL}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/pricing`,
      payment_method_types: ["card"],
      allow_promotion_codes: true,
      billing_address_collection: "auto",
      customer_update: {
        address: "auto",
        name: "auto"
      },
      metadata: {
        userId,
        tenantId,
        referralCode: referralCode || "",
        recoveryEventId: data.recoveryEventId || "",
        planType: data.planType || "professional"
      }
    });
    return session.url;
  } catch (error) {
    console.error("Stripe Checkout Session creation failed:", error);
    throw new TRPCError3({
      code: "INTERNAL_SERVER_ERROR",
      message: "Failed to create checkout session"
    });
  }
}
async function processSuccessfulCheckout(sessionId) {
  try {
    const session = await stripe3.checkout.sessions.retrieve(sessionId);
    if (!session.customer || !session.subscription) {
      throw new Error("Invalid session data");
    }
    const subscription = await stripe3.subscriptions.retrieve(session.subscription);
    const db = await getDb();
    await db.insert(stripeSubscriptions).values({
      id: subscription.id,
      userId: parseInt(session.metadata?.userId || "0", 10),
      tenantId: parseInt(session.metadata?.tenantId || "0", 10),
      customerId: session.customer,
      status: subscription.status,
      priceId: FIXED_PRICE_ID,
      quantity: 1,
      currentPeriodStart: new Date(subscription.current_period_start * 1e3),
      currentPeriodEnd: new Date(subscription.current_period_end * 1e3),
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
      metadata: {
        referralCode: session.metadata?.referralCode || "",
        meteredPriceId: METERED_PRICE_ID
      },
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    });
    if (session.metadata?.referralCode) {
      await processReferralCompletion(session.metadata.referralCode, session.metadata.userId, subscription.id);
    }
    return {
      customerId: session.customer,
      subscriptionId: subscription.id,
      status: subscription.status,
      currentPeriodStart: new Date(subscription.current_period_start * 1e3),
      currentPeriodEnd: new Date(subscription.current_period_end * 1e3)
    };
  } catch (error) {
    console.error("Checkout processing failed:", error);
    throw new TRPCError3({
      code: "INTERNAL_SERVER_ERROR",
      message: "Failed to process checkout"
    });
  }
}
async function reportRevenueUsage(customerId, recoveredAmount, recoveryEventId) {
  try {
    const subscriptions2 = await stripe3.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 1
    });
    if (subscriptions2.data.length === 0) {
      console.warn("No active subscription found for customer:", customerId);
      return;
    }
    const subscription = subscriptions2.data[0];
    const meteredItem = subscription.items.data.find(
      (item) => item.price.id === METERED_PRICE_ID || item.price.recurring?.usage_type === "metered"
    );
    if (!meteredItem) {
      console.warn("No metered subscription item found for subscription:", subscription.id);
      return;
    }
    await stripe3.subscriptionItems.createUsageRecord(meteredItem.id, {
      quantity: recoveredAmount,
      // Report in dollars (or scale to cents if needed)
      action: "increment"
    });
    console.log(`Reported $${recoveredAmount} revenue recovery for customer ${customerId}${recoveryEventId ? ` (recovery_event: ${recoveryEventId})` : ""}`);
  } catch (error) {
    console.error("Failed to report revenue usage:", error);
    throw new TRPCError3({
      code: "INTERNAL_SERVER_ERROR",
      message: "Failed to report revenue usage"
    });
  }
}
async function getCurrentUsage(customerId) {
  try {
    const subscriptions2 = await stripe3.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 1
    });
    if (subscriptions2.data.length === 0) {
      return 0;
    }
    const subscription = subscriptions2.data[0];
    const meteredItem = subscription.items.data.find(
      (item) => item.price.id === METERED_PRICE_ID || item.price.recurring?.usage_type === "metered"
    );
    if (!meteredItem) {
      return 0;
    }
    const usageRecords = await stripe3.subscriptionItems.listUsageRecordSummaries(meteredItem.id);
    const totalUsage = usageRecords.data.reduce((sum, record) => {
      return sum + record.total_usage;
    }, 0);
    return totalUsage;
  } catch (error) {
    console.error("Failed to get current usage:", error);
    return 0;
  }
}
async function createCustomerPortalSession(customerId) {
  try {
    const session = await stripe3.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${process.env.FRONTEND_URL}/billing`
    });
    return session.url;
  } catch (error) {
    console.error("Failed to create customer portal session:", error);
    throw new TRPCError3({
      code: "INTERNAL_SERVER_ERROR",
      message: "Failed to create customer portal session"
    });
  }
}
async function cancelSubscription(subscriptionId) {
  try {
    await stripe3.subscriptions.update(subscriptionId, {
      cancel_at_period_end: true
    });
    const db = await getDb();
    await db.update(stripeSubscriptions).set({
      cancelAtPeriodEnd: true,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq17(stripeSubscriptions.id, subscriptionId));
  } catch (error) {
    console.error("Failed to cancel subscription:", error);
    throw new TRPCError3({
      code: "INTERNAL_SERVER_ERROR",
      message: "Failed to cancel subscription"
    });
  }
}
async function resumeSubscription(subscriptionId) {
  try {
    await stripe3.subscriptions.update(subscriptionId, {
      cancel_at_period_end: false
    });
    const db = await getDb();
    await db.update(stripeSubscriptions).set({
      cancelAtPeriodEnd: false,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq17(stripeSubscriptions.id, subscriptionId));
  } catch (error) {
    console.error("Failed to resume subscription:", error);
    throw new TRPCError3({
      code: "INTERNAL_SERVER_ERROR",
      message: "Failed to resume subscription"
    });
  }
}
async function processReferralCompletion(referralCode, userId, subscriptionId) {
  try {
    const { processReferral: processReferral2, completeReferral: completeReferral2 } = await Promise.resolve().then(() => (init_referral_service(), referral_service_exports));
    const result = await processReferral2(referralCode, Number(userId));
    if (result.success && result.referralId) {
      await completeReferral2(result.referralId, subscriptionId, 6);
    }
  } catch (error) {
    console.error("Failed to process referral completion:", error);
  }
}
async function getSubscriptionDetails(subscriptionId) {
  try {
    const subscription = await stripe3.subscriptions.retrieve(subscriptionId, {
      expand: ["customer", "latest_invoice"]
    });
    return subscription;
  } catch (error) {
    console.error("Failed to get subscription details:", error);
    throw new TRPCError3({
      code: "NOT_FOUND",
      message: "Subscription not found"
    });
  }
}

// server/_core/stripe.ts
init_env();
init_logger();
var stripe4 = new Stripe4(ENV.stripeSecretKey || "", { apiVersion: "2022-11-15" });
async function getSubscriptionByStripeId(db, stripeId) {
  const rows = await db.select().from(subscriptions).where(eq18(subscriptions.stripeId, stripeId)).limit(1);
  return rows[0];
}
async function resolvePlanId(db, priceId, fallback = 1) {
  if (!priceId) return fallback;
  const planRows = await db.select().from(plans).where(eq18(plans.stripePriceId, priceId)).limit(1);
  return planRows[0]?.id ?? fallback;
}
function registerStripeWebhook(app) {
  app.post(
    "/api/stripe/webhook",
    express.raw({ type: "application/json" }),
    async (req, res) => {
      const sig = req.headers["stripe-signature"];
      const webhookSecret = ENV.stripeWebhookSecret;
      if (!sig || !webhookSecret) {
        return res.status(400).send("Missing signature/webhook secret");
      }
      let event;
      try {
        event = stripe4.webhooks.constructEvent(req.body, sig, webhookSecret);
      } catch (err) {
        return res.status(400).send(`Webhook Error: ${err?.message || "invalid payload"}`);
      }
      try {
        const db = await getDb();
        if (!db) return res.status(500).send("Database unavailable");
        switch (event.type) {
          case "checkout.session.completed": {
            const session = event.data.object;
            const stripeSubId = session.subscription;
            const tenantId = session.metadata ? Number(session.metadata.tenantId) : void 0;
            if (!stripeSubId || !tenantId) break;
            const sub = await stripe4.subscriptions.retrieve(stripeSubId, { expand: ["items.data.price"] }).catch(() => null);
            const priceId = sub?.items.data[0]?.price?.id;
            const planId = await resolvePlanId(db, priceId, 1);
            const existing = await db.select().from(subscriptions).where(eq18(subscriptions.tenantId, tenantId)).limit(1);
            const payload = {
              stripeId: stripeSubId,
              status: sub?.status || "active",
              planId,
              currentPeriodStart: sub?.current_period_start ? new Date(sub.current_period_start * 1e3) : void 0,
              currentPeriodEnd: sub?.current_period_end ? new Date(sub.current_period_end * 1e3) : void 0,
              trialEndsAt: sub?.trial_end ? new Date(sub.trial_end * 1e3) : void 0
            };
            if (existing[0]) {
              await db.update(subscriptions).set(payload).where(eq18(subscriptions.id, existing[0].id));
            } else {
              await db.insert(subscriptions).values({ tenantId, ...payload });
            }
            break;
          }
          case "invoice.paid":
          case "invoice.payment_failed":
          case "invoice.finalized": {
            const invoice = event.data.object;
            const stripeSubId = invoice.subscription;
            if (!stripeSubId) break;
            const subscription = await getSubscriptionByStripeId(db, stripeSubId);
            if (!subscription) break;
            await upsertInvoiceFromStripeEvent(db, {
              tenantId: subscription.tenantId,
              subscriptionId: subscription.id,
              invoice
            });
            await db.update(subscriptions).set({
              status: event.type === "invoice.payment_failed" ? "past_due" : "active",
              currentPeriodStart: invoice.period_start ? new Date(invoice.period_start * 1e3) : void 0,
              currentPeriodEnd: invoice.period_end ? new Date(invoice.period_end * 1e3) : void 0
            }).where(eq18(subscriptions.id, subscription.id));
            if (event.type === "invoice.paid" && invoice.payment_intent) {
              const paymentIntentId = typeof invoice.payment_intent === "string" ? invoice.payment_intent : invoice.payment_intent.id;
              const amountPaid = invoice.amount_paid || 0;
              const convertedEvents = await db.select().from(recoveryEvents).where(and16(
                eq18(recoveryEvents.tenantId, subscription.tenantId),
                eq18(recoveryEvents.status, "converted"),
                eq18(recoveryEvents.isPrimaryAttribution, true)
              ));
              for (const re of convertedEvents) {
                try {
                  await markRecoveryRealized(db, subscription.tenantId, re.leadId, {
                    stripePaymentIntentId: paymentIntentId,
                    stripeInvoiceId: invoice.id,
                    realizedRevenue: re.estimatedRevenue
                    // use estimated until we can link exact amounts
                  });
                } catch (err) {
                  logger.warn("Failed to realize recovery event", { recoveryEventId: re.id, error: String(err) });
                }
              }
              if (convertedEvents.length > 0) {
                const totalRealized = convertedEvents.reduce((sum, e) => sum + e.estimatedRevenue, 0);
                const customerId = typeof invoice.customer === "string" ? invoice.customer : invoice.customer?.id;
                if (customerId && totalRealized > 0) {
                  try {
                    await reportRevenueUsage(customerId, Math.round(totalRealized / 100));
                    logger.info("Reported metered revenue usage to Stripe", { tenantId: subscription.tenantId, amount: totalRealized });
                  } catch (err) {
                    logger.warn("Failed to report metered usage", { error: String(err) });
                  }
                }
              }
            }
            try {
              const result = await evaluateGuarantee(db, subscription.tenantId);
              if (result.action === "refund_eligible") {
                logger.warn("ROI guarantee refund eligible \u2014 admin action needed", {
                  tenantId: subscription.tenantId,
                  clientNetROI: result.roi?.clientNetROI
                });
              }
            } catch (err) {
              logger.warn("Failed to evaluate ROI guarantee", { tenantId: subscription.tenantId, error: String(err) });
            }
            break;
          }
          case "charge.refunded": {
            const charge = event.data.object;
            if (!charge.invoice || typeof charge.invoice !== "string") break;
            const [invoiceRow] = await db.select().from(billingInvoices).where(eq18(billingInvoices.stripeInvoiceId, charge.invoice)).limit(1);
            if (!invoiceRow) break;
            const refunds = await stripe4.refunds.list({ charge: charge.id, limit: 10 });
            for (const refund of refunds.data) {
              await createRefundRecord(db, {
                tenantId: invoiceRow.tenantId,
                subscriptionId: invoiceRow.subscriptionId ?? void 0,
                billingInvoiceId: invoiceRow.id,
                refund
              });
            }
            break;
          }
          case "customer.subscription.updated":
          case "customer.subscription.created":
          case "customer.subscription.deleted": {
            const sub = event.data.object;
            const subscription = await getSubscriptionByStripeId(db, sub.id);
            if (!subscription) break;
            const priceId = sub.items.data[0]?.price?.id;
            const planId = await resolvePlanId(db, priceId, subscription.planId);
            await db.update(subscriptions).set({
              status: sub.status,
              currentPeriodStart: sub.current_period_start ? new Date(sub.current_period_start * 1e3) : void 0,
              currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end * 1e3) : void 0,
              trialEndsAt: sub.trial_end ? new Date(sub.trial_end * 1e3) : void 0,
              planId
            }).where(eq18(subscriptions.id, subscription.id));
            break;
          }
        }
        res.json({ received: true });
      } catch (err) {
        console.error("[Stripe] Webhook handler error:", err);
        res.status(500).send("Internal error");
      }
    }
  );
}

// server/routers.ts
import { z as z7 } from "zod";
import { TRPCError as TRPCError7 } from "@trpc/server";

// shared/schemas/leads.ts
import { z } from "zod";
var phoneSchema = z.string().trim().superRefine((val, ctx) => {
  if (!normalizePhoneE164(val)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Phone must be a valid number in E.164 format (e.g. +15550001234)"
    });
  }
}).transform((val) => normalizePhoneE164(val));
var smsBodySchema = z.string().min(1, "Message cannot be empty").max(1600, "Message exceeds maximum SMS length (1600 chars)");
var createLeadSchema = z.object({
  name: z.string().min(1, "Name is required").max(255),
  phone: phoneSchema,
  email: z.string().email("Invalid email").max(320).optional().or(z.literal("")),
  source: z.string().max(100).optional(),
  notes: z.string().max(5e3).optional()
});
var updateLeadSchema = z.object({
  leadId: z.number().int().positive(),
  name: z.string().min(1).max(255).optional(),
  email: z.string().email().max(320).optional().or(z.literal("")),
  phone: phoneSchema.optional(),
  notes: z.string().max(5e3).optional(),
  appointmentAt: z.date().nullable().optional()
});
var updateLeadStatusSchema = z.object({
  leadId: z.number().int().positive(),
  status: z.enum(["new", "contacted", "qualified", "booked", "lost", "unsubscribed"])
});
var sendMessageSchema = z.object({
  leadId: z.number().int().positive(),
  body: smsBodySchema,
  tone: z.enum(["friendly", "professional", "casual", "urgent", "empathetic"]).optional(),
  // Idempotency key — client generates a UUID per send attempt to prevent duplicates
  idempotencyKey: z.string().uuid("idempotencyKey must be a UUID").optional()
});
var loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(12, "Password must be at least 12 characters")
});
var paginationSchema = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.string().optional(),
  sortOrder: z.enum(["asc", "desc"]).default("desc")
});

// server/routers.ts
init_schema();
import Stripe6 from "stripe";
import { eq as eq27, and as and25, gte as gte7, sql as sql16 } from "drizzle-orm";
init_llm();

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError4 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var createRouter = t.router;
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError4({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});
var protectedProcedure = t.procedure.use(requireUser);
var requireTenant = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError4({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  const tenantId = await getTenantId(ctx.db, ctx.user.id);
  return next({ ctx: { ...ctx, user: ctx.user, tenantId } });
});
var tenantProcedure = t.procedure.use(requireTenant);
var requireAdmin = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user || ctx.user.role !== "admin") {
    throw new TRPCError4({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});
var adminProcedure = t.procedure.use(requireAdmin);

// server/routers.ts
import bcrypt3 from "bcryptjs";
import { randomUUID as randomUUID2 } from "crypto";

// server/services/template.service.ts
init_schema();
import { eq as eq20, and as and18, isNull as isNull7 } from "drizzle-orm";
async function getTemplates(db, tenantId) {
  return db.select().from(templates).where(and18(eq20(templates.tenantId, tenantId), isNull7(templates.deletedAt))).orderBy(templates.name);
}
async function createTemplate(db, data) {
  const { category, ...insertData } = data;
  await db.insert(templates).values(insertData);
  return { success: true };
}
async function updateTemplate(db, tenantId, templateId, data) {
  await db.update(templates).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(and18(eq20(templates.id, templateId), eq20(templates.tenantId, tenantId), isNull7(templates.deletedAt)));
}
async function deleteTemplate(db, tenantId, templateId) {
  await db.update(templates).set({ deletedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(and18(eq20(templates.id, templateId), eq20(templates.tenantId, tenantId), isNull7(templates.deletedAt)));
}

// server/services/analytics.service.ts
init_schema();
init_query_service();
import { eq as eq21, and as and19, sql as sql13, isNotNull as isNotNull3, gt, lt as lt2, isNull as isNull8, gte as gte4 } from "drizzle-orm";
async function getDashboardMetrics(db, tenantId) {
  const [leadCount, messageCount, automationCount, bookedCount] = await withQueryTimeout("analytics.dashboardMetrics", Promise.all([
    db.select({ count: sql13`count(*)` }).from(leads).where(eq21(leads.tenantId, tenantId)),
    db.select({ count: sql13`count(*)` }).from(messages).where(eq21(messages.tenantId, tenantId)),
    db.select({ count: sql13`count(*)` }).from(automations).where(and19(eq21(automations.tenantId, tenantId), eq21(automations.enabled, true), isNull8(automations.deletedAt))),
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "booked")))
  ]));
  return {
    leadCount: Number(leadCount[0]?.count ?? 0),
    messageCount: Number(messageCount[0]?.count ?? 0),
    automationCount: Number(automationCount[0]?.count ?? 0),
    bookedCount: Number(bookedCount[0]?.count ?? 0)
  };
}
async function getRevenueRecoveryMetrics(db, tenantId) {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3);
  const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1e3);
  const [
    totalLeads,
    bookedLeads,
    avgRevenuePerBooking,
    recentBookings,
    recoveredLeads,
    lostLeads,
    qualifiedLeads,
    contactedLeads
  ] = await withQueryTimeout("analytics.revenueRecovery", Promise.all([
    // Total leads in system
    db.select({ count: sql13`count(*)` }).from(leads).where(eq21(leads.tenantId, tenantId)),
    // Booked leads (converted revenue)
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "booked"))),
    // Average revenue per booking (using a reasonable default)
    db.select({ avgRevenue: sql13`COALESCE(AVG(CASE WHEN ${leads.status} = 'booked' THEN 250 ELSE 0 END), 250)` }).from(leads).where(eq21(leads.tenantId, tenantId)),
    // Recent bookings (last 30 days)
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "booked"), gte4(leads.createdAt, thirtyDaysAgo))),
    // Recovered leads (new -> booked)
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "booked"), isNotNull3(leads.updatedAt), gte4(leads.updatedAt, thirtyDaysAgo))),
    // Lost leads (lost revenue)
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "lost"))),
    // Qualified leads (potential revenue)
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "qualified"))),
    // Contacted leads (in pipeline)
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "contacted")))
  ]));
  const totalLeadsCount = Number(totalLeads[0]?.count ?? 0);
  const bookedLeadsCount = Number(bookedLeads[0]?.count ?? 0);
  const avgRevenueAmount = Number(avgRevenuePerBooking[0]?.avgRevenue ?? 250);
  const recentBookingsCount = Number(recentBookings[0]?.count ?? 0);
  const recoveredLeadsCount = Number(recoveredLeads[0]?.count ?? 0);
  const lostLeadsCount = Number(lostLeads[0]?.count ?? 0);
  const qualifiedLeadsCount = Number(qualifiedLeads[0]?.count ?? 0);
  const contactedLeadsCount = Number(contactedLeads[0]?.count ?? 0);
  const totalRecoveredRevenue = bookedLeadsCount * avgRevenueAmount;
  const recentRecoveredRevenue = recentBookingsCount * avgRevenueAmount;
  const potentialRevenue = qualifiedLeadsCount * avgRevenueAmount;
  const lostRevenue = lostLeadsCount * avgRevenueAmount;
  const pipelineRevenue = contactedLeadsCount * avgRevenueAmount * 0.3;
  const overallRecoveryRate = totalLeadsCount > 0 ? bookedLeadsCount / totalLeadsCount * 100 : 0;
  const recentRecoveryRate = recentBookingsCount > 0 ? recoveredLeadsCount / recentBookingsCount * 100 : 0;
  return {
    totalRecoveredRevenue,
    recentRecoveredRevenue,
    potentialRevenue,
    lostRevenue,
    pipelineRevenue,
    overallRecoveryRate,
    recentRecoveryRate,
    avgRevenuePerBooking: avgRevenueAmount,
    totalLeadsCount,
    bookedLeadsCount,
    qualifiedLeadsCount,
    contactedLeadsCount,
    lostLeadsCount,
    recentBookingsCount,
    recoveredLeadsCount
  };
}
async function getRevenueTrends(db, tenantId, days = 90) {
  const boundedDays = Math.min(Math.max(days, 1), 365);
  const since = new Date(Date.now() - boundedDays * 24 * 60 * 60 * 1e3);
  const revenueData = await withQueryTimeout("analytics.revenueTrends", db.select({
    date: sql13`DATE(${leads.createdAt})`,
    bookings: sql13`SUM(CASE WHEN ${leads.status} = 'booked' THEN 1 ELSE 0 END)`,
    revenue: sql13`SUM(CASE WHEN ${leads.status} = 'booked' THEN 250 ELSE 0 END)`,
    totalLeads: sql13`COUNT(*)`
  }).from(leads).where(and19(eq21(leads.tenantId, tenantId), gte4(leads.createdAt, since))).groupBy(sql13`DATE(${leads.createdAt})`).orderBy(sql13`DATE(${leads.createdAt})`));
  return revenueData.map((row) => ({
    date: row.date,
    bookings: Number(row.bookings),
    revenue: Number(row.revenue),
    totalLeads: Number(row.totalLeads),
    recoveryRate: Number(row.totalLeads) > 0 ? Number(row.bookings) / Number(row.totalLeads) * 100 : 0
  }));
}
async function getLeadStatusBreakdown(db, tenantId) {
  const result = await withQueryTimeout("analytics.statusBreakdown", db.select({ status: leads.status, count: sql13`count(*)` }).from(leads).where(eq21(leads.tenantId, tenantId)).groupBy(leads.status));
  return result.map((r) => ({ status: r.status, count: Number(r.count) }));
}
async function getMessageVolume(db, tenantId, days = 30) {
  const boundedDays = Math.min(Math.max(days, 1), 90);
  const since = new Date(Date.now() - boundedDays * 24 * 60 * 60 * 1e3);
  return withQueryTimeout("analytics.messageVolume", db.select({
    date: sql13`DATE(createdAt)`,
    count: sql13`count(*)`,
    direction: messages.direction
  }).from(messages).where(and19(eq21(messages.tenantId, tenantId), sql13`createdAt >= ${since}`)).groupBy(sql13`DATE(createdAt)`, messages.direction).orderBy(sql13`DATE(createdAt)`));
}
async function getLeakageMetrics(db, tenantId) {
  const [unconfirmed, qualifiedUnbooked, cancellations, failedMessages] = await Promise.all([
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "booked"), isNotNull3(leads.appointmentAt), gt(leads.appointmentAt, /* @__PURE__ */ new Date()), lt2(leads.appointmentAt, new Date(Date.now() + 48 * 60 * 60 * 1e3)))),
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), eq21(leads.status, "qualified"), sql13`${leads.appointmentAt} IS NULL`)),
    db.select({ count: sql13`count(*)` }).from(leads).where(and19(eq21(leads.tenantId, tenantId), sql13`JSON_SEARCH(COALESCE(${leads.tags}, JSON_ARRAY()), 'one', 'cancelled') IS NOT NULL`, sql13`${leads.status} <> 'booked'`)),
    db.select({ count: sql13`count(distinct ${messages.leadId})` }).from(messages).where(and19(eq21(messages.tenantId, tenantId), eq21(messages.direction, "outbound"), eq21(messages.status, "failed"), gt(messages.createdAt, new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3))))
  ]);
  return {
    unconfirmedAppointments: Number(unconfirmed[0]?.count ?? 0),
    qualifiedUnbooked: Number(qualifiedUnbooked[0]?.count ?? 0),
    cancellationsUnrecovered: Number(cancellations[0]?.count ?? 0),
    failedDeliveryRecovery: Number(failedMessages[0]?.count ?? 0)
  };
}

// server/services/ai.service.ts
init_schema();
import { eq as eq22, desc as desc13, and as and20 } from "drizzle-orm";
async function getAiLogs(db, tenantId, limit = 50, page = 1) {
  const offset = (page - 1) * limit;
  return db.select().from(aiMessageLogs).where(typeof tenantId === "number" ? and20(eq22(aiMessageLogs.tenantId, tenantId)) : void 0).orderBy(desc13(aiMessageLogs.createdAt)).limit(limit).offset(offset);
}

// server/services/adminAudit.service.ts
init_schema();
async function recordAdminAudit(db, input) {
  await db.insert(adminAuditLogs).values({
    adminUserId: input.adminUserId,
    adminEmail: input.adminEmail ?? void 0,
    action: input.action,
    route: input.route,
    targetTenantId: input.targetTenantId,
    targetUserId: input.targetUserId,
    metadata: input.metadata
  });
}

// server/_core/pop3.ts
init_logger();
import poplib from "poplib";
import { simpleParser } from "mailparser";
async function connectPOP3(config) {
  return new Promise((resolve, reject) => {
    const client = new poplib.POP3Client(config.port, config.host, {
      tls: config.tls
    });
    client.on("connect", () => {
      logger.info("POP3 connected", { host: config.host, port: config.port });
      client.login(config.user, config.password, (err) => {
        if (err) {
          logger.error("POP3 login failed", { error: err.message, user: config.user });
          reject(err);
        } else {
          logger.info("POP3 login successful", { user: config.user });
          resolve(client);
        }
      });
    });
    client.on("error", (err) => {
      logger.error("POP3 connection error", { error: err.message });
      reject(err);
    });
    client.connect();
  });
}
async function retrieveEmails(client) {
  return new Promise((resolve, reject) => {
    client.stat((err, stats) => {
      if (err) {
        logger.error("POP3 stat failed", { error: err.message });
        reject(err);
        return;
      }
      const messageCount = stats.count;
      logger.info("POP3 messages found", { count: messageCount });
      if (messageCount === 0) {
        resolve([]);
        return;
      }
      const messages5 = [];
      let processedCount = 0;
      for (let i = 1; i <= messageCount; i++) {
        client.retr(i, (err2, data) => {
          if (err2) {
            logger.error("POP3 retr failed", { error: err2.message, messageNumber: i });
            processedCount++;
            if (processedCount === messageCount) {
              resolve(messages5);
            }
            return;
          }
          simpleParser(Buffer.from(data), (parseErr, parsed) => {
            if (parseErr) {
              logger.error("Email parse failed", { error: parseErr.message, messageNumber: i });
            } else {
              const message = {
                from: parsed.from?.text || "",
                to: parsed.to?.text || "",
                subject: parsed.subject || "",
                text: parsed.text || "",
                html: parsed.html || void 0,
                date: parsed.date || /* @__PURE__ */ new Date(),
                messageId: parsed.messageId || "",
                headers: parsed.headers
              };
              messages5.push(message);
            }
            processedCount++;
            if (processedCount === messageCount) {
              resolve(messages5);
            }
          });
        });
      }
    });
  });
}
async function deleteEmails(client, messageCount) {
  return new Promise((resolve, reject) => {
    let deletedCount = 0;
    for (let i = 1; i <= messageCount; i++) {
      client.dele(i, (err) => {
        if (err) {
          logger.error("POP3 delete failed", { error: err.message, messageNumber: i });
        }
        deletedCount++;
        if (deletedCount === messageCount) {
          client.quit(() => {
            logger.info("POP3 session ended", { deletedCount });
            resolve();
          });
        }
      });
    }
  });
}
async function processIncomingEmails(db, emails) {
  for (const email of emails) {
    try {
      const phoneNumber = extractPhoneNumber(email);
      if (phoneNumber) {
        const existingLead = await db.select().from(__require("../drizzle/schema").leads).where(
          __require("drizzle-orm").eq(
            __require("../drizzle/schema").leads.phone,
            phoneNumber
          )
        ).limit(1);
        if (existingLead.length === 0) {
          await db.insert(__require("../drizzle/schema").leads).values({
            phone: phoneNumber,
            name: extractNameFromEmail(email),
            email: email.from,
            tenantId: 1,
            // Default tenant - you may want to configure this
            status: "new",
            source: "email",
            createdAt: /* @__PURE__ */ new Date(),
            updatedAt: /* @__PURE__ */ new Date()
          });
          logger.info("Lead created from email", {
            phone: phoneNumber,
            email: email.from,
            subject: email.subject
          });
          await db.insert(__require("../drizzle/schema").messages).values({
            leadId: null,
            // Will be updated with actual lead ID
            tenantId: 1,
            direction: "inbound",
            body: email.text,
            subject: email.subject,
            fromEmail: email.from,
            toEmail: email.to,
            createdAt: email.date,
            updatedAt: /* @__PURE__ */ new Date()
          });
          logger.info("Email communication logged", {
            from: email.from,
            to: email.to,
            subject: email.subject
          });
        } else {
          logger.info("Lead already exists", {
            phone: phoneNumber,
            existingLeadId: existingLead[0].id
          });
          await db.insert(__require("../drizzle/schema").messages).values({
            leadId: existingLead[0].id,
            tenantId: existingLead[0].tenantId,
            direction: "inbound",
            body: email.text,
            subject: email.subject,
            fromEmail: email.from,
            toEmail: email.to,
            createdAt: email.date,
            updatedAt: /* @__PURE__ */ new Date()
          });
        }
      } else {
        logger.warn("No phone number found in email", {
          from: email.from,
          subject: email.subject
        });
      }
    } catch (error) {
      logger.error("Failed to process email", {
        error: String(error),
        messageId: email.messageId
      });
    }
  }
}
function extractPhoneNumber(email) {
  const text2 = `${email.subject} ${email.text}`;
  const patterns = [
    /(\+?1[\s-]?)?\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{4})/g,
    // US format
    /(\+44[\s-]?)?(\d{4})[\s-]?(\d{3})[\s-]?(\d{3})/g,
    // UK format
    /(\+\d{1,3}[\s-]?)?\(?(\d{1,4})\)?[\s-]?(\d{1,4})[\s-]?(\d{1,4})[\s-]?(\d{1,9})/g
    // International
  ];
  for (const pattern of patterns) {
    const matches = text2.match(pattern);
    if (matches) {
      const match = matches[0].replace(/[^\d+]/g, "");
      if (match.length >= 10) {
        return match.startsWith("+") ? match : `+1${match}`;
      }
    }
  }
  return null;
}
function extractNameFromEmail(email) {
  if (email.headers.from) {
    const nameMatch = email.headers.from.match(/^(.+?)\s+</);
    if (nameMatch) {
      return nameMatch[1].replace(/['"]/g, "").trim();
    }
  }
  if (email.subject) {
    const subjectNameMatch = email.subject.match(/^(.+?)(?:\s+[-:]\s+.*)?$/);
    if (subjectNameMatch && subjectNameMatch[1].length > 2) {
      return subjectNameMatch[1].trim();
    }
  }
  const emailMatch = email.from.match(/([^@]+)@/);
  return emailMatch ? emailMatch[1] : "Unknown";
}
async function checkAndProcessEmails(db) {
  const config = {
    host: process.env.POP3_HOST || "mail.rebooked.org",
    port: parseInt(process.env.POP3_PORT || "995", 10),
    user: process.env.POP3_USER || "",
    password: process.env.POP3_PASSWORD || "",
    tls: process.env.POP3_TLS !== "false"
  };
  if (!config.user || !config.password) {
    return { success: false, error: "POP3 credentials not configured" };
  }
  try {
    const client = await connectPOP3(config);
    const emails = await retrieveEmails(client);
    if (emails.length > 0) {
      await processIncomingEmails(db, emails);
      await deleteEmails(client, emails.length);
      logger.info("Email processing completed", {
        count: emails.length,
        host: config.host
      });
    }
    return {
      success: true,
      messagesProcessed: emails.length
    };
  } catch (error) {
    logger.error("Email processing failed", { error: String(error) });
    return {
      success: false,
      error: String(error)
    };
  }
}
async function testPOP3Connection() {
  const config = {
    host: process.env.POP3_HOST || "mail.rebooked.org",
    port: parseInt(process.env.POP3_PORT || "995", 10),
    user: process.env.POP3_USER || "",
    password: process.env.POP3_PASSWORD || "",
    tls: process.env.POP3_TLS !== "false"
  };
  if (!config.user || !config.password) {
    return { success: false, error: "POP3 credentials not configured" };
  }
  try {
    const client = await connectPOP3(config);
    return new Promise((resolve) => {
      client.stat((err, stats) => {
        client.quit(() => {
          if (err) {
            resolve({ success: false, error: err.message });
          } else {
            resolve({ success: true });
          }
        });
      });
    });
  } catch (error) {
    return { success: false, error: String(error) };
  }
}

// server/services/email.service.ts
init_logger();
var EmailService = class {
  /**
   * Send email using SMTP (local server) or fallback to SendGrid
   */
  static async sendEmail(options) {
    try {
      const result = await sendEmail(options);
      if (result.success) {
        logger.info("Email sent successfully", {
          to: options.to,
          subject: options.subject
        });
      } else {
        logger.warn("Email sending failed", {
          to: options.to,
          subject: options.subject,
          error: result.error
        });
      }
      return result;
    } catch (error) {
      const errorMessage = String(error);
      logger.error("Email service error", {
        to: options.to,
        subject: options.subject,
        error: errorMessage
      });
      return { success: false, error: errorMessage };
    }
  }
  /**
   * Check and process incoming emails from POP3
   */
  static async processIncomingEmails(db) {
    try {
      const result = await checkAndProcessEmails(db);
      if (result.success) {
        logger.info("Email processing completed", {
          messagesProcessed: result.messagesProcessed
        });
      } else {
        logger.warn("Email processing failed", {
          error: result.error
        });
      }
      return result;
    } catch (error) {
      const errorMessage = String(error);
      logger.error("Email processing service error", {
        error: errorMessage
      });
      return { success: false, error: errorMessage };
    }
  }
  /**
   * Test email configuration
   */
  static async testEmailConfiguration() {
    const results = {
      smtp: { success: false, error: "SMTP not configured" },
      pop3: { success: false, error: "POP3 not configured" }
    };
    if (process.env.SMTP_HOST && process.env.SMTP_USER) {
      try {
        const testResult = await sendEmail({
          to: process.env.EMAIL_FROM_ADDRESS || "test@rebooked.org",
          subject: "SMTP Test",
          text: "This is a test email to verify SMTP configuration."
        });
        results.smtp = { success: testResult.success, error: testResult.error };
      } catch (error) {
        results.smtp = { success: false, error: String(error) };
      }
    }
    try {
      const pop3Result = await testPOP3Connection();
      results.pop3 = pop3Result;
    } catch (error) {
      results.pop3 = { success: false, error: String(error) };
    }
    return results;
  }
  /**
   * Get email configuration status
   */
  static getConfigurationStatus() {
    return {
      smtp: !!(process.env.SMTP_HOST && process.env.SMTP_USER),
      pop3: !!(process.env.POP3_USER && process.env.POP3_PASSWORD),
      sendgrid: !!process.env.SENDGRID_API_KEY,
      details: {
        smtpHost: process.env.SMTP_HOST,
        smtpPort: process.env.SMTP_PORT,
        smtpUser: process.env.SMTP_USER,
        pop3Host: process.env.POP3_HOST,
        pop3Port: process.env.POP3_PORT,
        pop3User: process.env.POP3_USER,
        hasSendGrid: !!process.env.SENDGRID_API_KEY
      }
    };
  }
  /**
   * Send welcome email to new lead
   */
  static async sendWelcomeEmail(leadName, leadEmail, tenantName) {
    const subject = `Welcome to ${tenantName || "Rebooked"}!`;
    const text2 = `Hi ${leadName},

Welcome to ${tenantName || "Rebooked"}! We're excited to have you on board.

We'll be reaching out to you shortly to discuss how we can help you grow your business.

If you have any questions in the meantime, feel free to reply to this email.

Best regards,
The ${tenantName || "Rebooked"} Team`;
    const html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Welcome to ${tenantName || "Rebooked"}</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; padding: 20px 0; }
        .content { padding: 20px 0; }
        .footer { text-align: center; padding: 20px 0; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Welcome to ${tenantName || "Rebooked"}!</h1>
        </div>
        <div class="content">
            <p>Hi ${leadName},</p>
            <p>Welcome to ${tenantName || "Rebooked"}! We're excited to have you on board.</p>
            <p>We'll be reaching out to you shortly to discuss how we can help you grow your business.</p>
            <p>If you have any questions in the meantime, feel free to reply to this email.</p>
            <p>Best regards,<br>The ${tenantName || "Rebooked"} Team</p>
        </div>
        <div class="footer">
            <p>&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} ${tenantName || "Rebooked"}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
    return this.sendEmail({
      to: leadEmail,
      subject,
      text: text2,
      html
    });
  }
  /**
   * Send appointment confirmation email
   */
  static async sendAppointmentConfirmation(leadName, leadEmail, appointmentDate, tenantName) {
    const formattedDate = appointmentDate.toLocaleString();
    const subject = "Appointment Confirmation";
    const text2 = `Hi ${leadName},

This is a confirmation of your appointment scheduled for:

${formattedDate}

We look forward to speaking with you!

Best regards,
The ${tenantName || "Rebooked"} Team`;
    const html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Appointment Confirmation</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; padding: 20px 0; }
        .appointment { 
            background: #f8f9fa; 
            border-left: 4px solid #007bff; 
            padding: 15px; 
            margin: 20px 0; 
        }
        .footer { text-align: center; padding: 20px 0; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Appointment Confirmation</h1>
        </div>
        <div class="content">
            <p>Hi ${leadName},</p>
            <p>This is a confirmation of your appointment:</p>
            <div class="appointment">
                <strong>${formattedDate}</strong>
            </div>
            <p>We look forward to speaking with you!</p>
            <p>Best regards,<br>The ${tenantName || "Rebooked"} Team</p>
        </div>
        <div class="footer">
            <p>&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} ${tenantName || "Rebooked"}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
    return this.sendEmail({
      to: leadEmail,
      subject,
      text: text2,
      html
    });
  }
  /**
   * Send follow-up email
   */
  static async sendFollowUpEmail(leadName, leadEmail, message, tenantName) {
    const subject = "Following Up";
    const text2 = `Hi ${leadName},

${message}

Best regards,
The ${tenantName || "Rebooked"} Team`;
    const html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Following Up</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; padding: 20px 0; }
        .message { 
            background: #f8f9fa; 
            border-left: 4px solid #28a745; 
            padding: 15px; 
            margin: 20px 0; 
            white-space: pre-wrap;
        }
        .footer { text-align: center; padding: 20px 0; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Following Up</h1>
        </div>
        <div class="content">
            <p>Hi ${leadName},</p>
            <div class="message">${message}</div>
            <p>Best regards,<br>The ${tenantName || "Rebooked"} Team</p>
        </div>
        <div class="footer">
            <p>&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} ${tenantName || "Rebooked"}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
    return this.sendEmail({
      to: leadEmail,
      subject,
      text: text2,
      html
    });
  }
};

// shared/templates.ts
var automationTemplates = [
  {
    key: "appointment_confirmation_chase",
    name: "Confirmation Chase",
    category: "appointment",
    trigger: "appointment.booked",
    steps: [{ type: "sms", message: "Hi {{name}}, just checking that you're still good for {{date}} at {{time}}. Reply CONFIRM or RESCHEDULE." }]
  },
  {
    key: "inbound_response_sla",
    name: "Inbound Auto-Reply",
    category: "follow_up",
    trigger: "message.received",
    steps: [{ type: "sms", message: "Thanks for reaching out to {{business}}. We got your message and will text you back shortly." }]
  },
  {
    key: "qualified_followup_1d",
    name: "Qualified Lead Follow-Up (1 Day)",
    category: "follow_up",
    trigger: "lead.created",
    steps: [{ type: "sms", message: "Hi {{name}}, just checking in from {{business}}. Want me to help you grab a time?" }]
  },
  {
    key: "qualified_followup_3d",
    name: "Qualified Lead Follow-Up (3 Days)",
    category: "follow_up",
    trigger: "lead.created",
    steps: [{ type: "sms", message: "Still interested in booking with {{business}}? Reply YES and we'll help you lock in a spot." }]
  },
  {
    key: "delivery_failure_retry",
    name: "Delivery Failure Recovery",
    category: "follow_up",
    trigger: "message.sent",
    steps: [{ type: "sms", message: "We had trouble reaching you earlier. If you still want to book with {{business}}, reply here and we'll help." }]
  },
  {
    key: "next_visit_prompt",
    name: "Next Visit Prompt",
    category: "follow_up",
    trigger: "appointment.booked",
    steps: [{ type: "sms", message: "Thanks again for visiting {{business}}. Want to get your next appointment on the calendar now?" }]
  },
  {
    key: "waitlist_fill",
    name: "Waitlist Fill",
    category: "cancellation",
    trigger: "appointment.cancelled",
    steps: [{ type: "sms", message: "An appointment opening just came up at {{business}}. Want it? Reply YES and we'll hold it for you." }]
  },
  {
    key: "cancellation_same_day",
    name: "Same-Day Cancellation Rescue",
    category: "cancellation",
    trigger: "appointment.cancelled",
    steps: [{ type: "sms", message: "Sorry we missed you today. Want help finding a new time? Reply REBOOK and we'll make it easy." }]
  },
  {
    key: "cancellation_rebooking_48h",
    name: "Cancellation Rescue (48h)",
    category: "cancellation",
    trigger: "appointment.cancelled",
    steps: [{ type: "sms", message: "We still have a few spots open this week if you'd like to rebook. Reply YES and we'll send options." }]
  },
  {
    key: "cancellation_rebooking_7d",
    name: "Cancellation Rescue (7d)",
    category: "cancellation",
    trigger: "appointment.cancelled",
    steps: [{ type: "sms", message: "Last check-in from {{business}}. We'd still love to get you back on the calendar whenever you're ready." }]
  },
  {
    key: "vip_winback_45d",
    name: "VIP Win-Back (45d)",
    category: "reactivation",
    trigger: "appointment.booked",
    steps: [{ type: "sms", message: "Hi {{name}}, we've missed you at {{business}}. Want priority booking for your next visit? Reply VIP." }]
  },
  {
    key: "vip_winback_90d",
    name: "VIP Win-Back (90d)",
    category: "reactivation",
    trigger: "appointment.booked",
    steps: [{ type: "sms", message: "We've saved a special comeback offer for you at {{business}}. Reply YES if you want first pick of availability." }]
  },
  {
    key: "reduce_no_shows",
    name: "Reduce No-Shows",
    category: "no_show",
    trigger: "appointment.no_show",
    steps: [
      { type: "delay", value: 600 },
      { type: "sms", message: "Hey {{first_name}}, we missed you today. Want to reschedule?" }
    ]
  },
  {
    key: "welcome_new_lead",
    name: "Welcome New Lead",
    category: "welcome",
    trigger: "lead.created",
    steps: [
      { type: "sms", message: "Hi {{name}}, thanks for reaching out! Reply with a time that works and we'll book you." }
    ]
  },
  {
    key: "appointment_reminder_24h",
    name: "24-Hour Appointment Reminder",
    category: "appointment",
    trigger: "appointment.reminder_24h",
    steps: [
      { type: "sms", message: "Hi {{name}}, reminder: your appointment at {{business}} is tomorrow at {{time}}. Reply CONFIRM to keep it or RESCHEDULE to change." }
    ]
  },
  {
    key: "appointment_reminder_2h",
    name: "2-Hour Appointment Reminder",
    category: "appointment",
    trigger: "appointment.reminder_2h",
    steps: [
      { type: "sms", message: "Hi {{name}}, just a heads up \u2014 your appointment at {{business}} is in 2 hours at {{time}}. See you soon!" }
    ]
  },
  {
    key: "booking_confirmation",
    name: "Booking Confirmation",
    category: "appointment",
    trigger: "appointment.booked",
    steps: [
      { type: "sms", message: "You're all set! Your appointment at {{business}} is confirmed for {{date}} at {{time}}. Reply CANCEL if you need to change plans." }
    ]
  },
  {
    key: "review_request",
    name: "Review Request",
    category: "review",
    trigger: "appointment.completed",
    steps: [
      { type: "delay", value: 3600 },
      { type: "sms", message: "Thanks for visiting {{business}}! We'd love your feedback. Leave us a quick review here: {{review_link}}" }
    ]
  },
  {
    key: "birthday_promo",
    name: "Birthday Promo",
    category: "loyalty",
    trigger: "contact.birthday",
    steps: [
      { type: "sms", message: "Happy birthday, {{name}}! \u{1F382} {{business}} wants to celebrate with you \u2014 enjoy {{discount}} off your next visit. Book now!" }
    ]
  },
  {
    key: "loyalty_milestone",
    name: "Loyalty Milestone",
    category: "loyalty",
    trigger: "contact.milestone",
    steps: [
      { type: "sms", message: "Congrats {{name}}! You've hit {{milestone}} visits at {{business}}. As a thank you, here's a special reward: {{reward}}. Book your next visit!" }
    ]
  },
  {
    key: "post_visit_feedback",
    name: "Post-Visit Feedback",
    category: "follow_up",
    trigger: "appointment.completed",
    steps: [
      { type: "delay", value: 7200 },
      { type: "sms", message: "Hi {{name}}, how was your visit to {{business}} today? Reply 1-5 (5 = amazing). We'd love to hear from you!" }
    ]
  },
  {
    key: "post_visit_upsell",
    name: "Post-Visit Upsell",
    category: "follow_up",
    trigger: "appointment.completed",
    steps: [
      { type: "delay", value: 86400 },
      { type: "sms", message: "Hi {{name}}, loved having you at {{business}}! Did you know we also offer {{upsell_service}}? Reply INFO to learn more." }
    ]
  },
  {
    key: "cancellation_flurry",
    name: "Cancellation Flurry (Waiting List)",
    category: "cancellation",
    trigger: "appointment.cancelled",
    steps: [
      { type: "sms", message: "Great news! A spot just opened up at {{business}} on {{date}} at {{time}}. You're on the waiting list \u2014 reply BOOK to grab it before it's gone!" }
    ]
  }
];

// server/routers.ts
init_appErrors();
init_env();

// server/_core/webhookSignature.ts
import { createHmac as createHmac2, timingSafeEqual as timingSafeEqual2 } from "crypto";
function buildInboundWebhookPayload(event, data, tenantId) {
  return JSON.stringify({ event, data, tenantId });
}
function signInboundWebhookPayload(secret, event, data, tenantId) {
  const payload = buildInboundWebhookPayload(event, data, tenantId);
  return createHmac2("sha256", secret).update(payload).digest("hex");
}
function verifyInboundWebhookSignature(secret, event, data, tenantId, signatureHex) {
  const expected = signInboundWebhookPayload(secret, event, data, tenantId);
  try {
    const a = Buffer.from(String(signatureHex).trim(), "hex");
    const b = Buffer.from(expected, "hex");
    if (a.length !== b.length) return false;
    return timingSafeEqual2(a, b);
  } catch {
    return false;
  }
}

// server/services/webhookDedup.service.ts
init_schema();
async function tryClaimInboundWebhookDedup(db, tenantId, dedupeKey) {
  try {
    await db.insert(webhookReceiveDedupes).values({ tenantId, dedupeKey });
    return true;
  } catch (e) {
    const code = e?.code;
    const msg = String(e?.message ?? e);
    if (code === "ER_DUP_ENTRY" || msg.includes("Duplicate")) return false;
    throw e;
  }
}

// server/api/stripe-checkout.ts
import { z as z2 } from "zod";
init_schema();
import { TRPCError as TRPCError5 } from "@trpc/server";
import { eq as eq23, and as and21 } from "drizzle-orm";
async function verifyCustomerOwnership(db, tenantId, customerId) {
  const [sub] = await db.select({ id: stripeSubscriptions.id }).from(stripeSubscriptions).where(and21(eq23(stripeSubscriptions.tenantId, tenantId), eq23(stripeSubscriptions.customerId, customerId))).limit(1);
  if (!sub) throw new TRPCError5({ code: "FORBIDDEN", message: "Customer does not belong to your account" });
}
async function verifySubscriptionOwnership(db, tenantId, subscriptionId) {
  const [sub] = await db.select({ id: stripeSubscriptions.id }).from(stripeSubscriptions).where(and21(eq23(stripeSubscriptions.tenantId, tenantId), eq23(stripeSubscriptions.id, subscriptionId))).limit(1);
  if (!sub) throw new TRPCError5({ code: "FORBIDDEN", message: "Subscription does not belong to your account" });
}
var createCheckoutSessionSchema = z2.object({
  customerEmail: z2.string().email(),
  referralCode: z2.string().optional()
});
var reportUsageSchema = z2.object({
  customerId: z2.string(),
  recoveredAmount: z2.number().min(0)
});
var createPortalSessionSchema = z2.object({
  customerId: z2.string()
});
var cancelSubscriptionSchema = z2.object({
  subscriptionId: z2.string()
});
var resumeSubscriptionSchema = z2.object({
  subscriptionId: z2.string()
});
var getSubscriptionDetailsSchema = z2.object({
  subscriptionId: z2.string()
});
var getCurrentUsageSchema = z2.object({
  customerId: z2.string()
});
var stripeCheckoutRouter = {
  // Create Stripe Checkout Session
  createCheckoutSession: tenantProcedure.input(createCheckoutSessionSchema).mutation(async ({ input, ctx }) => {
    const checkoutUrl = await createCheckoutSession({
      customerEmail: input.customerEmail,
      userId: ctx.user.id.toString(),
      tenantId: ctx.tenantId.toString(),
      referralCode: input.referralCode
    });
    return {
      success: true,
      checkoutUrl,
      message: "Checkout session created successfully"
    };
  }),
  // Process successful checkout (webhook handler)
  processCheckoutSuccess: publicProcedure.input(z2.object({ sessionId: z2.string() })).mutation(async ({ input }) => {
    const subscriptionData = await processSuccessfulCheckout(input.sessionId);
    return {
      success: true,
      subscriptionData,
      message: "Checkout processed successfully"
    };
  }),
  // Report revenue recovery usage
  reportUsage: tenantProcedure.input(reportUsageSchema).mutation(async ({ input, ctx }) => {
    await verifyCustomerOwnership(ctx.db, ctx.tenantId, input.customerId);
    await reportRevenueUsage(
      input.customerId,
      input.recoveredAmount
    );
    return {
      success: true,
      message: `Reported $${input.recoveredAmount} revenue recovery`
    };
  }),
  // Get current usage for billing period
  getCurrentUsage: tenantProcedure.input(getCurrentUsageSchema).query(async ({ input, ctx }) => {
    await verifyCustomerOwnership(ctx.db, ctx.tenantId, input.customerId);
    const usage2 = await getCurrentUsage(input.customerId);
    const [sub] = await ctx.db.select({ revenueSharePercent: plans.revenueSharePercent }).from(subscriptions).innerJoin(plans, eq23(subscriptions.planId, plans.id)).where(eq23(subscriptions.tenantId, ctx.tenantId)).limit(1);
    const revenueShareRate = (sub?.revenueSharePercent ?? 15) / 100;
    return {
      success: true,
      usage: usage2,
      estimatedCharge: usage2 * revenueShareRate,
      revenueSharePercent: sub?.revenueSharePercent ?? 15,
      message: `Current usage: $${usage2} recovered revenue`
    };
  }),
  // Create customer portal session
  createPortalSession: tenantProcedure.input(createPortalSessionSchema).mutation(async ({ input, ctx }) => {
    await verifyCustomerOwnership(ctx.db, ctx.tenantId, input.customerId);
    const portalUrl = await createCustomerPortalSession(input.customerId);
    return {
      success: true,
      portalUrl,
      message: "Customer portal session created"
    };
  }),
  // Cancel subscription
  cancelSubscription: tenantProcedure.input(cancelSubscriptionSchema).mutation(async ({ input, ctx }) => {
    await verifySubscriptionOwnership(ctx.db, ctx.tenantId, input.subscriptionId);
    await cancelSubscription(input.subscriptionId);
    return {
      success: true,
      message: "Subscription will be cancelled at period end"
    };
  }),
  // Resume cancelled subscription
  resumeSubscription: tenantProcedure.input(resumeSubscriptionSchema).mutation(async ({ input, ctx }) => {
    await verifySubscriptionOwnership(ctx.db, ctx.tenantId, input.subscriptionId);
    await resumeSubscription(input.subscriptionId);
    return {
      success: true,
      message: "Subscription resumed successfully"
    };
  }),
  // Get subscription details
  getSubscriptionDetails: tenantProcedure.input(getSubscriptionDetailsSchema).query(async ({ input, ctx }) => {
    await verifySubscriptionOwnership(ctx.db, ctx.tenantId, input.subscriptionId);
    const subscription = await getSubscriptionDetails(input.subscriptionId);
    return {
      success: true,
      subscription,
      message: "Subscription details retrieved"
    };
  })
};

// server/api/referral.ts
import { z as z3 } from "zod";
init_referral_service();
var processReferralSchema = z3.object({
  referralCode: z3.string().min(6).max(16)
});
var completeReferralSchema = z3.object({
  referralId: z3.number().int().positive(),
  subscriptionId: z3.string().min(1),
  subscriptionMonths: z3.number().min(6)
});
var requestPayoutSchema = z3.object({
  method: z3.enum(["paypal", "stripe", "bank_transfer"])
});
var getLeaderboardSchema = z3.object({
  limit: z3.number().min(1).max(50).default(10),
  timeframe: z3.enum(["all", "month", "year"]).default("all")
});
var referralRouter = {
  // Generate a new referral code for the authenticated user
  generateReferralCode: protectedProcedure.mutation(async ({ ctx }) => {
    const referralCode = await generateReferralCode(ctx.user.id);
    return {
      success: true,
      referralCode,
      expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1e3)
    };
  }),
  // Process a referral code during signup/registration
  processReferral: publicProcedure.input(processReferralSchema).mutation(async ({ input, ctx }) => {
    if (!ctx.user) {
      return { success: false, message: "Must be logged in to use a referral code" };
    }
    const result = await processReferral(
      input.referralCode,
      ctx.user.id
    );
    return result;
  }),
  // Complete a referral when subscription meets requirements (system/admin only)
  completeReferral: adminProcedure.input(completeReferralSchema).mutation(async ({ input }) => {
    await completeReferral(
      input.referralId,
      input.subscriptionId,
      input.subscriptionMonths
    );
    return {
      success: true,
      message: "Referral completed successfully! $50 reward scheduled.",
      rewardAmount: 50
    };
  }),
  // Get referral statistics for the authenticated user
  getReferralStats: protectedProcedure.query(async ({ ctx }) => {
    const stats = await getReferralStats(ctx.user.id);
    return { success: true, stats };
  }),
  // Get all referrals for the authenticated user
  getUserReferrals: protectedProcedure.input(z3.object({ limit: z3.number().min(1).max(100).default(10) }).optional()).query(async ({ input, ctx }) => {
    const referrals2 = await getUserReferrals(ctx.user.id, input?.limit ?? 10);
    return {
      success: true,
      referrals: referrals2,
      total: referrals2.length
    };
  }),
  // Request payout of available referral earnings
  requestPayout: protectedProcedure.input(requestPayoutSchema).mutation(async ({ ctx, input }) => {
    const payout = await requestPayout(ctx.user.id, input.method);
    return {
      success: true,
      payout,
      message: "Payout request submitted successfully"
    };
  }),
  // Get user's payout history
  getUserPayouts: protectedProcedure.query(async ({ ctx }) => {
    const payouts = await getUserPayouts(ctx.user.id);
    return {
      success: true,
      payouts,
      total: payouts.length
    };
  }),
  // Get referral leaderboard
  getLeaderboard: publicProcedure.input(getLeaderboardSchema).query(async ({ input }) => {
    const leaderboard = await getReferralLeaderboard(
      input.limit,
      input.timeframe
    );
    return {
      success: true,
      leaderboard,
      total: leaderboard.length
    };
  }),
  // Clean up expired referrals (admin only)
  cleanupExpiredReferrals: adminProcedure.mutation(async () => {
    const cleanedCount = await cleanupExpiredReferrals();
    return {
      success: true,
      cleanedCount,
      message: `Cleaned up ${cleanedCount} expired referrals`
    };
  })
};

// server/api/stripe-connect.ts
import { z as z5 } from "zod";

// server/services/stripe-connect.service.ts
import Stripe5 from "stripe";
import { z as z4 } from "zod";
var createConnectAccountSchema = z4.object({
  email: z4.string().email(),
  displayName: z4.string().min(1)
});
var createProductSchema = z4.object({
  productName: z4.string().min(1),
  productDescription: z4.string().min(1),
  productPrice: z4.number().min(50),
  // Minimum $0.50
  accountId: z4.string().min(1)
});
var createCheckoutSessionSchema2 = z4.object({
  priceId: z4.string().min(1),
  accountId: z4.string().min(1)
});
var createPortalSessionSchema2 = z4.object({
  session_id: z4.string().min(1)
});
var StripeConnectService = class {
  stripe;
  constructor() {
    if (!process.env.STRIPE_SECRET_KEY) {
      throw new Error("STRIPE_SECRET_KEY environment variable is required");
    }
    this.stripe = new Stripe5(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2022-11-15"
    });
  }
  /**
   * Create a new Stripe Connect account
   */
  async createConnectAccount(data) {
    const validated = createConnectAccountSchema.parse(data);
    try {
      const account = await this.stripe.accounts.create({
        type: "express",
        country: "US",
        email: validated.email,
        business_profile: {
          name: validated.displayName
        },
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true }
        }
      });
      return {
        id: account.id,
        email: validated.email,
        display_name: validated.displayName,
        payouts_enabled: account.payouts_enabled,
        charges_enabled: account.charges_enabled,
        details_submitted: account.details_submitted
      };
    } catch (error) {
      console.error("Error creating Connect account:", error);
      throw new Error(`Failed to create Connect account: ${error.message}`);
    }
  }
  /**
   * Create account link for onboarding
   */
  async createAccountLink(accountId) {
    try {
      const accountLink = await this.stripe.accountLinks.create({
        account: accountId,
        type: "account_onboarding",
        refresh_url: `${process.env.APP_URL}/onboarding/refresh`,
        return_url: `${process.env.APP_URL}/onboarding/complete?accountId=${accountId}`
      });
      return { url: accountLink.url };
    } catch (error) {
      console.error("Error creating account link:", error);
      throw new Error(`Failed to create account link: ${error.message}`);
    }
  }
  /**
   * Get account status and requirements
   */
  async getAccountStatus(accountId) {
    try {
      const account = await this.stripe.accounts.retrieve(accountId);
      return {
        id: account.id,
        email: account.email || "",
        display_name: account.business_profile?.name || "",
        payouts_enabled: account.payouts_enabled,
        charges_enabled: account.charges_enabled,
        details_submitted: account.details_submitted,
        requirements: account.requirements
      };
    } catch (error) {
      console.error("Error getting account status:", error);
      throw new Error(`Failed to get account status: ${error.message}`);
    }
  }
  /**
   * Create a product and price for a connected account
   */
  async createProduct(data) {
    const validated = createProductSchema.parse(data);
    try {
      const product = await this.stripe.products.create(
        {
          name: validated.productName,
          description: validated.productDescription
        },
        { stripeAccount: validated.accountId }
      );
      const price = await this.stripe.prices.create(
        {
          product: product.id,
          unit_amount: validated.productPrice,
          currency: "usd"
        },
        { stripeAccount: validated.accountId }
      );
      return {
        id: product.id,
        name: validated.productName,
        description: validated.productDescription,
        price: validated.productPrice,
        priceId: price.id,
        image: "https://i.imgur.com/6Mvijcm.png"
      };
    } catch (error) {
      console.error("Error creating product:", error);
      throw new Error(`Failed to create product: ${error.message}`);
    }
  }
  /**
   * Get products for a specific account
   */
  async getProducts(accountId) {
    try {
      const options = {
        expand: ["data.product"],
        active: true,
        limit: 100
      };
      if (accountId !== "platform") {
        options.stripeAccount = accountId;
      }
      const prices = await this.stripe.prices.list(options);
      return prices.data.map((price) => ({
        id: price.product.id,
        name: price.product.name,
        description: price.product.description,
        price: price.unit_amount,
        priceId: price.id,
        period: price.recurring ? price.recurring.interval : null,
        image: "https://i.imgur.com/6Mvijcm.png"
      }));
    } catch (error) {
      console.error("Error fetching products:", error);
      throw new Error(`Failed to fetch products: ${error.message}`);
    }
  }
  /**
   * Create checkout session for connected account
   */
  async createCheckoutSession(data) {
    const validated = createCheckoutSessionSchema2.parse(data);
    try {
      const price = await this.stripe.prices.retrieve(validated.priceId, {
        stripeAccount: validated.accountId
      });
      const priceType = price.type;
      const mode = priceType === "recurring" ? "subscription" : "payment";
      const session = await this.stripe.checkout.sessions.create({
        line_items: [
          {
            price: validated.priceId,
            quantity: 1
          }
        ],
        mode,
        success_url: `${process.env.APP_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.APP_URL}/checkout/cancel`,
        payment_intent_data: {
          application_fee_amount: 123
          // Platform fee in cents
        }
      }, {
        stripeAccount: validated.accountId
      });
      return {
        url: session.url,
        sessionId: session.id
      };
    } catch (error) {
      console.error("Error creating checkout session:", error);
      throw new Error(`Failed to create checkout session: ${error.message}`);
    }
  }
  /**
   * Create subscription to platform (for platform services)
   */
  async subscribeToPlatform(accountId) {
    try {
      const priceId = process.env.PLATFORM_PRICE_ID;
      if (!priceId) {
        throw new Error("PLATFORM_PRICE_ID environment variable is required");
      }
      const session = await this.stripe.checkout.sessions.create({
        mode: "subscription",
        line_items: [
          {
            price: priceId,
            quantity: 1
          }
        ],
        success_url: `${process.env.APP_URL}?session_id={CHECKOUT_SESSION_ID}&success=true`,
        cancel_url: `${process.env.APP_URL}?canceled=true`
      });
      return {
        url: session.url,
        sessionId: session.id
      };
    } catch (error) {
      console.error("Error creating platform subscription:", error);
      throw new Error(`Failed to create platform subscription: ${error.message}`);
    }
  }
  /**
   * Create billing portal session
   */
  async createPortalSession(sessionId) {
    const validated = createPortalSessionSchema2.parse({ session_id: sessionId });
    try {
      const session = await this.stripe.checkout.sessions.retrieve(validated.session_id);
      const portalSession = await this.stripe.billingPortal.sessions.create({
        customer: session.customer,
        return_url: `${process.env.APP_URL}/?session_id=${validated.session_id}`
      });
      return { url: portalSession.url };
    } catch (error) {
      console.error("Error creating portal session:", error);
      throw new Error(`Failed to create portal session: ${error.message}`);
    }
  }
  /**
   * Parse webhook event
   */
  constructWebhookEvent(body, signature, secret) {
    try {
      return this.stripe.webhooks.constructEvent(body, signature, secret);
    } catch (error) {
      console.error("Webhook signature verification failed:", error);
      throw new Error(`Webhook signature verification failed: ${error.message}`);
    }
  }
};
var stripeConnectService = new StripeConnectService();

// server/api/stripe-connect.ts
import { TRPCError as TRPCError6 } from "@trpc/server";
var createConnectAccountSchema2 = z5.object({
  email: z5.string().email(),
  displayName: z5.string().min(1)
});
var createProductSchema2 = z5.object({
  productName: z5.string().min(1),
  productDescription: z5.string().min(1),
  productPrice: z5.number().min(50),
  // Minimum $0.50
  accountId: z5.string().min(1)
});
var createCheckoutSessionSchema3 = z5.object({
  priceId: z5.string().min(1),
  accountId: z5.string().min(1)
});
var createPortalSessionSchema3 = z5.object({
  session_id: z5.string().min(1)
});
var createConnectAccount = protectedProcedure.input(createConnectAccountSchema2).mutation(async ({ input }) => {
  try {
    const account = await stripeConnectService.createConnectAccount(input);
    return { success: true, account };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var createAccountLink = protectedProcedure.input(z5.object({ accountId: z5.string().min(1) })).mutation(async ({ input }) => {
  try {
    const accountLink = await stripeConnectService.createAccountLink(input.accountId);
    return { success: true, url: accountLink.url };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var getAccountStatus = tenantProcedure.input(z5.object({ accountId: z5.string().min(1) })).query(async ({ input }) => {
  try {
    const status = await stripeConnectService.getAccountStatus(input.accountId);
    return { success: true, status };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var createProduct = tenantProcedure.input(createProductSchema2).mutation(async ({ input }) => {
  try {
    const product = await stripeConnectService.createProduct(input);
    return { success: true, product };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var getProducts = tenantProcedure.input(z5.object({ accountId: z5.string().min(1) })).query(async ({ input }) => {
  try {
    const products = await stripeConnectService.getProducts(input.accountId);
    return { success: true, products };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var createCheckoutSession2 = tenantProcedure.input(createCheckoutSessionSchema3).mutation(async ({ input }) => {
  try {
    const session = await stripeConnectService.createCheckoutSession(input);
    return { success: true, url: session.url, sessionId: session.sessionId };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var subscribeToPlatform = protectedProcedure.input(z5.object({ accountId: z5.string().min(1) })).mutation(async ({ input }) => {
  try {
    const session = await stripeConnectService.subscribeToPlatform(input.accountId);
    return { success: true, url: session.url, sessionId: session.sessionId };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var createPortalSession = protectedProcedure.input(createPortalSessionSchema3).mutation(async ({ input }) => {
  try {
    const portalSession = await stripeConnectService.createPortalSession(input.session_id);
    return { success: true, url: portalSession.url };
  } catch (error) {
    throw new TRPCError6({
      code: "INTERNAL_SERVER_ERROR",
      message: error.message
    });
  }
});
var stripeConnectRouter = router({
  createConnectAccount,
  createAccountLink,
  getAccountStatus,
  createProduct,
  getProducts,
  createCheckoutSession: createCheckoutSession2,
  createPortalSession,
  subscribeToPlatform
});

// server/api/feature-config-router.ts
import { z as z6 } from "zod";

// server/services/feature-config.service.ts
init_schema();
import { eq as eq24, and as and22 } from "drizzle-orm";
async function getConfig(db, tenantId, feature) {
  const [row] = await db.select({ config: featureConfigs.config }).from(featureConfigs).where(
    and22(
      eq24(featureConfigs.tenantId, tenantId),
      eq24(featureConfigs.feature, feature)
    )
  ).limit(1);
  return row?.config ?? null;
}
async function saveConfig(db, tenantId, feature, config) {
  await db.insert(featureConfigs).values({ tenantId, feature, config }).onDuplicateKeyUpdate({
    set: { config, updatedAt: /* @__PURE__ */ new Date() }
  });
}

// server/api/feature-config-router.ts
var featureConfigRouter = {
  get: tenantProcedure.input(z6.object({ feature: z6.string().min(1).max(100) })).query(async ({ input, ctx }) => {
    const config = await getConfig(
      ctx.db,
      ctx.tenantId,
      input.feature
    );
    return { config };
  }),
  save: tenantProcedure.input(
    z6.object({
      feature: z6.string().min(1).max(100),
      config: z6.record(z6.string(), z6.unknown())
    })
  ).mutation(async ({ input, ctx }) => {
    await saveConfig(
      ctx.db,
      ctx.tenantId,
      input.feature,
      input.config
    );
    return { success: true };
  })
};

// server/routers.ts
function clampAdminPagination(input) {
  const page = Math.max(1, input?.page ?? 1);
  const limit = Math.min(100, Math.max(1, input?.limit ?? 50));
  return { page, limit };
}
var signupSchema = z7.object({
  email: z7.string().email(),
  password: z7.string().min(12).regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/, "Password must contain at least 12 characters, including uppercase, lowercase, number, and special character"),
  captchaToken: z7.string().optional(),
  website: z7.string().max(0).optional()
});
var forgotPasswordSchema = z7.object({
  email: z7.string().email()
});
var resetPasswordSchema = z7.object({
  token: z7.string().min(12),
  password: z7.string().min(12).regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/, "Password must contain at least 12 characters, including uppercase, lowercase, number, and special character")
});
async function sendVerificationEmail2(email, token) {
  const appUrl2 = process.env.APP_URL || "http://localhost:3000";
  const verifyUrl = `${appUrl2}/api/auth/verify-email?token=${encodeURIComponent(token)}`;
  await sendEmail({
    to: email,
    subject: "Verify your Rebooked email",
    text: `Verify your email to activate your account: ${verifyUrl}`,
    html: `<p>Verify your email to activate your account.</p><p><a href="${verifyUrl}">Verify email</a></p>`
  });
}
async function sendPasswordResetEmail(email, token) {
  const appUrl2 = process.env.APP_URL || "http://localhost:3000";
  const resetUrl = `${appUrl2}/login?mode=reset&token=${encodeURIComponent(token)}`;
  await sendEmail({
    to: email,
    subject: "Reset your Rebooked password",
    text: `Reset your password using this secure link: ${resetUrl}`,
    html: `<p>Reset your password using this secure link.</p><p><a href="${resetUrl}">Reset password</a></p>`
  });
}
async function auditAdminRead(ctx, action, metadata) {
  await recordAdminAudit(ctx.db, {
    adminUserId: ctx.user.id,
    adminEmail: ctx.user.email,
    action,
    route: ctx.req.path,
    metadata,
    targetTenantId: typeof metadata?.tenantId === "number" ? metadata.tenantId : void 0,
    targetUserId: typeof metadata?.userId === "number" ? metadata.userId : void 0
  });
}
async function checkAuthRateLimit(db, email) {
  const windowStart = new Date(Date.now() - 15 * 60 * 1e3);
  const maxAttempts = 10;
  try {
    const [{ count }] = await db.select({ count: sql16`count(*)` }).from(authRateLimits).where(
      and25(
        eq27(authRateLimits.email, email),
        gte7(authRateLimits.createdAt, windowStart)
      )
    );
    if (Number(count) >= maxAttempts) {
      return false;
    }
    await db.insert(authRateLimits).values({
      email,
      createdAt: /* @__PURE__ */ new Date()
    });
    return true;
  } catch (error) {
    console.warn("Auth rate limit table error:", error);
    return true;
  }
}
var appRouter = router({
  // ─── AUTH ──────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => ctx.user ?? null),
    logout: protectedProcedure.mutation(async ({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME, {
        maxAge: -1,
        ...getSessionCookieOptions(ctx.req),
        secure: true,
        sameSite: "none"
      });
      return { success: true };
    }),
    signup: publicProcedure.input(signupSchema).mutation(async ({ input, ctx }) => {
      if (input.website) {
        throw new TRPCError7({ code: "BAD_REQUEST", message: "Spam protection triggered" });
      }
      if (!await checkAuthRateLimit(ctx.db, input.email)) {
        throw new TRPCError7({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Try again later." });
      }
      const db = ctx.db;
      if (!db) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const existing = await getUserByEmail(db, input.email);
      if (existing?.emailVerifiedAt) throw new TRPCError7({ code: "CONFLICT", message: "Email already registered" });
      if (existing && !existing.emailVerifiedAt) {
        const verifyToken2 = await createEmailVerificationToken(db, existing.id, input.email);
        await sendVerificationEmail2(input.email, verifyToken2);
        return { success: true, pendingVerification: true };
      }
      const passwordHash = await bcrypt3.hash(input.password, 10);
      const openId = randomUUID2();
      await createUser(db, { openId, email: input.email, passwordHash, loginMethod: "password", role: "user", active: true });
      const created = await getUserByOpenId(db, openId);
      if (!created) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create user" });
      const verifyToken = await createEmailVerificationToken(db, created.id, input.email);
      await sendVerificationEmail2(input.email, verifyToken);
      return { success: true, pendingVerification: true };
    }),
    login: publicProcedure.input(loginSchema).mutation(async ({ input, ctx }) => {
      if (!await checkAuthRateLimit(ctx.db, input.email)) {
        throw new TRPCError7({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Try again later." });
      }
      const db = ctx.db;
      if (!db) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const user = await getUserByEmail(db, input.email);
      if (!user) throw new TRPCError7({ code: "UNAUTHORIZED", message: "Invalid email or password" });
      if (!user.passwordHash) throw new TRPCError7({ code: "UNAUTHORIZED", message: "No password set for this user" });
      const valid = await bcrypt3.compare(input.password, user.passwordHash);
      if (!valid) throw new TRPCError7({ code: "UNAUTHORIZED", message: "Invalid email or password" });
      if (!user.emailVerifiedAt) {
        const verifyToken = await createEmailVerificationToken(db, user.id, user.email || input.email);
        await sendVerificationEmail2(user.email || input.email, verifyToken);
        throw new TRPCError7({ code: "PRECONDITION_FAILED", message: "Verify your email before signing in. We sent a fresh link." });
      }
      await updateLastSignedIn(db, user.id);
      ctx.res.cookie(COOKIE_NAME, user.openId, { ...getSessionCookieOptions(ctx.req), httpOnly: true, secure: true, sameSite: "none" });
      return { success: true };
    }),
    requestPasswordReset: publicProcedure.input(forgotPasswordSchema).mutation(async ({ input, ctx }) => {
      const user = await getUserByEmail(ctx.db, input.email);
      if (user?.passwordHash) {
        const token = await createPasswordResetToken(ctx.db, user.id);
        await sendPasswordResetEmail(input.email, token);
      }
      return { success: true };
    }),
    resetPassword: publicProcedure.input(resetPasswordSchema).mutation(async ({ input, ctx }) => {
      const row = await consumePasswordResetToken(ctx.db, input.token);
      if (!row) throw new TRPCError7({ code: "BAD_REQUEST", message: "Reset link is invalid or expired" });
      const passwordHash = await bcrypt3.hash(input.password, 10);
      await setUserPasswordHash(ctx.db, row.userId, passwordHash);
      return { success: true };
    })
  }),
  // ─── LEADS ─────────────────────────────────────────────────────────────────
  leads: router({
    list: tenantProcedure.input(
      z7.object({
        page: z7.number().int().min(1).default(1),
        limit: z7.number().int().min(1).max(100).default(20),
        search: z7.string().max(200).optional(),
        status: z7.enum(["new", "contacted", "qualified", "booked", "lost", "unsubscribed"]).optional()
      }).optional()
    ).query(async ({ ctx, input }) => {
      return getLeads(ctx.db, ctx.tenantId, {
        page: input?.page ?? 1,
        limit: input?.limit ?? 20,
        search: input?.search,
        status: input?.status
      });
    }),
    get: tenantProcedure.input(z7.object({ leadId: z7.number() })).query(async ({ ctx, input }) => {
      const lead = await getLeadById(ctx.db, ctx.tenantId, input.leadId);
      if (!lead) throw new TRPCError7({ code: "NOT_FOUND" });
      return lead;
    }),
    create: tenantProcedure.input(createLeadSchema).mutation(async ({ ctx, input }) => {
      const created = await createLead(ctx.db, { tenantId: ctx.tenantId, name: input.name, phone: input.phone, email: input.email ?? void 0 });
      if (!("duplicate" in created && created.duplicate)) {
        await emitEvent({ type: "lead.created", tenantId: ctx.tenantId, data: { name: input.name, phone: input.phone }, userId: ctx.user.id, timestamp: /* @__PURE__ */ new Date() });
      }
      return created;
    }),
    update: tenantProcedure.input(updateLeadSchema).mutation(async ({ ctx, input }) => {
      await updateLead(ctx.db, ctx.tenantId, input.leadId, { name: input.name, email: input.email, phone: input.phone, appointmentAt: input.appointmentAt });
      return { success: true };
    }),
    updateStatus: tenantProcedure.input(updateLeadStatusSchema).mutation(async ({ ctx, input }) => {
      await updateLeadStatus(ctx.db, ctx.tenantId, input.leadId, input.status);
      return { success: true };
    }),
    messages: tenantProcedure.input(z7.object({ leadId: z7.number() })).query(async ({ ctx, input }) => {
      return getMessagesByLeadId(ctx.db, ctx.tenantId, input.leadId);
    }),
    sendMessage: tenantProcedure.input(sendMessageSchema).mutation(async ({ ctx, input }) => {
      let finalBody = input.body;
      if (input.tone) {
        try {
          const result = await invokeLLM({ messages: [
            { role: "system", content: `Rewrite in ${input.tone} tone. Under 160 chars. Return only text.` },
            { role: "user", content: input.body }
          ] });
          const content = result.choices?.[0]?.message?.content || "";
          finalBody = content.trim() || finalBody;
        } catch (err) {
          if (!isAppError(err)) {
            console.error("AI rewrite failed:", err);
          }
        }
      }
      const res = await sendMessage(
        ctx.db,
        ctx.tenantId,
        input.leadId,
        finalBody,
        input.idempotencyKey
      );
      await emitEvent({ type: "message.sent", tenantId: ctx.tenantId, data: { leadId: input.leadId, body: finalBody }, userId: ctx.user.id, timestamp: /* @__PURE__ */ new Date() });
      return { success: res.success, errorCode: res.errorCode, deduplicated: res.deduplicated };
    }),
    markNoShow: tenantProcedure.input(z7.object({ leadId: z7.number(), appointmentTime: z7.date().optional() })).mutation(async ({ ctx, input }) => {
      const lead = await getLeadById(ctx.db, ctx.tenantId, input.leadId);
      if (!lead) throw new TRPCError7({ code: "NOT_FOUND" });
      await updateLeadStatus(ctx.db, ctx.tenantId, input.leadId, "lost");
      await addLeadTags(ctx.db, ctx.tenantId, input.leadId, ["no_show"]);
      await emitEvent({ type: "appointment.no_show", tenantId: ctx.tenantId, data: { leadId: input.leadId, appointmentTime: input.appointmentTime ?? lead.appointmentAt, phone: lead.phone, name: lead.name }, userId: ctx.user.id, timestamp: /* @__PURE__ */ new Date() });
      return { success: true };
    }),
    markBooked: tenantProcedure.input(z7.object({ leadId: z7.number(), appointmentTime: z7.date(), trackingToken: z7.string().optional(), estimatedRevenue: z7.number().optional() })).mutation(async ({ ctx, input }) => {
      const lead = await getLeadById(ctx.db, ctx.tenantId, input.leadId);
      if (!lead) throw new TRPCError7({ code: "NOT_FOUND" });
      await updateLead(ctx.db, ctx.tenantId, input.leadId, { status: "booked", appointmentAt: input.appointmentTime });
      await addLeadTags(ctx.db, ctx.tenantId, input.leadId, ["booked_client"]);
      const attribution = await markRecoveryConverted(ctx.db, ctx.tenantId, input.leadId, {
        recoveredAppointmentId: `apt_${input.leadId}_${Date.now()}`,
        estimatedRevenue: input.estimatedRevenue,
        trackingToken: input.trackingToken
      });
      await emitEvent({ type: "appointment.booked", tenantId: ctx.tenantId, data: { leadId: input.leadId, appointmentTime: input.appointmentTime, phone: lead.phone, name: lead.name, recoveryEventId: attribution.primaryEventId }, userId: ctx.user.id, timestamp: /* @__PURE__ */ new Date() });
      return { success: true, primaryRecoveryEventId: attribution.primaryEventId };
    }),
    markCancelled: tenantProcedure.input(z7.object({ leadId: z7.number(), appointmentTime: z7.date().optional() })).mutation(async ({ ctx, input }) => {
      const lead = await getLeadById(ctx.db, ctx.tenantId, input.leadId);
      if (!lead) throw new TRPCError7({ code: "NOT_FOUND" });
      await updateLeadStatus(ctx.db, ctx.tenantId, input.leadId, "contacted");
      await addLeadTags(ctx.db, ctx.tenantId, input.leadId, ["cancelled"]);
      await emitEvent({ type: "appointment.cancelled", tenantId: ctx.tenantId, data: { leadId: input.leadId, appointmentTime: input.appointmentTime ?? lead.appointmentAt, phone: lead.phone, name: lead.name }, userId: ctx.user.id, timestamp: /* @__PURE__ */ new Date() });
      return { success: true };
    })
  }),
  // ─── AUTOMATIONS ───────────────────────────────────────────────────────────
  automations: router({
    list: tenantProcedure.query(async ({ ctx }) => getAutomations(ctx.db, ctx.tenantId)),
    catalog: protectedProcedure.query(async () => automationTemplates),
    toggleByKey: tenantProcedure.input(z7.object({ key: z7.string(), enabled: z7.boolean() })).mutation(async ({ ctx, input }) => {
      if (input.enabled) {
        const entitled = await tenantHasAutomationAccess(ctx.db, ctx.tenantId);
        if (!entitled) {
          throw new TRPCError7({
            code: "FORBIDDEN",
            message: "Cannot enable automations: trial has expired or subscription is inactive"
          });
        }
      }
      const automation = await getAutomationByKey(ctx.db, ctx.tenantId, input.key);
      if (!automation) throw new TRPCError7({ code: "NOT_FOUND" });
      await updateAutomation(ctx.db, ctx.tenantId, automation.id, { enabled: input.enabled });
      return { success: true };
    }),
    configureByKey: tenantProcedure.input(z7.object({ key: z7.string(), config: z7.record(z7.string(), z7.any()) })).mutation(async ({ ctx, input }) => {
      const entitled = await tenantHasAutomationAccess(ctx.db, ctx.tenantId);
      if (!entitled) {
        throw new TRPCError7({
          code: "FORBIDDEN",
          message: "Cannot configure automations: trial has expired or subscription is inactive"
        });
      }
      const automation = await getAutomationByKey(ctx.db, ctx.tenantId, input.key);
      if (!automation) throw new TRPCError7({ code: "NOT_FOUND" });
      await upsertAutomationByKey(ctx.db, ctx.tenantId, input.key, {
        name: automation.name,
        category: automation.category,
        triggerType: automation.triggerType,
        triggerConfig: input.config,
        actions: [{ type: "send_message", body: String(input.config.message || ""), tone: "friendly" }],
        enabled: automation.enabled
      });
      return { success: true };
    }),
    activateTemplate: tenantProcedure.input(z7.object({ templateKey: z7.string() })).mutation(async ({ ctx, input }) => {
      const entitled = await tenantHasAutomationAccess(ctx.db, ctx.tenantId);
      if (!entitled) {
        throw new TRPCError7({
          code: "FORBIDDEN",
          message: "Cannot activate automations: trial has expired or subscription is inactive"
        });
      }
      const template = automationTemplates.find((t2) => t2.key === input.templateKey);
      if (!template) throw new TRPCError7({ code: "NOT_FOUND" });
      const triggerMapping = {
        "lead.created": "new_lead",
        "appointment.booked": "appointment_reminder",
        "appointment.no_show": "time_delay",
        "appointment.cancelled": "appointment_reminder",
        "message.received": "inbound_message"
      };
      await upsertAutomationByKey(ctx.db, ctx.tenantId, template.key, {
        name: template.name,
        category: template.category,
        triggerType: triggerMapping[template.trigger] || "custom",
        triggerConfig: {},
        conditions: [],
        actions: template.steps,
        enabled: true
      });
      return { success: true };
    }),
    test: tenantProcedure.input(z7.object({ automationId: z7.number(), testPhone: phoneSchema })).mutation(async ({ ctx, input }) => {
      const auto = await getAutomationById(ctx.db, ctx.tenantId, input.automationId);
      if (!auto) throw new TRPCError7({ code: "NOT_FOUND" });
      await runAutomationsForEvent({ type: auto.triggerType, tenantId: ctx.tenantId, data: { phone: input.testPhone, first_name: "Test User" }, timestamp: /* @__PURE__ */ new Date() });
      return { success: true, message: "Test sequence fired" };
    })
  }),
  // ─── AI ────────────────────────────────────────────────────────────────────
  ai: router({
    rewrite: protectedProcedure.input(z7.object({ message: z7.string().min(1), tone: z7.enum(["friendly", "professional", "casual", "urgent", "empathetic"]) })).mutation(async ({ input }) => {
      try {
        const result = await invokeLLM({ messages: [
          { role: "system", content: `Expert SMS copywriter. Rewrite in ${input.tone} tone. Under 160 chars. Return ONLY the message.` },
          { role: "user", content: input.message }
        ] });
        const content = result.choices?.[0]?.message?.content || "";
        return { rewritten: content.trim() };
      } catch (err) {
        console.error("AI rewrite error:", err);
        if (isAppError(err)) {
          throw new TRPCError7({ code: err.statusCode === 503 ? "SERVICE_UNAVAILABLE" : "INTERNAL_SERVER_ERROR", message: err.message });
        }
        throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR", message: "AI rewrite failed" });
      }
    })
  }),
  // ─── TEMPLATES ─────────────────────────────────────────────────────────────
  templates: router({
    list: tenantProcedure.query(async ({ ctx }) => getTemplates(ctx.db, ctx.tenantId)),
    create: tenantProcedure.input(z7.object({ key: z7.string(), name: z7.string(), body: z7.string(), tone: z7.enum(["friendly", "professional", "casual", "urgent"]).optional(), category: z7.string().optional() })).mutation(async ({ ctx, input }) => {
      await createTemplate(ctx.db, { ...input, tenantId: ctx.tenantId });
      return { success: true };
    }),
    update: tenantProcedure.input(z7.object({ templateId: z7.number(), name: z7.string().optional(), body: z7.string().optional(), tone: z7.enum(["friendly", "professional", "casual", "urgent"]).optional() })).mutation(async ({ ctx, input }) => {
      await updateTemplate(ctx.db, ctx.tenantId, input.templateId, input);
      return { success: true };
    }),
    delete: tenantProcedure.input(z7.object({ templateId: z7.number() })).mutation(async ({ ctx, input }) => {
      await deleteTemplate(ctx.db, ctx.tenantId, input.templateId);
      return { success: true };
    }),
    preview: protectedProcedure.input(z7.object({ body: z7.string(), tone: z7.enum(["friendly", "professional", "casual", "urgent"]) })).mutation(async ({ input }) => {
      const { rewriteMessage: rewriteMessage2 } = await Promise.resolve().then(() => (init_ai(), ai_exports));
      const rewritten = await rewriteMessage2(input.body, input.tone);
      return { rewritten };
    })
  }),
  // ─── API KEYS ──────────────────────────────────────────────────────────────
  apiKeys: router({
    list: tenantProcedure.query(async ({ ctx }) => getApiKeys(ctx.db, ctx.tenantId)),
    create: tenantProcedure.input(z7.object({ label: z7.string().optional() })).mutation(async ({ ctx, input }) => {
      const key = `rk_${randomUUID2().replace(/-/g, "")}`;
      const keyHash = await bcrypt3.hash(key, 10);
      await createApiKey(ctx.db, ctx.tenantId, keyHash, key.slice(0, 7), input.label);
      return { key };
    }),
    revoke: tenantProcedure.input(z7.object({ keyId: z7.number() })).mutation(async ({ ctx, input }) => {
      await revokeApiKey(ctx.db, ctx.tenantId, input.keyId);
      return { success: true };
    })
  }),
  // ─── WEBHOOKS ──────────────────────────────────────────────────────────────
  webhooks: router({
    receive: publicProcedure.input(z7.object({
      event: z7.enum(["lead.created", "appointment.booked", "appointment.no_show", "appointment.cancelled", "message.received", "message.sent"]),
      data: z7.record(z7.string(), z7.any()),
      tenantId: z7.number(),
      userId: z7.number().optional(),
      signature: z7.string().optional(),
      /** Client-supplied key; duplicate deliveries return deduplicated: true */
      idempotencyKey: z7.string().min(8).max(64).optional()
    })).mutation(async ({ input, ctx }) => {
      const isProd2 = process.env.NODE_ENV === "production";
      const secret = ENV.webhookSecret?.trim();
      const allowUnsigned = !isProd2 && process.env.WEBHOOK_ALLOW_UNSIGNED === "true";
      if (!secret) {
        if (!allowUnsigned) {
          throw new TRPCError7({
            code: "PRECONDITION_FAILED",
            message: isProd2 ? "WEBHOOK_SECRET is required in production" : "Set WEBHOOK_SECRET or WEBHOOK_ALLOW_UNSIGNED=true (development only)"
          });
        }
      } else {
        const sig = input.signature ?? ctx.req.headers["x-webhook-signature"] ?? "";
        if (!sig || !verifyInboundWebhookSignature(secret, input.event, input.data, input.tenantId, sig)) {
          throw new TRPCError7({ code: "UNAUTHORIZED", message: "Invalid or missing webhook signature" });
        }
      }
      if (input.idempotencyKey) {
        if (!ctx.db) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        const first = await tryClaimInboundWebhookDedup(ctx.db, input.tenantId, input.idempotencyKey);
        if (!first) return { success: true, deduplicated: true };
      }
      await emitEvent({ type: input.event, data: input.data, tenantId: input.tenantId, userId: input.userId, timestamp: /* @__PURE__ */ new Date() });
      return { success: true };
    })
  }),
  // ─── TENANT ────────────────────────────────────────────────────────────────
  tenant: router({
    get: tenantProcedure.query(async ({ ctx }) => {
      const tenant = await getTenantById(ctx.db, ctx.tenantId);
      if (!tenant) throw new TRPCError7({ code: "NOT_FOUND", message: "Tenant not found" });
      return tenant;
    }),
    update: tenantProcedure.input(z7.object({ name: z7.string().optional(), timezone: z7.string().optional(), industry: z7.string().optional() })).mutation(async ({ ctx, input }) => {
      await updateTenant(ctx.db, ctx.tenantId, input);
      return { success: true };
    }),
    subscription: tenantProcedure.query(async ({ ctx }) => {
      const sub = await getSubscriptionByTenantId(ctx.db, ctx.tenantId);
      if (!sub) throw new TRPCError7({ code: "NOT_FOUND", message: "Subscription not found" });
      return { sub };
    }),
    usage: tenantProcedure.query(async ({ ctx }) => {
      const usageData = await getUsageByTenantId(ctx.db, ctx.tenantId);
      if (!usageData) throw new TRPCError7({ code: "NOT_FOUND", message: "Usage data not found" });
      return usageData;
    }),
    phoneNumbers: tenantProcedure.query(async ({ ctx }) => getPhoneNumbersByTenantId(ctx.db, ctx.tenantId)),
    addPhoneNumber: tenantProcedure.input(z7.object({ number: phoneSchema, label: z7.string().optional() })).mutation(async ({ ctx, input }) => {
      await addPhoneNumber(ctx.db, ctx.tenantId, { number: input.number, title: input.label });
      return { success: true };
    }),
    removePhoneNumber: tenantProcedure.input(z7.object({ phoneNumberId: z7.number() })).mutation(async ({ ctx, input }) => {
      await removePhoneNumber(ctx.db, ctx.tenantId, input.phoneNumberId);
      return { success: true };
    }),
    setDefaultPhoneNumber: tenantProcedure.input(z7.object({ phoneNumberId: z7.number() })).mutation(async ({ ctx, input }) => {
      await setDefaultPhoneNumber(ctx.db, ctx.tenantId, input.phoneNumberId);
      return { success: true };
    }),
    setInboundPhoneNumber: tenantProcedure.input(z7.object({ phoneNumberId: z7.number() })).mutation(async ({ ctx, input }) => {
      await setInboundPhoneNumber(ctx.db, ctx.tenantId, input.phoneNumberId);
      return { success: true };
    })
  }),
  // ─── ANALYTICS ─────────────────────────────────────────────────────────────
  analytics: router({
    dashboard: tenantProcedure.input(z7.object({ days: z7.number().int().min(1).max(90).default(30) }).optional()).query(async ({ ctx, input }) => {
      const [metrics, statusBreakdown, messageVolume, recentMessages, revenueMetrics, revenueTrends, attributedRevenue] = await Promise.all([
        getDashboardMetrics(ctx.db, ctx.tenantId),
        getLeadStatusBreakdown(ctx.db, ctx.tenantId),
        getMessageVolume(ctx.db, ctx.tenantId, input?.days ?? 30),
        getRecentMessages(ctx.db, ctx.tenantId, 10),
        getRevenueRecoveryMetrics(ctx.db, ctx.tenantId),
        getRevenueTrends(ctx.db, ctx.tenantId, 90),
        getAttributedRevenueMetrics(ctx.db, ctx.tenantId).catch(() => null)
      ]);
      const leakage = await getLeakageMetrics(ctx.db, ctx.tenantId);
      return { metrics, statusBreakdown, messageVolume, recentMessages, leakage, revenueMetrics, revenueTrends, attributedRevenue };
    }),
    revenueLeakage: tenantProcedure.input(z7.object({ days: z7.number().int().min(1).max(365).default(90) })).query(async ({ ctx, input }) => {
      const LeakageService = await Promise.resolve().then(() => (init_revenue_leakage_service(), revenue_leakage_service_exports));
      const leakageReport = await LeakageService.detectRevenueLeakage(ctx.db, ctx.tenantId, input.days);
      return leakageReport;
    }),
    createRecoveryCampaign: tenantProcedure.input(z7.object({
      leakageType: z7.string(),
      priority: z7.enum(["low", "medium", "high", "urgent"]).default("medium"),
      messageTemplate: z7.string().optional(),
      discountAmount: z7.number().optional(),
      scheduleDelay: z7.number().optional()
    })).mutation(async ({ ctx, input }) => {
      const RecoveryService = await Promise.resolve().then(() => (init_revenue_recovery_service(), revenue_recovery_service_exports));
      const campaign = await RecoveryService.createRecoveryCampaign(
        ctx.db,
        ctx.tenantId,
        input.leakageType,
        {
          priority: input.priority,
          messageTemplate: input.messageTemplate,
          discountAmount: input.discountAmount,
          scheduleDelay: input.scheduleDelay
        }
      );
      return campaign;
    }),
    executeRecoveryCampaign: tenantProcedure.input(z7.object({ campaignId: z7.string() })).mutation(async ({ ctx, input }) => {
      const RecoveryService = await Promise.resolve().then(() => (init_revenue_recovery_service(), revenue_recovery_service_exports));
      const result = await RecoveryService.executeRecoveryCampaign(ctx.db, ctx.tenantId, input.campaignId);
      return result;
    }),
    analyzeRecoveryEffectiveness: tenantProcedure.input(z7.object({ days: z7.number().int().min(1).max(365).default(30) })).query(async ({ ctx, input }) => {
      const RecoveryService = await Promise.resolve().then(() => (init_revenue_recovery_service(), revenue_recovery_service_exports));
      const analysis = await RecoveryService.analyzeRecoveryEffectiveness(ctx.db, ctx.tenantId, input.days);
      return analysis;
    }),
    // ─── ATTRIBUTION-ACCURATE REVENUE METRICS ──────────────────────────────
    attributedRevenue: tenantProcedure.query(async ({ ctx }) => {
      return getAttributedRevenueMetrics(ctx.db, ctx.tenantId);
    }),
    automationAttribution: tenantProcedure.query(async ({ ctx }) => {
      return getAutomationAttribution(ctx.db, ctx.tenantId);
    }),
    // ─── RECOVERY LEDGER (bank-statement-reconcilable export) ──────────────
    recoveryLedger: tenantProcedure.input(z7.object({
      startDate: z7.date().optional(),
      endDate: z7.date().optional(),
      statusFilter: z7.array(z7.string()).optional(),
      limit: z7.number().int().min(1).max(1e3).default(500),
      offset: z7.number().int().min(0).default(0)
    }).optional()).query(async ({ ctx, input }) => {
      return getRecoveryLedger(ctx.db, ctx.tenantId, {
        startDate: input?.startDate,
        endDate: input?.endDate,
        statusFilter: input?.statusFilter,
        limit: input?.limit,
        offset: input?.offset
      });
    }),
    exportRecoveryLedgerCSV: tenantProcedure.input(z7.object({
      startDate: z7.date().optional(),
      endDate: z7.date().optional()
    }).optional()).query(async ({ ctx, input }) => {
      const { entries } = await getRecoveryLedger(ctx.db, ctx.tenantId, {
        startDate: input?.startDate,
        endDate: input?.endDate,
        limit: 1e4
      });
      return { csv: ledgerToCSV(entries), count: entries.length };
    }),
    // ─── MANUAL RECOVERY MARKING (off-platform payments) ───────────────────
    markManualRecovery: tenantProcedure.input(z7.object({
      leadId: z7.number(),
      realizedRevenue: z7.number().int().min(1),
      // in cents
      notes: z7.string().optional(),
      recoveryEventId: z7.number().optional()
    })).mutation(async ({ ctx, input }) => {
      await markManualRecovery(ctx.db, ctx.tenantId, input.leadId, {
        realizedRevenue: input.realizedRevenue,
        notes: input.notes,
        recoveryEventId: input.recoveryEventId
      });
      return { success: true };
    }),
    // ─── MARK STRIPE PAYMENT AS REALIZED ───────────────────────────────────
    markPaymentRealized: tenantProcedure.input(z7.object({
      leadId: z7.number(),
      stripePaymentIntentId: z7.string(),
      stripeInvoiceId: z7.string().optional(),
      realizedRevenue: z7.number().int().min(1),
      // in cents
      recoveryEventId: z7.number().optional()
    })).mutation(async ({ ctx, input }) => {
      await markRecoveryRealized(ctx.db, ctx.tenantId, input.leadId, {
        stripePaymentIntentId: input.stripePaymentIntentId,
        stripeInvoiceId: input.stripeInvoiceId,
        realizedRevenue: input.realizedRevenue,
        recoveryEventId: input.recoveryEventId
      });
      return { success: true };
    })
  }),
  // ─── PLANS ─────────────────────────────────────────────────────────────────
  plans: router({
    list: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.db) return [];
      return getAllPlans(ctx.db);
    })
  }),
  // ─── PUBLIC PLATFORM STATS (landing page) ─────────────────────────────────
  platformStats: router({
    get: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.db) return { businesses: 0, messagesSent: 0, appointmentsRecovered: 0, revenueRecovered: 0 };
      const [bizCount] = await ctx.db.select({ count: sql16`count(*)` }).from(tenants);
      const [msgCount] = await ctx.db.select({ count: sql16`count(*)` }).from(messages).where(eq27(messages.direction, "outbound"));
      const [bookedCount] = await ctx.db.select({ count: sql16`count(*)` }).from(leads).where(eq27(leads.status, "booked"));
      return {
        businesses: Number(bizCount?.count ?? 0),
        messagesSent: Number(msgCount?.count ?? 0),
        appointmentsRecovered: Number(bookedCount?.count ?? 0),
        revenueRecovered: 0
      };
    })
  }),
  // ─── BILLING ───────────────────────────────────────────────────────────────
  billing: router({
    createCheckoutSession: tenantProcedure.input(z7.object({ priceId: z7.string() })).mutation(async ({ ctx, input }) => {
      const stripe5 = new Stripe6(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2022-11-15" });
      const session = await stripe5.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [{ price: input.priceId, quantity: 1 }],
        success_url: `${process.env.APP_URL || "http://localhost:3000"}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.APP_URL || "http://localhost:3000"}/billing/cancel`,
        metadata: { tenantId: String(ctx.tenantId) },
        customer_email: ctx.user.email ?? void 0
      });
      return { url: session.url, id: session.id };
    }),
    changePlan: tenantProcedure.input(z7.object({ priceId: z7.string(), prorateImmediately: z7.boolean().default(true) })).mutation(async ({ ctx, input }) => {
      if (ctx.user.role === "admin") {
        await auditAdminRead(ctx, "admin.billing.changePlan", {
          targetTenantId: ctx.tenantId,
          priceId: input.priceId,
          prorateImmediately: input.prorateImmediately
        });
      }
      const updated = await changeSubscriptionPlan(ctx.db, {
        tenantId: ctx.tenantId,
        priceId: input.priceId,
        prorateImmediately: input.prorateImmediately
      });
      return { success: true, status: updated.status };
    }),
    createCustomerPortal: tenantProcedure.input(z7.object({ returnUrl: z7.string().url().optional() })).mutation(async ({ ctx, input }) => {
      const stripe5 = new Stripe6(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2022-11-15" });
      const rows = await ctx.db.select().from(subscriptions).where(eq27(subscriptions.tenantId, ctx.tenantId)).limit(1);
      const subRow = rows[0];
      let customerId;
      if (subRow?.stripeId) {
        const stripeSub = await stripe5.subscriptions.retrieve(subRow.stripeId).catch(() => null);
        customerId = stripeSub?.customer;
      }
      if (!customerId) throw new TRPCError7({ code: "BAD_REQUEST", message: "No Stripe customer found" });
      const portal = await stripe5.billingPortal.sessions.create({
        customer: customerId,
        return_url: input.returnUrl || `${process.env.APP_URL || "http://localhost:3000"}/billing`
      });
      return { url: portal.url };
    }),
    invoices: tenantProcedure.query(async ({ ctx }) => {
      const [invoices, refunds] = await Promise.all([
        listInvoicesByTenant(ctx.db, ctx.tenantId),
        listRefundsByTenant(ctx.db, ctx.tenantId)
      ]);
      return { invoices, refunds };
    }),
    refundInvoice: tenantProcedure.input(z7.object({
      stripeInvoiceId: z7.string(),
      amount: z7.number().int().positive().optional(),
      reason: z7.enum(["duplicate", "fraudulent", "requested_by_customer"]).optional()
    })).mutation(async ({ ctx, input }) => {
      if (ctx.user.role === "admin") {
        await auditAdminRead(ctx, "admin.billing.refundInvoice", {
          targetTenantId: ctx.tenantId,
          stripeInvoiceId: input.stripeInvoiceId,
          amount: input.amount,
          reason: input.reason
        });
      }
      const refund = await issueRefundForInvoiceCharge(ctx.db, {
        tenantId: ctx.tenantId,
        stripeInvoiceId: input.stripeInvoiceId,
        amount: input.amount,
        reason: input.reason
      });
      return { success: true, refundId: refund.id };
    })
  }),
  // ─── ONBOARDING ────────────────────────────────────────────────────────────
  onboarding: router({
    setup: tenantProcedure.input(z7.any()).mutation(async () => ({ success: true }))
  }),
  // ─── ADMIN ─────────────────────────────────────────────────────────────────
  admin: router({
    tenants: router({
      list: adminProcedure.input(paginationSchema).query(async ({ ctx, input }) => {
        await auditAdminRead(ctx, "admin.tenants.list", { page: input?.page, limit: input?.limit });
        const { page, limit } = clampAdminPagination(input);
        const { rows, total } = await getAllTenants(ctx.db, page, limit);
        return { tenants: rows, total };
      })
    }),
    users: router({
      list: adminProcedure.input(paginationSchema).query(async ({ ctx, input }) => {
        await auditAdminRead(ctx, "admin.users.list", { page: input?.page, limit: input?.limit });
        const { page, limit } = clampAdminPagination(input);
        const { rows, total } = await getAllUsers(ctx.db, page, limit);
        return { users: rows, total };
      }),
      toggleActive: adminProcedure.input(z7.object({ userId: z7.number(), active: z7.boolean() })).mutation(async ({ ctx, input }) => {
        await updateUserActive(ctx.db, input.userId, input.active);
        return { success: true };
      })
    }),
    systemHealth: router({
      errors: adminProcedure.input(z7.object({ limit: z7.number().int().min(1).max(100).optional() }).optional()).query(async ({ ctx, input }) => {
        await auditAdminRead(ctx, "admin.systemHealth.errors", { limit: input?.limit });
        const lim = Math.min(100, Math.max(1, input?.limit ?? 50));
        return getSystemErrors(ctx.db, void 0, lim);
      })
    }),
    webhookLogs: router({
      list: adminProcedure.input(paginationSchema).query(async ({ ctx, input }) => {
        await auditAdminRead(ctx, "admin.webhookLogs.list", { page: input?.page, limit: input?.limit });
        const { page, limit } = clampAdminPagination(input);
        return getWebhookLogs(ctx.db, void 0, limit, page);
      })
    }),
    aiLogs: router({
      list: adminProcedure.input(paginationSchema).query(async ({ ctx, input }) => {
        await auditAdminRead(ctx, "admin.aiLogs.list", { page: input?.page, limit: input?.limit });
        const { page, limit } = clampAdminPagination(input);
        return getAiLogs(ctx.db, void 0, limit, page);
      })
    }),
    email: router({
      status: adminProcedure.query(async ({ ctx }) => {
        await auditAdminRead(ctx, "admin.email.status");
        return EmailService.getConfigurationStatus();
      }),
      test: adminProcedure.mutation(async ({ ctx }) => {
        await auditAdminRead(ctx, "admin.email.test");
        return EmailService.testEmailConfiguration();
      }),
      send: adminProcedure.input(z7.object({
        to: z7.string().email(),
        subject: z7.string(),
        text: z7.string(),
        html: z7.string().optional()
      })).mutation(async ({ ctx, input }) => {
        await auditAdminRead(ctx, "admin.email.send", { to: input.to, subject: input.subject });
        return EmailService.sendEmail(input);
      })
    }),
    guarantee: router({
      overview: adminProcedure.query(async ({ ctx }) => {
        return getGuaranteeOverview(ctx.db);
      }),
      evaluateAll: adminProcedure.mutation(async ({ ctx }) => {
        return evaluateAllGuarantees(ctx.db);
      }),
      evaluateTenant: adminProcedure.input(z7.object({ tenantId: z7.number() })).mutation(async ({ ctx, input }) => {
        return evaluateGuarantee(ctx.db, input.tenantId);
      }),
      enroll: adminProcedure.input(z7.object({
        subscriptionId: z7.number(),
        cohort: z7.enum(["risk_free_20", "flex_10"])
      })).mutation(async ({ ctx, input }) => {
        return enrollInGuarantee(ctx.db, input.subscriptionId, input.cohort);
      }),
      cohortAvailability: adminProcedure.query(async ({ ctx }) => {
        const [riskFree, flex] = await Promise.all([
          isCohortAvailable(ctx.db, "risk_free_20"),
          isCohortAvailable(ctx.db, "flex_10")
        ]);
        return { riskFree20: riskFree, flex10: flex };
      })
    })
  }),
  // ─── GUARANTEE (tenant-facing) ─────────────────────────────────────────────
  guarantee: router({
    status: tenantProcedure.query(async ({ ctx }) => {
      return getGuaranteeStatus(ctx.db, ctx.tenantId);
    }),
    roi: tenantProcedure.input(z7.object({
      periodStart: z7.date().optional(),
      periodEnd: z7.date().optional()
    }).optional()).query(async ({ ctx, input }) => {
      return calculateTenantROI(
        ctx.db,
        ctx.tenantId,
        input?.periodStart,
        input?.periodEnd
      );
    })
  }),
  // ─── STRIPE CHECKOUT ──────────────────────────────────────────────────────
  stripeCheckout: router(stripeCheckoutRouter),
  // ─── REFERRAL ─────────────────────────────────────────────────────────────
  referral: router(referralRouter),
  // ─── STRIPE CONNECT ───────────────────────────────────────────────────────
  stripeConnect: stripeConnectRouter,
  // ─── FEATURE CONFIG ────────────────────────────────────────────────────────
  featureConfig: router(featureConfigRouter)
});

// server/_core/context.ts
async function createContext(opts) {
  const { getDb: getDb2 } = await Promise.resolve().then(() => (init_db(), db_exports));
  const dbRaw = await getDb2();
  if (!dbRaw) {
    throw new Error("Database unavailable");
  }
  const db = dbRaw;
  let user = null;
  let authViaApiKey = false;
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch {
    user = null;
  }
  if (!user && db) {
    const bearer = opts.req.headers.authorization;
    if (bearer?.startsWith("Bearer rk_")) {
      user = await resolveUserFromApiKey(db, bearer.slice(7));
      authViaApiKey = !!user;
    } else {
      const xk = opts.req.headers["x-api-key"];
      if (typeof xk === "string" && xk.startsWith("rk_")) {
        user = await resolveUserFromApiKey(db, xk);
        authViaApiKey = !!user;
      }
    }
  }
  return {
    req: opts.req,
    res: opts.res,
    user,
    db,
    correlationId: opts.req.correlationId,
    authViaApiKey
  };
}

// server/_core/vite.ts
import express2 from "express";
import fs from "fs";
import { nanoid } from "nanoid";
import path from "path";
async function setupVite(app, server) {
  const viteModule = await import("vite");
  const createViteServer = viteModule.createServer;
  const vite = await createViteServer({
    configFile: path.resolve(import.meta.dirname, "../..", "vite.config.ts"),
    server: {
      middlewareMode: true,
      hmr: { server },
      allowedHosts: true
    },
    appType: "custom"
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app) {
  const distPath = process.env.NODE_ENV === "development" ? path.resolve(import.meta.dirname, "../..", "dist", "public") : path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app.use("/assets", express2.static(path.join(distPath, "assets"), {
    maxAge: "1y",
    immutable: true
  }));
  app.use(express2.static(distPath, {
    index: false,
    // Don't serve index.html from static — let the fallback handle it with proper no-cache headers
    setHeaders(res, filePath) {
      if (filePath.endsWith(".html")) {
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      }
    }
  }));
  app.use("*", (_req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}

// server/_core/index.ts
init_db();
init_logger();
init_requestContext();
import { readFileSync } from "fs";
var isShuttingDown = false;
var shutdownTimeoutMs = 3e4;
var corsOrigins = process.env.CORS_ORIGIN?.split(",").map((s) => s.trim()).filter(Boolean) ?? [];
var WORKER_HEARTBEAT_FILE = process.env.WORKER_HEARTBEAT_FILE || "/tmp/worker-heartbeat.json";
var WORKER_STALE_MS = 2 * 6e4;
function isPortAvailable(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}
async function findAvailablePort(startPort = 3e3) {
  if (process.env.NODE_ENV === "production" || !!process.env.DOCKER_ENV) {
    return startPort;
  }
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}
async function gracefulShutdown(server, signal) {
  if (isShuttingDown) {
    logger.warn("Shutdown already in progress, ignoring signal", { signal });
    return;
  }
  isShuttingDown = true;
  logger.info("Starting graceful shutdown", { signal, timeout: shutdownTimeoutMs });
  try {
    const shutdownTimeout = setTimeout(() => {
      logger.error("Graceful shutdown timeout, forcing exit", { signal });
      process.exit(1);
    }, shutdownTimeoutMs);
    server.close(async (err) => {
      if (err) {
        logger.error("Error closing server", { error: err.message });
        clearTimeout(shutdownTimeout);
        process.exit(1);
      }
      logger.info("Server stopped accepting new connections");
      try {
        const db = await getDb();
        if (db && db.$client) {
          logger.info("Closing database connections");
          await db.$client.end();
        }
        logger.info("Graceful shutdown completed successfully", { signal });
        clearTimeout(shutdownTimeout);
        process.exit(0);
      } catch (dbError) {
        logger.error("Error closing database connections", { error: dbError.message });
        clearTimeout(shutdownTimeout);
        process.exit(1);
      }
    });
    server.on("close", () => {
      logger.info("All connections closed");
    });
  } catch (error) {
    logger.error("Error during graceful shutdown", { error: error.message, signal });
    process.exit(1);
  }
}
function registerShutdownHandlers(server) {
  const signals = ["SIGTERM", "SIGINT", "SIGUSR2"];
  signals.forEach((signal) => {
    process.on(signal, () => {
      logger.info(`Received ${signal} signal`, { signal });
      gracefulShutdown(server, signal);
    });
  });
  process.on("uncaughtException", (error) => {
    logger.error("Uncaught Exception", { error: error.message, stack: error.stack });
    gracefulShutdown(server, "uncaughtException");
  });
  process.on("unhandledRejection", (reason, promise) => {
    logger.error("Unhandled Rejection", { reason: String(reason), promise: String(promise) });
    gracefulShutdown(server, "unhandledRejection");
  });
}
async function startServer() {
  await initSentry();
  const app = express3();
  app.set("trust proxy", 1);
  const server = createServer(app);
  registerStripeWebhook(app);
  app.use(
    cors({
      origin: corsOrigins.length > 0 ? corsOrigins : true,
      credentials: true
    })
  );
  app.use((req, res, next) => {
    const correlationId = ensureCorrelationId(req.header("x-correlation-id") || void 0);
    req.correlationId = correlationId;
    res.setHeader("x-correlation-id", correlationId);
    runWithCorrelationId(correlationId, () => next());
  });
  const rawBodySaver = (req, _res, buffer) => {
    req.rawBody = buffer.toString("utf8");
  };
  app.use(express3.json({ limit: "2mb", verify: rawBodySaver }));
  app.use(express3.urlencoded({ limit: "2mb", extended: true, verify: rawBodySaver }));
  registerOAuthRoutes(app);
  registerInboundWebhooks(app);
  app.get("/health", async (_req, res) => {
    const dbOk = await pingDb();
    const status = dbOk ? 200 : 503;
    res.status(status).json({
      status: dbOk ? "ok" : "degraded",
      db: dbOk ? "connected" : "unreachable",
      uptime: Math.floor(process.uptime()),
      ts: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  app.get("/ready", async (_req, res) => {
    const dbOk = await pingDb();
    let workerHealthy = false;
    try {
      const heartbeat = JSON.parse(readFileSync(WORKER_HEARTBEAT_FILE, "utf8"));
      const ts = Date.parse(heartbeat.ts || heartbeat.lastSuccessAt || "");
      workerHealthy = Number.isFinite(ts) && Date.now() - ts <= WORKER_STALE_MS && heartbeat.status !== "error";
    } catch {
      workerHealthy = false;
    }
    const healthy = dbOk && workerHealthy;
    res.status(healthy ? 200 : 503).json({
      status: healthy ? "ready" : "degraded",
      db: dbOk ? "connected" : "unreachable",
      worker: workerHealthy ? "healthy" : "stale",
      ts: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  const apiLimiter = rateLimit({
    windowMs: 5 * 60 * 1e3,
    limit: 600,
    standardHeaders: "draft-7",
    legacyHeaders: false
  });
  app.use("/api/", apiLimiter);
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
      onError: async ({ error, path: path2, ctx }) => {
        logger.error("tRPC error", { path: path2, message: error.message, correlationId: ctx?.correlationId });
        captureException(error, { path: path2, tenantId: ctx?.tenantId });
        const db = await getDb();
        if (db) {
          await createSystemError(db, {
            type: "system",
            message: `tRPC Error in ${path2}: ${error.message}`,
            detail: JSON.stringify({
              stack: error.stack,
              correlationId: ctx?.correlationId
            }),
            tenantId: ctx?.tenantId
          }).catch((err) => logger.error("Failed to log system error", { error: String(err) }));
        }
      }
    })
  );
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const preferredPort = parseInt(process.env.PORT || "3000");
  const isDocker = process.env.NODE_ENV === "production" || !!process.env.DOCKER_ENV;
  let port = preferredPort;
  if (!isDocker) {
    port = await findAvailablePort(preferredPort);
    if (port !== preferredPort) {
      console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
    }
  }
  server.listen(port, () => {
    logger.info("Server started", { port, env: process.env.NODE_ENV });
  });
  registerShutdownHandlers(server);
}
startServer().catch(console.error);
